<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of client_footer
 *
 * @author Steve
 */
?>
<!-- PAGE FOOTER -->
<div class="page-footer">
<div class="row">
    <div class="col-xs-12 col-sm-6">
            <span class="txt-color-white">EZ Pay Payment Software System © 2014-2016</span>
    </div>
</div>
</div>


<!--================================================== -->

