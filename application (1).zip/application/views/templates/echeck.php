<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="Web based loan maintenance software">
    <meta name="author" content="Steve Thomas">
    <link rel="icon" href="../../favicon.ico">
    <link href='https://fonts.googleapis.com/css?family=Comfortaa' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Rokkitt' rel='stylesheet' type='text/css'>
        <title><?php echo $title; ?></title>
        
        <?php 
        // CSS
        $type = 'text/css';
        $rel = 'stylesheet';
        echo link_tag('assets/css/style.css'); 
        //echo link_tag('https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.5.4/bootstrap-select.min.css');
        echo link_tag('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css');
        echo link_tag('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css');
        //echo link_tag('//ajax.googleapis.com/ajax/libs/jqueryui/1.11.1/themes/smoothness/jquery-ui.css'); 
        echo link_tag('https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css');
       // echo link_tag('http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'); 
        
        echo link_tag('assets/css/bootstrap.min.css'); 
       //  echo link_tag('assets/css/bootstrap.css');
         echo link_tag('assets/css/bootstrap-theme.min.css'); 
         echo link_tag('assets/css/font-awesome.min.css'); 
           echo link_tag('assets/css/smartadmin-production.min.css'); 
           echo link_tag('assets/css/smartadmin-rtl.min.css'); 
    //       echo link_tag('assets/css/smartadmin-skins.min.css');
           echo link_tag('assets/js/bootstrap/bootstrap-datepicker/css/datepicker.css');
           echo link_tag('assets/css/jquery-ui-1.11.4.custom/jquery-ui.css');
        echo link_tag('assets/css/jquery-ui-1.11.4.custom/jquery-ui.structure.css');
        echo link_tag('assets/css/jquery-ui-1.11.4.custom/jquery-ui.theme.css');

         ?>
            <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <script src="../../assets/js/libs/jquery-ui-1.10.3.min.js"></script>
    <script src="../../assets/js/smartwidgets/jarvis.widget.min.js"></script>
    <script src="../../assets/js/bootstrap/bootstrap.min.js"></script>
    <script src="../../assets/js/plugin/jquery-form/jquery-form.min.js"></script>
<!--    <script src="../../assets/js/plugin/easy-pie-chart/jquery.easy-pie-chart.min.js"></script>-->
<!--    <script src="../../assets/js/plugin/datatables/dataTables.bootstrap.min.js"></script>-->
    <script src="../../assets/js/plugin/jquery-form/formats_4_forms.js"></script>
    <script src="../../assets/css/jquery-ui-1.11.4.custom/jquery-ui.js"></script>

    <script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/jquery.validate.min.js"></script>
    <script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/additional-methods.min.js"></script>
    <script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/jquery.validate.js"></script>
    <script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/jquery.validate.min.js"></script>
    <script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/additional-methods.js"></script>
    <script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/additional-methods.min.js"></script>

    <script src="../../../assets/js/echeck.js"></script>
    <link href='../../../assets/css/terminal.css' rel='stylesheet' type='text/css'>

          <script>
              $(document).ready(function() {
                  $(".datepicker").datepicker();
              });
      
    $(function() {
    $( "#add_since" ).datepicker({ minDate: -20, maxDate: "+1M +10D" });
  });

  function HideContent(d) {
    document.getElementById(d).style.display = "none";
    }
    function ShowContent(d) {
    document.getElementById(d).style.display = "block";
    }
    function ReverseDisplay(d) {
    if(document.getElementById(d).style.display == "none") { document.getElementById(d).style.display = "block"; }
    else { document.getElementById(d).style.display = "none"; }
    }
  </script>
  
    </head>
 
<!--    <body class="fixed-header menu-on-top">       this puts the menu on the top horizontally-->
        <body class="fixed-header fixed-navigation fixed-footer">    
<?php $this->load->view('templates/client_header'); // load the header into the template?>       
<?php $this->load->view('templates/client_sidenav'); // load the side navigation menu into the template?> 
<?php echo $body; // load the selected page body into tne template ?>           
<?php $this->load->view('templates/client_footer'); // load the footer into the template?>
    
    

         
    </body>
     
</html>
 