<?php  defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="<?php echo $description; ?>">
    <meta name="author" content="Steve Thomas">
    <link rel="icon" href="../../favicon.ico">
    <link href='https://fonts.googleapis.com/css?family=Rokkitt' rel='stylesheet' type='text/css'>
        <title><?php echo $title; ?></title>
<!--        <link type="text/css" href="assets/css/style.css" rel="stylesheet"/>-->
        <?php 
        // CSS
        echo link_tag('assets/css/style.css'); 
        echo link_tag('https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.5.4/bootstrap-select.min.css');
        echo link_tag('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css');
        echo link_tag('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css');
        echo link_tag('//ajax.googleapis.com/ajax/libs/jqueryui/1.11.1/themes/smoothness/jquery-ui.css'); 
        echo link_tag('https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css');
        echo link_tag('assets/css/bootstrap.min.css');  
         echo link_tag('assets/css/bootstrap.css');
         echo link_tag('assets/css/bootstrap-theme.min.css'); 
         echo link_tag('assets/css/font-awesome.min.css'); 
           echo link_tag('assets/css/smartadmin-production.min.css'); 
           echo link_tag('assets/css/smartadmin-rtl.min.css'); 
           echo link_tag('assets/css/smartadmin-skins.min.css'); 
           echo link_tag("https://fonts.googleapis.com/css?family=Comfortaa"); 
          echo link_tag('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js','','text/javascript');
          echo link_tag('https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js','','text/javascript'); 
          echo link_tag('https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.5.4/bootstrap-select.min.js','','text/javascript');

         ?>
         <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
        <script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
        <script src="../../assets/js/smartwidgets/jarvis.widget.min.js"></script>
    <script src="../../assets/js/bootstrap/bootstrap.min.js"></script>
    <script src="../../assets/js/plugin/jquery-form/formats_4_forms.js"></script>
    <script src="../../assets/css/jquery-ui-1.11.4.custom/jquery-ui.js"></script>
    <script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/jquery.validate.min.js"></script>
    <script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/additional-methods.min.js"></script>
    
            <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
        
        
    </head>
 

                <?php
			if( isset( $auth_user_id ) ){
				echo secure_anchor('users/logout','Logout');
                                echo '</li><li><a href="/clients">Temp Backend</a></li>';
			}else{
                            echo secure_anchor( LOGIN_PAGE . '?redirect=users/login','Login');
                          echo'</li>'; 
			}
		?>

             <body class="fixed-header fixed-navigation fixed-footer">    
<?php $this->load->view('templates/default_header'); // load the header into the template?> 
<?php $this->load->view('templates/default_sidenav'); // load the footer into the template?>  
        <div class="margin-bottom-10"> 
            <?php echo $body; ?>
        </div>
        <div class="margin-top-5">
          <?php $this->load->view('templates/default_footer'); // load the footer into the template?>  
        </div>


         
    </body>
     
</html>
 <?php

/* End of file default.php */
/* Location: /views/templates/default.php */