<?php

/* 
 * This is the client template header
 * This page adds the top bar to the page
 * Steve Thomas
 * Revised: 6/19/2016
 */
  $Users = (Array)$this->users_model->get_by_id($this->auth_user_id)->row();
$Clients = (Array)$this->clients_model->get_by_id($this->auth_user_id)->row();
?>

<!-- HEADER -->
<header id="header">
        <div id="logo-group">     
        <span id="logo">
            <a href=' .<? base_url();?>. '><img src="/assets/img/pagasys.png" alt="Pagasys"></a> </span>

        <span id="activity" class="activity-dropdown"> <i class="fa fa-user"></i> <b class="badge">
         <?php if( isset( $auth_user_id ) ){ echo $Clients['client_name']; }else{echo "none"; } ?>   
            </b> </span>

        </div>

<!-- projects dropdown -->
<div class="project-context hidden-sm">

        <span class="label"><?php if( isset( $auth_user_id ) ){ echo $auth_role; }else{echo "none"; } ?></span>
        <span class="project-selector dropdown-toggle" data-toggle="dropdown"><?php echo $auth_user_id; ?> <i class="fa fa-angle-down"></i></span>

        <!-- Suggestion: populate this list with fetch and push technique -->
        <ul class="dropdown-menu">
            <li>Name: <?php echo $Users['user_fname']. " " .$Users['user_lname']; ?></li>
            <li>Email: <?php echo $Users['user_email']; ?></li>
            <li>Last Login: <?php echo $Users['user_last_login']; ?></li>
            <li>Listed Phone: <?php echo $Users['user_phone']; ?></li>
            <li>Address: <?php echo $Users['user_street']. " ".$Users['user_unit']; ?></li>
            <li>Address: <?php echo $Users['user_city']. ", ".$Users['user_state']. " ".$Users['user_zipcode']; ?></li>
            <li>Status: <?php echo $Users['user_status']; ?></li>
        </ul>
        <!-- end dropdown-menu-->

</div>
<!-- end projects dropdown -->



        <!-- logout button -->
        <div id="logout" class="btn-header  pull-right hidden-mobile hidden-sm hidden-xs">
            <span> <a href="/users/logout" title="Sign Out" data-action="userLogout" data-logout-msg="You can improve your security further after logging out by closing this opened browser">
                        <i class="fa fa-sign-out"> Log Out</i>
                   </a> </span>
        </div>
        <!-- end logout button -->
        
        <!-- logout link for mobile -->
        <div class="btn-header pull-right hidden-lg hidden-md">
            <span> <a href="/users/logout" title="Sign Out" data-action="userLogout" data-logout-msg="You can improve your security further after logging out by closing this opened browser">
                        <i class="fa fa-sign-out"> Log Out</i>
                   </a> </span>
        </div>
        <!-- end logout mobile link -->


</header>
<!-- END HEADER -->