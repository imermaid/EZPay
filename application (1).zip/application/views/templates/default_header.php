<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<!-- HEADER -->
<header id="header">
 
     
        <div id="logo-group">     
        <span id="logo">
            <a href=' .<? base_url();?>. '><img src="/assets/img/pagasys.png" alt="Pagasys"></a> </span>

<!--        <span id="activity" class="activity-dropdown"> <i class="fa fa-user"></i> <b class="badge">-->
         <?php //if( isset( $auth_user_id ) ){ echo $auth_user_name; }else{echo "none"; } ?> 
<!--            </b> </span>-->

        </div>
       
       
<!-- pulled right: nav area -->
<div class="pull-right">
    
<div id="logout" class="btn-header transparent pull-right visible-lg-inline visible-md-inline">   
      <ul class="nav navbar-nav navbar-left">
            <li><a href='.<? base_url(); ?>.' title="EZ Pay Home"><i class="fa fa-home"> HOME</i></a></li>
            <li><a href="/pages/product"><i class="fa fa-list-ol"> PRODUCTS</i></a></li>
            <li><a href="/pages/contact"><i class="fa fa-connectdevelop"> CONTACT US</i></a></li>
            <li><?php
                        if( isset( $auth_user_id ) ){
                                echo secure_anchor('users/logout','Logout');
                                echo '</li><li><a href="/clients"><i class="fa fa-forward"> Temp Backend</i></a></li>';
                        }else{
                            echo secure_anchor( LOGIN_PAGE . '?redirect=users/login','<i class="fa fa-sign-in"> LOGIN</i>');
                          echo'</li>'; 
                        }
                ?>
      </ul>
    </div>
    
    <div class="visible-xs-inline hidden-lg hidden-md">   
     
            <a href='.<? base_url(); ?>.' title="EZ Pay Home"><i class="fa fa-home"> HOME</i></a>
            <a href="/pages/product"><i class="fa fa-list-ol"> PRODUCTS</i></a>
            <a href="/pages/contact"><i class="fa fa-connectdevelop"> CONTACT US</i></a>
            <?php
                        if( isset( $auth_user_id ) ){
                                echo secure_anchor('users/logout','Logout');
                                echo '<a href="/clients"><i class="fa fa-forward"> Temp Backend</i></a>';
                        }else{
                            echo secure_anchor( LOGIN_PAGE . '?redirect=users/login','<i class="fa fa-sign-in"> LOGIN</i>');
                           
                        }
                ?>
      
    </div>
    
    
        </div>
        <!-- end logout -->

<!-- end pulled right: nav area -->
    
       
 
  

 </header>
<!-- END HEADER -->   