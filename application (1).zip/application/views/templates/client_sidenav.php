
<!-- Left panel : Navigation area -->
<!-- Note: This width of the aside area can be adjusted through LESS variables -->
<aside id="left-panel">

<!-- User info -->
<div>
                <span>
                   
                   <?php 
                   $Users = (Array)$this->users_model->get_by_id($this->auth_user_id)->row();
                    
                   $display_name = $Users['user_fname']. ' ' .$Users['user_lname'];
                   
                   echo '<h6 class="sidecolor">' .$display_name. '</h6>';
                   echo '<p class="sidecolor">' .$Users['user_last_login']. '</p>';
                   ?>  

                </span>
</div>
<!-- end user info -->
        <nav>
           <ul>
                        <li>
                         
                            <a href="<?php echo secure_site_url('dashboard/'); ?>">
                            
                               
                                    <i class="fa fa-lg fa-fw fa-tachometer txt-color-blue"></i> 
                                    <span class="menu-item-parent">Dashboard</span>
                                </a>
                        </li> 
                        <li>
                                <a href="#"><i class="fa fa-lg fa-fw fa-inbox"></i> 
                                    <span class="menu-item-parent">Inbox</span>
                                    <span class="badge pull-right inbox-badge">0</span>
                                </a>
                        </li>
                        
                        <li>
                        <a href="<?php echo secure_site_url('reports/'); ?>">
                            <i class="fa fa-lg fa-fw fa-table"></i> 
                            <span class="menu-item-parent">Reports</span>
                        </a>
                        
                        </li>
                        
                         
                        <li>
                                <a href="<?php echo secure_site_url('products/'); ?>">
                                    <i class="fa fa-lg fa-fw fa-list-alt"></i> 
                                    <span class="menu-item-parent">Profile Settings</span></a>
                        </li>
                    <?php if( $auth_level == 9 ){ ?>
                        <li>
                               <a href="<?php echo secure_site_url('products/'); ?>">
                                    <i class="fa fa-lg fa-fw fa-windows"></i> 
                                    <span class="menu-item-parent">Company Settings</span></a>
                              
                        </li>
                        
                       
                        <li>
                               <a href="<?php echo secure_site_url('admin'); ?>">
                                    <i class="fa fa-lg fa-fw fa-cube txt-color-blue"></i> 
                                    <span class="menu-item-parent">Admin</span></a>
                               
                        </li>
                        <?php   } ?>
                </ul>
        </nav>
       

</aside>
<!-- END NAVIGATION -->