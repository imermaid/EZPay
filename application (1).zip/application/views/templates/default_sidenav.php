<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>

<!-- Left panel : Navigation area -->
<!-- Note: This width of the aside area can be adjusted through LESS variables -->
<aside id="left-panel">


        <nav>
           <ul>
                         
                        <li>
                             <a href="<?php echo secure_site_url('/'); ?>">
                            <i class="fa fa-lg fa-fw fa-home txt-color-blueLight">
                                
                                </i> <span class="menu-item-parent">Home</span></a>
                                
                        </li>
                        <li>
                                <a href="<?php echo secure_site_url('pages/contact'); ?>">
                                    <i class="fa fa-lg fa-fw fa-inbox"></i> 
                                    <span class="menu-item-parent">Contact Us</span>
                                    
                                </a>
                        </li>
                        <li>
                                 <a href="<?php echo secure_site_url('/login'); ?>">
                                <i class="fa fa-lg fa-fw fa-sign-in txt-color-blueLight">

                                    </i> <span class="menu-item-parent">Login</span>
                                 </a>

                        </li>
                        
                        
                        <li>
                                <a href="<?php echo secure_site_url('pages/product/'); ?>">
                                    <i class="fa fa-lg fa-fw fa-list-alt"></i> 
                                    <span class="menu-item-parent">Product Features</span>
                                </a>
                        </li>

                        
                       
                </ul>
        </nav>
       

</aside>
<!-- END NAVIGATION -->