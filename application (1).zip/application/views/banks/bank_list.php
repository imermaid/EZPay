<?php

/* 
 * Client_View
 * This displays the client View
 * Steve Thomas
 * 11/22/2015
 */

// get the var's that are used in this page
if(isset($cli_rec)): foreach ($cli_rec as $r): 
   $client_name = $r->client_name; 
endforeach;
endif;

?>
<!-- MAIN PANEL -->
<div id="main" role="main">

        <!-- RIBBON -->
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href="<?php base_url(); ?>">Home</a></li>
                    <li><a href="<?php echo secure_site_url('dashboard'); ?>">Dashboard</a></li>
                    <li>List</li>
                </ol>
        </div>
        <!-- MAIN CONTENT -->
        <div id="content">

                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-8">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube"></i> <?php echo $client_name; ?>
                                    <span>> List Bank Accounts </span></h1>
                        </div>
                       

                </div>
 
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">  
       <div class="panel panel-primary">
    <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
    </div>  
        
          <div class="panel-body">                   
                    <div class="well well-lg"> 
                        
                        <h2><?php echo $message;  ?></h2>
                       <div class="pagination pagination-lg">
                            <?php echo $pagination; ?>
                        </div> 
                        <div class="data table">
                            <?php echo $table; ?>
                        </div> 
                        <div class="paging">
                            <?php echo $pagination; ?>
                        </div> <br /> 
                        
                            <?php echo secure_anchor(
                                    'banks/add/',
                                    '<i class="fa fa-lg fa-fw fa-user-plus txt-color-blue"></i> Add new Bank',
                                    array('class'=>'add')); ?> 
                    </div>                    
                </div>  
       </div>
    </article>
   </div> <!-- end row -->
 
 
        </div>
        <!-- END MAIN CONTENT -->
</div>
<!-- END MAIN PANEL -->
<script type="text/javascript">
$(function() {
    $("#app_phone").mask("(999) 999-9999");
    $( "tr:odd" ).css( "background-color", "#dbdbdb" );
    $("tr").not(':first').hover(
  function () {
    $(this).css("background","#3074ae");
    $(this).css("color", "#ffffff");
  }, 
  function () {
    $(this).css("background","");
    $( "tr:odd" ).css( "background-color", "#dbdbdb" );
    $(this).css("color", "#000000");

  }
);
    
});
</script>