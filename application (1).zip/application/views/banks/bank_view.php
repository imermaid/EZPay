<?php

/* 
 * bank_view.php
 * This displays the Bank View
 * Steve Thomas
 * revised 6/18/2016
 */

// get the var's that are used in this page
if(isset($cli_rec)): foreach ($cli_rec as $r): 
   $client_name = $r->client_name; 
endforeach;
endif;
if(empty($Bank['bank_id']) || $Bank['bank_id'] == '') {
                             //  $data['id'] = $id;
                          $Bank['bank_id'] = '';
                       $Bank['bank_name']  = '';
                     $Bank['bank_branch']  = '';
                    $Bank['bank_account']  = '';
                    $Bank['bank_routing']  = '';
                    $Bank['bank_address']  = '';
                       $Bank['bank_city']  = '';
                      $Bank['bank_state']  = '';
                        $Bank['bank_zip']  = '';
                    $Bank['bank_purpose']  = '';
                 $Bank['bank_trans_type']  = '';
                     $Bank['bank_status']  = '';
                     $Bank['bank_create']  = '';
                         $Bank['bank_by']  = '';
} 
?>
<!-- MAIN PANEL -->
<div id="main" role="main">

        <!-- RIBBON -->
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href="<?php base_url(); ?>">Home</a></li>
                    <li><a href="<?php echo secure_site_url('dashboard'); ?>">Dashboard</a></li>
                    <li><a href="<?php echo secure_site_url('banks/index'); ?>">Banks</a></li>
                    <li>View</li>
                </ol>
        </div>
        <!-- MAIN CONTENT -->
        <div id="content">

                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-8">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube"></i> <?php echo $client_name; ?>
                                    <span>> View Banking </span></h1>
                        </div>
                       

                </div>
 
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">  
       <div class="panel panel-primary">
    <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
    </div>  
        
          <div class="panel-body">
            <div class="content"> 
                
                <div class="data"> 
                    <div class="well well-lg">  
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Bank ID: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_id']; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Bank Name: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_name']; ?>
               </div>
           </div> 
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Branch: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_branch']; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Account Number: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_account']; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Routing Number: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_routing']; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Bank Address: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_address']; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>City: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_city']; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>State: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_state']; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Zipcode: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_zip']; ?>
               </div>
           </div> 
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Account Purpose: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_purpose']; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Account Trans Type: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_trans_type']; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Status: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_status']; ?>
               </div>
           </div>   
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Created: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_create']; ?>
               </div>
           </div> 
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Created By: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Bank['bank_by']; ?>
               </div>
           </div> 

          </div>
                    
             
                </div> 

            </div>
        </div>    
       </div>
    </article>
   </div> <!-- end row -->
 
 
        </div>
        <!-- END MAIN CONTENT -->
</div>
<!-- END MAIN PANEL -->


                              