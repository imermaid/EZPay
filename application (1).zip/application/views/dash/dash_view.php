<?php
/*
 * admin_main_view
 */
?>
<!-- MAIN PANEL -->
<div id="main" role="main">
    <div id="ribbon">
        <ol class="breadcrumb">
            <li><a href='.<? base_url(); ?>.'>Home</a></li><li>Dashboard</li>
        </ol>
    </div>
    <!-- MAIN CONTENT -->
    <div id="content">


        <section id="widget-grid" class="">

            <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">  
                <!--            <div class="panel panel-primary">
                                <div class="panel-heading">-->
                <h1><?php echo $headline; ?></h1>
                <!--                </div>  
                           
                           <div class="panel-body">                   -->

                <div class="padding-gutter">

                    <div class="row">

                        <!-- ADMIN Panel -->
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4"> 
                            <div class="panel panel-info">
                                <div class="panel-heading">
                                    <h1>ADMIN</h1>
                                </div>  

                                <div class="panel-body"> 

                                    <div class="list-group">

                                        <a href="<?php echo secure_site_url('users/index'); ?>">      
                                            <button type="button" class="list-group-item">
                                                <i class="fa fa-lg fa-fw fa-users txt-color-blue"></i> 
                                               <?php echo '<span class="badge pull-right inbox-badge">' .$count_users. '</span><span>View Users List</span>' ?>
                                            </button>
                                        </a>
                                    </div>
                                    <div class="list-group">

                                        <a href="<?php echo secure_site_url('banks/index'); ?>">      
                                            <button type="button" class="list-group-item">
                                                <i class="fa fa-lg fa-fw fa-bank txt-color-blue"></i> 
                                                <span class="badge"><?php //echo "1"; ?></span><span>View Banking</span>
                                            </button>
                                        </a>
                                    </div>
                                    <div class="list-group">

                                        <a href="<?php echo secure_site_url('clients/view'); ?>">      
                                            <button type="button" class="list-group-item">
                                                <i class="fa fa-lg fa-fw fa-institution txt-color-blue"></i> 
                                                <span>View Company Profile</span>
                                            </button>
                                        </a>
                                    </div>

                                </div> <!-- Panel Body -->
                            </div> <!-- Panel Heading -->
                        </div>  <!-- col -->


                        <!-- REPORTS Panel -->
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4"> 
                            <div class="panel panel-success">
                                <div class="panel-heading">
                                    <h1>REPORTS</h1>
                                </div>  

                                <div class="panel-body"> 

                                    <div class="list-group">

                                        <a href="<?php echo secure_site_url('reports/index'); ?>">      
                                            <button type="button" class="list-group-item">
                                                <i class="fa fa-lg fa-fw fa-calendar txt-color-blue"></i> 
                                                <span>Daily Reports</span>
                                            </button>
                                        </a>
                                    </div>
                                    <div class="list-group">

                                        <a href="<?php echo secure_site_url('applications/settlement'); ?>">      
                                            <button type="button" class="list-group-item">
                                                <i class="fa fa-lg fa-fw fa-list txt-color-blue"></i> 
                                                <span>Settlement</span>
                                            </button>
                                        </a>
                                    </div>
                                    <div class="list-group">

                                        <a href="<?php echo secure_site_url('applications/chargeback'); ?>">     
                                            <button type="button" class="list-group-item">
                                                <i class="fa fa-lg fa-fw fa-list-alt txt-color-blue"></i> 
                                                <span>Chargebacks</span>
                                            </button>
                                        </a>
                                    </div>

                                </div> <!-- Panel Body -->
                            </div> <!-- Panel Heading -->
                        </div>  <!-- col -->


                        <!-- Virtual Terminal Panel -->
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4"> 
                            <div class="panel panel-warning">
                                <div class="panel-heading">
                                    <h1>VIRTUAL TERMINAL</h1>
                                </div>  

                                <div class="panel-body"> 

                                    <div class="list-group">

                                        <a href="<?php echo secure_site_url('terminal/index'); ?>">      
                                            <button type="button" class="list-group-item">
                                                <i class="fa fa-lg fa-fw fa-credit-card txt-color-blue"></i> 
                                                <span>Card Payment</span>
                                            </button>
                                        </a>
                                    </div>
                                    <div class="list-group">

                                        <a href="<?php echo secure_site_url('terminal/echeck'); ?>">      
                                            <button type="button" class="list-group-item">
                                                <i class="fa fa-lg fa-fw fa-money txt-color-blue"></i> 
                                                <span>E-Check</span>
                                            </button>
                                        </a>
                                    </div>
                                    <div class="list-group">

                                        <a href="<?php echo secure_site_url('applications/holidays'); ?>">      
                                            <button type="button" class="list-group-item">
                                                <i class="fa fa-lg fa-fw fa-calendar-minus-o txt-color-blue"></i> 
                                                <span>Holidays</span>
                                            </button>
                                        </a>
                                    </div>

                                </div> <!-- Panel Body -->
                            </div> <!-- Panel Heading -->
                        </div>  <!-- col -->

                    </div> <!-- row -->




                </div> 
                <!--             </div>
                            </div>-->

            </article>



        </section>
    </div>
</div>
<!-- END MAIN PANEL -->


