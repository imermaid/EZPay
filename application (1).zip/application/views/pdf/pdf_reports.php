<style media="all" type="text/css">

span.table {
    width:100% !important;
    display:block;
    height:auto;
    overflow:auto;
    border:1px solid black;
}
span.td {
    border: none !important;
/*    background: White !important;*/
    font-size: 16px;
    border:none !important;
    float:left;
    display:inline-block;
/*    width:16.6%;*/
}
span.tr {
    border: 1px solid Black;
    background-color: #f5f5f5;
    display:block;
    height:auto;
    overflow:auto;
}
span.th {
    text-align: center;
    font-weight: bold;
    display:inline-block;
    width:16.6%;
}

</style>
 <style>
    
     @page { margin: 10px 50px; padding-right: 35px; }
     #header { position: fixed; left: 0px; top: 10px; right: 0px; height: 120px; color: #f5f5f5; background-color: #3675b0; text-align: left; }
     #footer { position: fixed; left: 0px; bottom: 10px; right: 0px; height: 80px; color: #f5f5f5; background-color: #3675b0; text-align: center; }
     #footer .page:after { content: counter(page, upper-roman); }
   </style>
   <?php

    if ( isset($pdf) ) {

      $font = Font_Metrics::get_font("helvetica", "bold");
      $pdf->page_text(500,10, "Page: {PAGE_NUM} of {PAGE_COUNT}", $font, 6, array(0,0,0));

    }
    ?>
<!-- MAIN PANEL -->
<div id="main" role="main">
    
    
    
 
    <div id="header" style="padding-left: 25px;">
          <h1><?php echo $title; ?></h1>
          <p><?php echo date("l jS \of F Y h:i:s A");?></p>
    </div>  
        <?php if(empty($total)) { $total = "No Records."; } ?>
    <p style="text-align: right">Total Records: <?php echo $total; ?></p>
     <div id="content">
                    <span class="table">
				<span class="tr">
					<span class="th h1">ID</span>
                                        <span class="th">Cardholder</span>
                                        <span class="th">Card</span>
                                        <span class="th">Amount</span>
                                        <span class="th">Date</span>
                                        <span class="th">Status</span>
                                </span>


                            <?php
                            if (empty($ret)) {
                                 echo "There are no records to display.";
                                
                            }else {
                            foreach ($ret as $item) { 
                             ?>
                        <span class="tr">
                            <span class="td" style="width:15%;"><?php echo $item->CUST_ID; ?></span>
                            <span class="td" style="width:18%;"><?php echo $item->name_on_card; ?></span>
                            <span class="td" style="width:15%;"><?php echo $item->CNumber; ?></span>
                            <span class="td" style="width:15%;"><?php echo $item->AMT; ?></span>
                            <span class="td" style="width:16%;"><?php echo $item->CDate; ?></span>
                            <span class="td" style="width:21%;"><?php echo $item->Status; ?></span>
                        </span>

                           <?php 
                            }
                            }
                           ?>
                    </span> <!-- END TABLE SPAN -->
                </div>
    
    <?php if(empty($total)) { $total = "No Records."; } ?>
                    <p>Total Records: <?php echo $total; ?></p>
                    
        <div id="footer">
             <p class="page">Page <?php $PAGE_NUM ?></p>
             
        </div>
                
                    
                   
            

</div>
<!-- END MAIN PANEL -->

