<?php

/* 
 * admin_main_view
 */

// get the var's that are used in this page
if(isset($cli_rec)): foreach ($cli_rec as $r): 
   $client_name    = $r->client_name; 
   $contact_name  = $r->contact_name;
   $contact_phone = $r->contact_phone; 
endforeach;
endif;
if(isset($records)): foreach ($records as $row): 
    $user_email = $row->user_email; 
    $user_id = $row->user_id; 
    $user_name = $row->user_name; 
    endforeach;
    endif; 
?>
<!-- MAIN PANEL -->
<div id="main" role="main">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>Admin View</li>
                </ol>
        </div>
<div id="content">
                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube"></i> <?php echo $client_name; ?>
                                    <span>> Admin Dashboard </span></h1>
                        </div>
                </div>
  <section id="widget-grid" class="">
                        <div class="row">
      <article class="col-xs-12 col-sm-12 col-md-12 col-lg-7">
            <div class="jarviswidget" id="wid-id-0" data-widget-colorbutton="false"	
                 data-widget-editbutton="false" data-widget-togglebutton="false" 
                 data-widget-deletebutton="false" data-widget-fullscreenbutton="false">
                    <header>
                            <h2> Search Records </h2>
                            <span class="badge pull-right margin-right-5 margin-top-5">Lists</span>
                    </header>
                  
                     
                                    <div class="padding-gutter">
                                        <div class="list-group">
                                            
                                        <a href="<?php echo secure_site_url('clients/index'); ?>">      
                                            <button type="button" class="list-group-item">
                                            <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                            <span class="badge"><?php echo $Client_count; ?></span><span>View Client List</span>
                                            </button>
                                        </a>
                                        <a href="<?php echo secure_site_url('users/'); ?>">    
                                            <button type="button" class="list-group-item">
                                            <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                            <span class="badge"><?php echo $User_count; ?></span><span>View User List</span>
                                            </button>  
                                        </a>
                                        <a href="<?php echo secure_site_url('users/'); ?>">    
                                            <button type="button" class="list-group-item">
                                            <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                            <span>View Lenders List</span>
                                            </button>
                                         </a>
                                        <a href="<?php echo secure_site_url('users/'); ?>">    
                                            <button type="button" class="list-group-item">
                                                <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i>
                                            <span>View Recent Applications</span>
                                            </button>
                                        </a>    
                                        <a href="<?php echo secure_site_url('users/'); ?>">    
                                            <button type="button" class="list-group-item">
                                            <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                            <span>View Approvals</span>    
                                            </button>
                                        </a>  
                                        <a href="<?php echo secure_site_url('users/'); ?>">    
                                            <button type="button" class="list-group-item">
                                            <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                            <span>View Denial Applications</span>    
                                            </button>
                                        </a>
                                        <a href="<?php echo secure_site_url('users/'); ?>">    
                                            <button type="button" class="list-group-item">
                                            <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                            <span>View Escrow Accounts</span>    
                                            </button>
                                        </a>
</div>
                                        
                                       
                                        
                                        
                                        
                                    </div>

                       


            </div>
            <!-- end widget -->

          

    </article>
                                <!-- WIDGET END -->

                                <article class="col-xs-12 col-sm-12 col-md-12 col-lg-5">

                                        <!-- Widget ID (each widget will need unique ID)-->
                                        <div class="jarviswidget" id="wid-id-2" data-widget-colorbutton="false"	data-widget-editbutton="false" data-widget-togglebutton="false" data-widget-deletebutton="false" data-widget-fullscreenbutton="false">
                                                <header>
                                                        <h2> Additional Controls </h2>
                                                </header>

                                                <!-- widget div-->
                                                <div>
                                                        <div class="widget-body no-padding">
                                                                <div class="padding-gutter padding-bottom-0">
                                                                    <p>Other Stuff</p>

                                                                </div>
                                                        </div>
                                                        <!-- end widget content -->

                                                </div>
                                                <!-- end widget div -->

                                        </div>
                                        <!-- end widget -->

                                </article>

                        </div>

                </section>
                <!-- end widget grid -->

        </div>
        <!-- END MAIN CONTENT -->

</div>
<!-- END MAIN PANEL -->

