<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<script type="text/javascript" language="JavaScript">
$(function() {
    $( "#add_since" ).datepicker({ 
            maxDate: "+1D" 
    });
    $( "#app_dob" ).datepicker({ 
        maxDate: "-18Y" 
    });
//$("app_phone").mask("999-999-9999");
// just for the demos, avoids form submit
//jQuery.validator.setDefaults({
//  debug: true,
//  success: "valid"
//});
//$( "#form_appl" ).validate({
//  rules: {
//    app_phone: {
//      required: true,
//      phoneUS: true
//    }
//  }
//});

  });
jQuery(function($){
   $("#app_dob").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#app_phone").mask("(999) 999-9999");
   $("#app_altphone").mask("(999) 999-9999");
   $("#app_primary_ssn").mask("999-99-9999");
});
</script>


    <!-- Begin page content -->
    <div id="main" data-role="page">
       
    <div id="content" class="container-fluid margin-top-0 margin-bottom-10">

        <div class="well-lg">
      <div class="page-header">
        <h1>PagaSys Contact Form  </h1>
      </div>
                
     <div class="panel panel-primary">
      <div class="panel-heading">
         <h1>Contact us for sales, support, or any questions you may need answered.</h1>  
        
      </div>  
          <div class="panel-body">                                   
              <p class="lead">If you're looking for a web based system that is robust, user friendly and affordable, look no further.</p>                          
        <div class="content">


        
             <?php 
                    echo validation_errors(); 
                    $attributes = array('role' => 'form', 'id' => 'form_appl');
                    echo form_open($action, $attributes); 
                    echo form_fieldset('Contact Information'); ?>
            
            
            
                <?php
              $ename = !empty($name) ? $name : '';
              $ephone = !empty($phone) ? $phone : '';
              $emessage = !empty($comment) ? $comment : '';
              if ($ename != '' || $ephone != '' || $emessage != ''   )
              {
                  
              echo '<div class="row">';
              
              echo  '<h1 class="text-align-center text-danger">' . $success . '</h1>';    
                  
               echo '<p>Sent by: ' . ucwords($ename)    . '<br>' .
                         'Phone: ' . $ephone   . '<br>' .
                       'Comment: ' . $emessage . '</p>'; 
              echo '</div>'; 
              } else {
              ?>
               
            
                
             <div class="row">   
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-5">
            <div class="input-group">
                <label for="epurpose">Reason for Email</label><br>
                 <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <input type="radio" name="epurpose" 
                            value="Sales" <?php echo  set_radio('epurpose', 'Sales', TRUE, $radclass ); ?> /> Sales
                    <input type="radio" name="epurpose"
                           value="Service" <?php echo  set_radio('epurpose', 'Billing', $radclass ); ?> /> Billing
                    <input type="radio" name="epurpose"
                           value="Technical" <?php echo  set_radio('epurpose', 'Technical', $radclass ); ?> /> Technical
                    <input type="radio" name="epurpose"
                           value="Demo" <?php echo  set_radio('epurpose', 'Demo', $radclass ); ?> /> Demo
                </div>  
            </div>
            </div> 
            </div>
            <div class="row">
                 
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_fname">First Name<span style="color:red;"> *</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="app_fname" class="form-control"
                       value="<?php echo (set_value('app_fname')); ?>"/> 
                <span class="input-group-addon"></span>
            </div>
            </div>
            
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_lname">Last Name<span style="color:red;"> *</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="app_lname" class="form-control" 
                       value="<?php echo (set_value('app_lname')); ?>"/> 
                <span class="input-group-addon"></span>
                                     
            </div>
            </div>
               
               
                  
            </div>
            
             <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_phone">Phone</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                    <input type="tel" name="app_phone" class="form-control" id="app_phone"
                       value="<?php echo set_value('app_phone'); ?>"/> 
                <span class="input-group-addon"></span>
                            
                

            </div>
            </div>
            
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-5">
                <label for="app_email">Email Address<span style="color:red;"> * </span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-envelope-square"></i></span>
                <input type="email" name="app_email" class="form-control" placeholder="email address"
                       value="<?php echo set_value('app_email'); ?>"/> 
                <span class="input-group-addon"></span>
                           
                
            </div>
            </div>
            
            </div><!-- // end PHONE/EMAIL row -->
            
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-8">
                <label for="ecomment">Comment<span style="color:red;"> * </span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-envelope-square"></i></span>
                <?php 
                $cdata = array(
                  'name' => 'ecomment',
                    'id' => 'ecomment',
                    'placeholder' => 'Leave a Comment.',
                    'rows' => '6',
                    'cols' => '89'
                );
                echo form_textarea($cdata);
                ?>
                
                <span class="input-group-addon"></span>
                           
                
            </div>
            </div>
            </div>
            <br><br>
            
             <?php echo form_fieldset_close(); ?>
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <?php echo form_submit('submit_contact','Send', array('class' => 'pull-left btn btn-primary' ) ); ?>
            </div>
             <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">   
            <?php echo form_reset('reset_contact','Reset', array('class' => 'pull-right' ) ); ?>
             </div>
            </div>
            <?php echo form_close(); ?>
            
              <?php } // end the if that shows the form ?>
            
                        </div>
                </div>
         
     </div>
        </div>
   </div>
    </div>
 