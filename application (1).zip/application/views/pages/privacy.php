<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

    <!-- Begin page content -->
    <div id="main" data-role="page">
<!--        <div id="ribbon"></div>-->
    <div id="content" class="container-fluid margin-top-10 margin-bottom-10">
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <a href="<?php echo secure_site_url('dompdf_pdf/privacy'); ?>">      
                                            <button type="button" class="btn btn-primary">
                                            <span>PDF Version</span>
                                            </button>
                                        </a>
                </div>
        <div class="margin-top-10 well-lg">
            <div class="row"> 
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

      <h1>Privacy Policy</h1>
		
<p>This Privacy Policy will tell you what information we collect about you and about your use of the Paga-Sys.com site (Site). It will explain the choices you have about how your 
    personal information is used and how we protect that information. We urge you to read this Privacy Policy carefully.</p>
<h3>Information We Collect</h3>
<p>We may collect personal information about you (such as your name, postal address, telephone number and email address) that you provide voluntarily. We use your personal information 
    that you provide to respond to your questions, provide you the specific services you select and send you emails about Site maintenance and updates.</p>
<p>Even if you do not provide us with personal information, we collect non-personal information about your use of our Site.</p>
<p>We may use Cookies and Web Beacons to collect anonymous, non-personally identifiable information about your use of our Site. For example, we may use cookies to help you navigate 
    our Site more efficiently and statistically monitor how many people are using our Site. Cookies are small text records used by our system that allow us to track user requests 
    and tailor the resulting user experience while on our Site. Web Beacons are tiny graphic image files, embedded in a web page in GIF, jpeg or HTML format, that provide a presence on 
    the web page and send back to its home server (which can belong to the host site, a network advertiser or some other third party) information from your browser, such as the IP address, 
    the URL of the page on which the beacon is located, the type of browser that is accessing the Site and the ID number of any Cookies on your computer previously placed by that server. 
    Web Beacons may also be used to place a Cookie on your computer.</p>
<h3>AdWords Remarketing</h3>
<p>AdWords Remarketing is a Remarketing and Behavioral Targeting service provided by Google. It connects the activity of www.Paga-Sys.com with the Adwords advertising network and the 
    Doubleclick Cookie. You can opt out of the cookie tracking here: <a href="http://google.com/settings/ads/onweb/optout?hl=en">http://google.com/settings/ads/onweb/optout?hl=en</a></p>
<p>Personal Data collected: Cookie and Usage Data<br> Place of processing: USA<br> See the <a href="http://www.google.com/intl/en/policies/privacy/">Privacy Policy</a></p>
<h3>Protection of Personal Information of Children</h3>
<p>The Site is a general audience site and is not designed or intended to attract children under the age of 13. We do not knowingly collect personal information from any person 
    we actually know is under the age of 13.</p>
<h3>Use of your Personal Information</h3>
<p>The personal information collected on this Site will be used to provide the services you have requested or authorized.</p>
<p>We may use non-personal information for research purposes, and we may provide this information in the aggregate to third parties. For example, we might inform third parties regarding 
    the number of users of our Site and the activities they conduct while on our Site.</p>
<p>We contract with other companies and individuals to help us provide services. For example, we may host some of our Site on a computer with another company, or we may hire a company to 
    answer customer questions, send information about our products and other services. In order to perform their jobs, these other companies may have limited access to some of the 
    information we maintain about you. We require all such companies to comply with the terms of our Privacy Policy, to limit their access to any personal information to the minimum 
    necessary to perform their obligations, and not to use the information they may access for purposes other than fulfilling their responsibilities to us.</p>
<p>If we transfer a business unit (such as a subsidiary) or an asset (such as a web site) to another company, we will require them to honor the applicable terms of this Privacy Policy. 
    n the event that PagaSys or substantially all of its assets are acquired by a third party, personally identifiable information will be among the transferred assets.</p>
<p>We may release personal information to third parties: (1) to comply with valid legal requirements such as a law, regulation, search warrant, subpoena or court order; or (2) in special 
    cases, such as in response to a physical threat to you or others, to protect property or defend or assert legal rights. In the event that we are legally compelled to disclose your 
    personal information to a third party, we will attempt to notify you unless doing so would violate the law or court order. When we share information with third parties, we ask that 
    they agree in writing to abide by our Privacy Policy.</p>
<p>Other than the cases described above, we will not release personal information about you to a third party without your consent.</p>
<h3>Security of your Personal Information</h3>
<p>We have implemented technology and security policies, rules and other measures to protect the personal data that we have under our control from unauthorized access, improper use, 
    alteration, unlawful or accidental destruction, and accidental loss as described in our security page. We also protect your information by requiring that all our employees and others 
    who have access to or are associated with the processing of your data respect your confidentiality.</p>
<p>Although PagaSys makes every reasonable attempt to secure your information, there is always some risk in transmitting information over the Internet. There is always a risk that thieves 
    could find some way to circumvent our security systems. Although we take appropriate measures to protect your information, we cannot guarantee that the personal information that we 
    collect will never be disclosed in a manner that is inconsistent with this Privacy Policy.</p>
<h3>General</h3>
<p>If you have questions or concerns about this Privacy Policy, wish to access your personal information or request that we not use your personal information for a particular purpose, 
    please contact us at&nbsp;<a target="_blank" href="mailto:support@Paga-Sys.com">support@Paga-Sys.com</a>. We try to answer all inquiries within a reasonable time, but may not always 
    be able to do so.</p>
<p>We reserve the right to change this Privacy Policy at any time. When we do, we will post changes to the Privacy Policy on our Site only. Your continued use of this Site constitutes 
    your agreement to this Privacy Policy.</p>
<p>This Privacy Policy does not apply to content, business information, ideas, concepts or inventions that you send to this Site by email. If you want to keep content or business 
    information, ideas, concepts or inventions private or proprietary, do not send them in an email to this Site.</p>
<p>Customer data that is gathered while logged into our system is not tracted, shared or available to anyone other than the the authorized company representative.</p>  
<p>Copyright © 2016 PagaSys. All Rights Reserved</p>  
                
              </div>
            </div>

         <div class="row"> 
      <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
          <span><img src="/assets/img/logo-cert-pci.png" alt="EZ Pay PCI Compliant" width="120" class="pull-left" /> </span>
      </div>
         </div>
        
  </div>      
    </div>
    </div>