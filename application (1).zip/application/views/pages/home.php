<?php

/* 
 * Home page pages->home.php
 * Steve Thomas
 * 10/15/2015
 */

?>
    <!-- Begin page content -->
    <div id="main" data-role="page">
<!--        <div id="ribbon"></div>-->
    <div id="content" class="container-fluid margin-top-10 margin-bottom-10">
        <div class="jumbotron">
            <h1>EZ PAY Payment Software Solution</h1>
            <h4>We are a web based loan payment processing system for small/mid size companies.  </h4> 

      <p class="lead">If you're looking for a web based system that is robust, user friendly and affordable, your 
          looking days are behind you.</p>
      
     </div> 
       <div class="row"> 
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
          <span><img src="/assets/img/SmartAdmin.png" alt="EZ Pay Screenshot" width="500" class="pull-left" /> </span>
      </div>
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
               <h5>Working with loan companies to securely and efficiently manage their payment process is our specialty.</h5>
               <p>We assemble the required steps to get you from loan origination to final pay-out. Our custom process meets your payment needs 
                   every step of the way. So, whether you want to schedule regular 
               recurring payments that are automatically processed, "Phone-in" card payments, or using a customer web portal, we make it an easy decision.
               
               </p>
           </div>
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-2"></div>
       </div>
        <div class="row"> 
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <h1 class="page-title txt-color-blueDark">
                                    <i class="fa fa-lg fa-fw fa-cube txt-color-blue"></i>
                                    <span> Convenience Fee Based </span></h1>
                <p>Many of our clients pass the cost of payment processing off to the customer as a convenience fee. This means, you can provide all the convenience
                online payment processing provides without cutting into your revenue.</p>
                        </div>
             <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <h1 class="page-title txt-color-blueDark">
                                    <i class="fa fa-lg fa-fw fa-cube txt-color-blue"></i>
                                    <span> Transaction Fee </span></h1>
                 <p>This type of fee is based on volume. Our pricing includes everything you need to accept credit cards and is a percentage based fee. </p>
                        </div>
             <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <h1 class="page-title txt-color-blueDark">
                                    <i class="fa fa-lg fa-fw fa-cube txt-color-blue"></i>
                                    <span> Accept Any Payment Type </span></h1>
                 <p>Easily manage all payment types — debit, credit, checks, or ACH — on a single, configurable receivables platform. </p>
                        </div>
             <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <h1 class="page-title txt-color-blueDark">
                                    <i class="fa fa-lg fa-fw fa-cube txt-color-blue"></i>
                                    <span> Flexible Back Office Integration </span></h1>
                 <p>Seamless integration to existing loan software and systems.</p>
                        </div>
        </div>
            
        </div>
        
        <div class="row"> 
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <a href="<?php echo secure_site_url('pages/fees/convenience'); ?>">      
                                            <button type="button" class="btn btn-primary">
                                            <span>Read More</span>
                                            </button>
                                        </a>
                </div>
                
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <a href="<?php echo secure_site_url('pages/fees/convenience'); ?>">      
                                            <button type="button" class="btn btn-primary">
                                            <span>Read More</span>
                                            </button>
                                        </a>
                </div>
                
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <a href="<?php echo secure_site_url('pages/paymenttypes'); ?>">      
                                            <button type="button" class="btn btn-primary">
                                            <span>Read More</span>
                                            </button>
                                        </a>
                </div>
                
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <a href="<?php echo secure_site_url('pages/integration'); ?>">      
                                            <button type="button" class="btn btn-primary">
                                            <span>Read More</span>
                                            </button>
                                        </a>
                </div>
                
                
                
            </div>
        </div>
        
    </div>
    </div>

    
