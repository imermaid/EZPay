<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

    <!-- Begin page content -->
    <div class="container">
        <div class="margin-top-10 well-lg">
      <div class="page-header">
        <h1>Our products are built with latest technology driven with speed and security at the forefront.  </h1>
      </div>
      <p class="lead">We specialize in processing online payments for loan companies of all sizes.
      </p>
      <h1>Reports</h1>
      <p>PagaSys On-Authorized-Request Online Payments solutions deliver multiple ways to securely accept one-time and recurring online ACH and credit/debit card payments and 
          automatically post transaction details to your back-office software.
      </p>
      <div id="infrastructure">
          <h2>Fully Hosted Online Payment Portal</h2>
          <p>In our fully hosted model, PagaSys delivers and maintains an online payment portal carrying your brand and overall look and feel, but hosted on our PCI-compliant, 
              cloud-based infrastructure. Our fully hosted online payment portal minimizes internal support and IT burdens and offers your customers a convenient, secure and easy-to-use 
              payment portal that is available 24/7/365</p>
      </div>

        </div>
         <div class="row"> 
      <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
          <span><img src="/assets/img/logo-cert-pci.png" alt="EZ Pay PCI Compliant" width="120" class="pull-left" /> </span>
      </div>
         </div>
    </div>