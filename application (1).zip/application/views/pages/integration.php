<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

    <!-- Begin page content -->
    <div class="container">
        <div class="margin-top-10 well-lg">
      <div class="page-header">
        <h1>Our products are built with latest technology driven with speed and security at the forefront.  </h1>
      </div>
      <p class="lead">We specialize in processing online payments for loan companies of all sizes.
      </p>
      
      <p>Our unique approach to the process utilizes latest software technology that eliminates the need to use the antiquated version still in use today.
          We maximize an array of models so our robust and efficient technique will make funds processing instantaneous.
      Gone are the days you wait three days before returned payments can be collected. We update the account immediately.
      </p>
      <div id="convenience">
          <p>Convenience fee based is....</p>
      </div>

        </div>
    </div>