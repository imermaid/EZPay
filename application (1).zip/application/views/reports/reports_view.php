<?php

/* 
 * admin_main_view
 */

// get the var's that are used in this page
if(isset($cli_rec)): foreach ($cli_rec as $r): 
   $client_name    = $r->client_name; 
   $contact_name  = $r->contact_name;
   $contact_phone = $r->contact_phone; 
endforeach;
endif;
if(isset($records)): foreach ($records as $row): 
    $user_email = $row->user_email; 
    $user_id = $row->user_id; 
    $user_name = $row->user_name; 
    endforeach;
    endif; 
?>

<script type="text/javascript" language="JavaScript">


function HideContent(d) {
    document.getElementById(d).style.display = "none";
    }
    function ShowContent(d) {
    document.getElementById(d).style.display = "block";
    }
    function ReverseDisplay(d) {
    if(document.getElementById(d).style.display == "none") { document.getElementById(d).style.display = "block"; }
    else { document.getElementById(d).style.display = "none"; }
    }
</script>

<script>
 $(function() {   

$( "#search_auth_id" ).click(function() {

  $( "#by_n" ).hide( "slow" );
  $( "#by_p" ).hide( "slow" );
  $( "#by_i" ).hide( "slow" );
  $( "#by_a" ).show( "slow" );
});

$( "#search_name" ).click(function() {

  $( "#by_n" ).show( "slow" );
  $( "#by_p" ).hide( "slow" );
  $( "#by_i" ).hide( "slow" );
  $( "#by_a" ).hide( "slow" );
});

$( "#search_date" ).click(function() {

  $( "#by_p" ).show( "slow" );
  $( "#by_n" ).hide( "slow" );
  $( "#by_i" ).hide( "slow" );
  $( "#by_a" ).hide( "slow" );
});

$( "#search_ref_id" ).click(function() {

  $( "#by_i" ).show( "slow" );
  $( "#by_n" ).hide( "slow" );
  $( "#by_p" ).hide( "slow" );
  $( "#by_a" ).hide( "slow" );
});

});
</script>



<!-- MAIN PANEL -->
<div id="main" role="main">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href="<?php base_url(); ?>">Home</a></li>
                    <li><a href="<?php echo secure_site_url('dashboard'); ?>">Dashboard</a></li>
                    <li>Reports</li>
                    
                </ol>
        </div>
        <!-- MAIN CONTENT -->
<div id="content">
                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube"></i> <?php echo $client_name; ?>
                                    <span>> Reports </span></h1>
                        </div>
                </div>

<section id="widget-grid" class="">
 
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-8">
        <div class="jarviswidget">
                    <header>
                            <h2> Custom Search </h2>
                            <span class="badge pull-right margin-right-5 margin-top-5"><?php echo $client_name; ?></span>
                    </header>
    <div class="padding-gutter">           
        <div class="list-group">

            <form action="show_report" method="post" name="showReports" id="showReports" autocomplete="off">
                <?php echo form_fieldset('Search By:'); ?> 
                
            <div class="well well-lg">
          <div class="row">    
 
               
             <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
               
                 <div class="input-group">
                  <ul class="list-group">
                    <li class="list-group-item">
                            <input type="radio" name="dash_search_by"  
                            value="auth_id" id="search_auth_id" checked="checked"  /> 
                            <label for="search_auth_id">Auth ID</label>
                    </li>
                    <li class="list-group-item">
                            <input type="radio" name="dash_search_by"  
                            value="app_name" id="search_name"   />
                            <label for="search_name">Card Holder</label>
                    </li>
                    <li class="list-group-item">
                            <input type="radio" name="dash_search_by"
                            value="app_date" id="search_date" />
                            <label for="search_date">Dates</label>
                    </li>
                    <li class="list-group-item">
                            <input type="radio" name="dash_search_by" 
                            value="ref_id" id="search_ref_id"  />
                            <label for="search_ref_id">Ref ID</label>
                    </li>
                  </ul>
                </div> 
            </div> 
              
              
              
         
       <div id="by_a">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                 <label for="auth_id">Auth ID</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                <input type="text" class="form-control" 
                       name="auth_id" id="auth_id" value=""/> 
                <span class="input-group-addon"></span>             
                </div>  
            </div>
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"></div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="order_column">Sort By</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                <?php $selected = array(set_value('order_column')?set_value('order_column'):'ID');
                      echo form_dropdown('order_column', $Fields, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
                </div>
            </div>
           <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                <div class="input-group">
                <label for="order_type">Sort Direction</label><br>
                 <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <input type="radio" name="order_type" 
                            value="asc" <?php echo  set_radio('order_type', 'asc', TRUE, $radclass ); ?> /> Ascending
                    <input type="radio" name="order_type"
                           value="desc" <?php echo  set_radio('order_type', 'desc', $radclass ); ?> /> Descending
                </div>  
                </div>
            </div> 
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"></div>
      </div>    
              
      <div id="by_n" style="display:none;">  
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="card_holder_name">Card Holder Name</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                <input type="text" class="form-control" 
                       name="card_holder_name" id="card_holder_name" value=""/> 
                <span class="input-group-addon"></span>       
                </div>
            </div>
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"></div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="order_column">Sort By</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                <?php $selected = array(set_value('order_column')?set_value('order_column'):'ID');
                      echo form_dropdown('order_column', $Fields, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
                </div>
            </div>
           <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                <div class="input-group">
                <label for="order_type">Sort Direction</label><br>
                 <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <input type="radio" name="order_type" 
                            value="asc" <?php echo  set_radio('order_type', 'asc', TRUE, $radclass ); ?> /> Ascending
                    <input type="radio" name="order_type"
                           value="desc" <?php echo  set_radio('order_type', 'desc', $radclass ); ?> /> Descending
                </div>  
                </div>
            </div> 
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"></div>
      </div>  
         
      <div id="by_p" style="display:none;"> 
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                 <label for="app_sdate">From Date</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                <input type="text" class="form-control" style="ui-datepicker-week-end: #fff;" 
                       name="app_sdate" id="app_sdate" value=""/> 
                <span class="input-group-addon"></span>             
                </div>
            </div>
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-2"></div>
      
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                 <label for="app_todate">To Date</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                <input type="text" class="form-control" 
                       name="app_todate" id="app_todate" value=""/> 
                <span class="input-group-addon"></span>             
                </div>
            </div>
          
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="order_column">Sort By</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                <?php $selected = array(set_value('order_column')?set_value('order_column'):'ID');
                      echo form_dropdown('order_column', $Fields, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
                </div>
            </div>
           <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                <div class="input-group">
                <label for="order_type">Sort Direction</label><br>
                 <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <input type="radio" name="order_type" 
                            value="asc" <?php echo  set_radio('order_type', 'asc', TRUE, $radclass ); ?> /> Ascending
                    <input type="radio" name="order_type"
                           value="desc" <?php echo  set_radio('order_type', 'desc', $radclass ); ?> /> Descending
                </div>  
                </div>
            </div> 
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"></div>
      </div>        
              
              
              
      <div id="by_i" style="display:none;">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                 <label for="ref_id">Ref ID</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                <input type="text" class="form-control" 
                       name="ref_id" id="ref_id" value=""/> 
                <span class="input-group-addon"></span>             
                </div>
            </div>
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"></div>
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="order_column">Sort By</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                <?php $selected = array(set_value('order_column')?set_value('order_column'):'ID');
                      echo form_dropdown('order_column', $Fields, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
                </div>
            </div>
           <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                <div class="input-group">
                <label for="order_type">Sort Direction</label><br>
                 <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <input type="radio" name="order_type" 
                            value="asc" <?php echo  set_radio('order_type', 'asc', TRUE, $radclass ); ?> /> Ascending
                    <input type="radio" name="order_type"
                           value="desc" <?php echo  set_radio('order_type', 'desc', $radclass ); ?> /> Descending
                </div>  
                </div>
            </div> 
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"></div>
      </div> 
    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-2">
                <label for="submit_search_fn"> </label><br> 
            <?php echo form_submit('submit_search_fn','Search', array('class' => 'pull-left btn btn-primary' ) );  ?>
            </div>
              <?php  
                    echo form_close(); 
            //*************************************  End Form    **************************************************************
            ?>
              </div>
          </div>
         

                            
            
                    </div> <!-- List-Group-->
                </div>
            </div><!-- jarviswidget -->
    </article>
      
 

     
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
        <div class="list-group">

        <div class="jarviswidget" >
                    <header>
                            <h2> Quick Search </h2>
                           
                    </header>

        

        <?php if( $auth_level >= 6 ) { ?>
            <form action="show_report" method="post" name="transReports" id="transReports" autocomplete="off">
                    <div class="padding-gutter">           
                        <div class="list-group">
                                
                                 
                    <ul class="list-group">
                         <li class="list-group-item">
                             <input type="radio" name="side_search_by"  id="last7days" value="trans_7_days" />
                             <label for="last7days">Last 7 Days Transactions</label>
                         </li>
                         <li class="list-group-item">
                             <input type="radio" name="side_search_by"  id="last30days" value="trans_30_days" /> 
                             <label for="last30days">Last 30 Days Transactions</label>
                         </li>
                         <li class="list-group-item">
                             <input type="radio" name="side_search_by" id="thismonth" value="trans_this_month" />
                             <label for="thismonth">This Month</label> 
                         </li>
                         <li class="list-group-item">
                             <input type="radio" name="side_search_by" id="lastmonth" value="trans_last_month" />
                             <label for="lastmonth">Last Month</label> 
                         </li>
                         <li class="list-group-item">
                             <input type="radio" name="side_search_by" id="last30approvals" value="last_30_approvals" />
                             <label for="last30approvals">Last 30 Approvals</label>
                         </li>
                         <li class="list-group-item">
                             <input type="radio" name="side_search_by" id="last30denials" value="last_30_denials" />
                             <label for="last30denials">Last 30 Denials</label>
                         </li>
                         
                     </ul>
                                  
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-2">
                <label for="submit_search_fn"> </label><br> 
            <?php echo form_submit('submit_search_fn','Search', array('class' => 'pull-left btn btn-primary' ) );  ?>
            </div>
              <?php  
                    echo form_close(); 
            //*************************************  End Form    **************************************************************
            ?>
                    </div>
         <?php 
              }  
            ?>

    </div>
       
        </div>
</article>
   
   
                                
                     
                </section>
        </div>
</div>
<!-- END MAIN PANEL -->

<script type="text/javascript">
$(function() {
    $("#search_id").focus();
    $("#app_phone").mask("(999) 999-9999");
    $("#app_primary_ssn").mask("999-99-9999");
    $( "tr:odd" ).css( "background-color", "#bbbbff" );
    $("tr").not(':first').hover(
  function () {
    $(this).css("background","#3074ae");
    $(this).css("color", "#ffffff");
  }, 
  function () {
    $(this).css("background","");
    $( "tr:odd" ).css( "background-color", "#bbbbff" );
    $(this).css("color", "#000000");

  }
);
    
});


 function HideContent(d) {
    document.getElementById(d).style.display = "none";
    }
    function ShowContent(d) {
    document.getElementById(d).style.display = "block";
    }
    function ReverseDisplay(d) {
    if(document.getElementById(d).style.display == "none") { document.getElementById(d).style.display = "block"; }
    else { document.getElementById(d).style.display = "none"; }
    }
</script>
<script type=text/javascript>
$(function() {
  

    
    $( "#app_sdate" ).datepicker({ dateFormat: 'yy-mm-dd' });
    $( "#app_todate" ).datepicker({ dateFormat: 'yy-mm-dd' });
    
   
  });
  </script>