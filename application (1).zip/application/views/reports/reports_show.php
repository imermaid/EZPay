<?php
if(isset($cli_rec)): foreach ($cli_rec as $r): 
   $client_id     = $r->client_id; 
   $client_name   = $r->client_name; 
endforeach;
endif;

// if start an end present, build gat statement to pass bact to pdf_creator

if(isset($start) && isset($end)){
    $params = '?start='.$start.'&end='.$end;
}elseif(isset($tbl) && isset($fld) && isset($val)) {
    $params = '?tbl='.$tbl.'&fld='.$fld.'&val='.$val;
}elseif(isset($tbln) && isset($fldn) && isset($valn)) {
    $params = '?tbln='.$tbln.'&fldn='.$fldn.'&valn='.$valn;
}
?>





<!-- MAIN PANEL -->
<div id="main" role="main">

        <!-- RIBBON -->
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>View</li>
                </ol>
        </div>
        <!-- MAIN CONTENT -->
        <div id="content">

                <div class="row">

                        <!-- col -->
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube"></i> <?php echo $client_name; ?>
                                    <span>> reports </span></h1>
                        </div>
                </div>
 
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-112">  
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h1><?php echo $headline; ?></h1>
                </div>  
        
                <div class="panel-body">                   
                    <div class="well well-lg"> 
                       <div class="pagination pagination-lg">
                            <?php echo $pagination; ?>
                        </div> 
                        <div class="data">
                            <?php echo $table; ?>
                        </div> 
                        <div class="paging">
                            <?php echo $pagination; ?>
                        </div> <br /> 
                       
                    </div>                    
                
                
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3 margin-bottom-10 margin-top-5">
                    
                   <?php 
                   // this will determine which pdf method to use, based on the $pdf_type passed from the reports controller
                   $pdf_page = 'reports/pdf_creator/'.$params;    ?>
                    <a href="<?php echo secure_site_url($pdf_page); ?>">      
                                            <button type="button" class="btn btn-primary">
                                            <span>PDF Version</span>
                                            </button>
                                        </a>
                </div>
                
<!--This is the Google chart div-->
                     <div id="chart_div"></div>
                    
                    
                </div> 
             
             </div>
          <?php 
          $timecnt = (! empty($timecnt) ? $timecnt : 30);
          // Google data for the chart below
          $dataset[] = '';  // declare the array first
          for($i = 1; $i<=$timecnt; $i++){   // loop thru as many times as there are days passed in with the $timecnt
              $dataset[] = ' ['.$i.', '.$cntTrans[$i][$i].'], ';  // had to make it a multidim associative  to line up with the right day. $i == the day of the month
          }
            ?>
        
        
    </article>
   </div>
             
    </div>
        <!-- END MAIN CONTENT -->

</div>
<!-- END MAIN PANEL -->


 <!--Load the AJAX API-->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

      google.charts.load('current', {packages: ['corechart', 'line']});
      google.charts.setOnLoadCallback(drawChart);
//      google.charts.setOnLoadCallback(drawAxisTickColors);

      // Callback that creates and populates a data table,
      // instantiates the pie chart, passes in the data and
      // draws it.
//      function drawAxisTickColors() {
          function drawChart() {
      var data = new google.visualization.DataTable();
      data.addColumn('number', 'Day');
      data.addColumn('number', 'Transactions');
      
      data.addRows([
        <?php for($i = 1; $i<=$timecnt; $i++){
              echo $dataset[$i];
          }?>
      ]);

      var options = {
        hAxis: {
          title: 'Timeframe',
          textStyle: {
            color: '#01579b',
            fontSize: 20,
            fontName: 'Arial',
            bold: true,
            italic: true
          },
          titleTextStyle: {
            color: '#01579b',
            fontSize: 16,
            fontName: 'Arial',
            bold: false,
            italic: true
          }
        },
        vAxis: {
          title: 'Transactions',
          textStyle: {
            color: '#1a237e',
            fontSize: 24,
            bold: true
          },
          titleTextStyle: {
            color: '#1a237e',
            fontSize: 24,
            bold: true
          }
        },
        colors: ['#a52714', '#097138']
      };
      var chart = new google.charts.Line(document.getElementById('chart_div'));
//      var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
      chart.draw(data, options);
    }
    </script>