<?php
if(isset($cli_rec)): foreach ($cli_rec as $r): 
   $client_id     = $r->client_id; 
   $client_name   = $r->client_name; 
endforeach;
endif;

// if start an end present, build gat statement to pass bact to pdf_creator

if(isset($start) && isset($end)){
    $params = '?start='.$start.'&end='.$end;
}elseif(isset($tbl) && isset($fld) && isset($val)) {
    $params = '?tbl='.$tbl.'&fld='.$fld.'&val='.$val;
}elseif(isset($tbln) && isset($fldn) && isset($valn)) {
    $params = '?tbln='.$tbln.'&fldn='.$fldn.'&valn='.$valn;
}
?>





<!-- MAIN PANEL -->
<div id="main" role="main">

        <!-- RIBBON -->
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>View</li>
                </ol>
        </div>
        <!-- MAIN CONTENT -->
        <div id="content">

                <div class="row">

                        <!-- col -->
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube"></i> <?php echo $client_name; ?>
                                    <span>> Search By Reports </span></h1>
                        </div>
                </div>
 
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-112">  
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h1><?php echo $headline; ?></h1>
                </div>  
        
                <div class="panel-body">                   
                    <div class="well well-lg"> 
                       <div class="pagination pagination-lg">
                            <?php echo $pagination; ?>
                        </div> 
                        <div class="data">
                            <?php echo $table; ?>
                        </div> 
                        <div class="paging">
                            <?php echo $pagination; ?>
                        </div> <br /> 
                       
                    </div>                    
                
                
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3 margin-bottom-10 margin-top-5">
                    
                   <?php 
                   // this will determine which pdf method to use, based on the $pdf_type passed from the reports controller
                   $pdf_page = 'reports/pdf_creator/'.$params;    ?>
                    <a href="<?php echo secure_site_url($pdf_page); ?>">      
                                            <button type="button" class="btn btn-primary">
                                            <span>PDF Version</span>
                                            </button>
                                        </a>
                </div>
  
                </div> 
             
             </div>

    </article>
   </div>
             
    </div>
        <!-- END MAIN CONTENT -->

</div>
<!-- END MAIN PANEL -->
