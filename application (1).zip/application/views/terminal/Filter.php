<?php

class Filter
{
    public function __construct()
    {
        
    }
    
    public function filter_input($data)
    {
        $result = strip_tags($data);
        $result = stripslashes($result);
        return $result; 
    }
}
