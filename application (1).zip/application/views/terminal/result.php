<?php
    require("Filter.php");
    
    $filter = new Filter();
    
 /*   $soap = new SoapClient("http://ezpay.host/Pegasys/PegasysAPI/wsdl.wsdl");
    
    $card_type = $_POST["card_type"];
    $card_num = $filter->filter_input($_POST["card_num"]);
    $payment = $filter->filter_input($_POST["payment"]);
    $ccv = $filter->filter_input($_POST["ccv"]);
    $name = $filter->filter_input($_POST["name"]);
    $addr = $filter->filter_input($_POST["address"]);
    $cust_id = $filter->filter_input($_POST["cust_id"]);
    $payment_type = "Sale";
    $expiration = $filter->filter_input($_POST["exp_date"]);
    $username = $_POST["api_key"];
    $password = $_POST["api_pass"]; */
    
   // $resp = $soap->processCreditCard($username, $password, $payment_type, $card_num, $card_type, $payment, $expiration);
    //var_dump($result);
?>
<div id="main" role="main" style="overflow: scroll;">
    <div id="ribbon">
        <div class="breadcrumb">
            <ol class="breadcrumb">
                <li><a href='.<? base_url(); ?>.'>Dashboard</a></li><li>Virtual Terminal</li><li>Payment Info.</li>
            </ol>
        </div>
    </div>
    <!-- Main Content -->
    <div id="content">
        <section id="widget-grid" class="">
            <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">  
                <span  id="logo">
                    <a href=' .<? base_url();?>. '><img src="/assets/img/pagasys.png" alt="Pagasys" width="150"></a> 
                </span>
                <?php echo $headline; ?>
                <div class="padding-gutter">
                            <div class="col-xs-12 col-sm-12 col-md-7 col-lg-6">  
            <div class="well">
                <div class="row">
                    <label id="status">Status:&nbsp;<?php echo $status; ?></label>
                </div>
                <div class="row">
                    <label id="auth">Authorization:&nbsp;<?php echo $auth; ?></label>
                </div>
                <div class="row">
                    <label id="ref">Reference ID:&nbsp;<?php echo $refId; ?></label>
                </div>
            </div>
        </div>
                </div>
            </article>
        </section>
    </div>
</div>

