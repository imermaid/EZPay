<?php 
       /// $this->passdb = $this->auth_client_id; // This passes the client id to the dropdown helper to call the dynamic dropdowns from the correct databases
        //$this->db2use = $this->load->database($this->auth_client_id, true);
        //$query = $this->db2use->query("SELECT API_KEY, API_PASS FROM pagasys_api");
        //$key = $query->result()[0]->API_KEY;
        //$pass = $query->result()[1]->API_PASS;
$key = "";
$pass = "";
?>

<div id="main" role="main" style="overflow: scroll;">
    <div id="ribbon">
        <div class="breadcrumb">
            <ol class="breadcrumb">
                <li><a href='.<? base_url(); ?>.'>Dashboard</a></li><li>Virtual Terminal</li><li>Card Payment</li>
            </ol>
        </div>
    </div>
    <!-- Main Content -->
    <div id="content"> 
        <section id="widget-grid" class="">
            <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <span  id="logo">
                    <a href=' .<? base_url();?>. '><img src="/assets/img/pagasys.png" alt="Pagasys" width="150"></a> 
                </span>
                <?php echo $headline; ?>
                <div class="padding-gutter">
                    <div class="col-xs-12 col-sm-12 col-md-7 col-lg-6">  
                        <div class="well">
                            <form id="card_payment" name="card_payment" class="form form-horizontal" method="post" 
                                  style="font-size:9pt; margin-top:10px; margin-left:5px;" action="process">
                                <input type="hidden" id="api_key" name="api_key" value="<?php echo $api_key; ?>">
                                <input type="hidden" id="api_pass" name="api_pass" value="<?php echo $pass; ?>">
                                <div class="form-group">
                                    <label class="col-md-4 control-label" for="payment">Payment Amount:*</label> 
                                    <div class="col-md-7">
                                        <input type="text" id="payment" name="payment" class="form-control">
                                    </div>  
                                </div>
                                <div class="form-group FontComic">
                                    <label class="col-md-4 control-label" for="type">Card Type:*</label>
                                    <div class="col-md-7">
                                        <select id="type" name="type" class="form-control">
                                            <option value="VISA">Visa</option>
                                            <option value="MC">Master Card</option>
                                            <option value="DISC">Discover</option>
                                            <option value="AE">American Express</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="card_num">Card Number:*</label>
                                    <div class="col-md-7">
                                        <input type="text" id="card_num" name="card_num" class="form-control" maxlength="16">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="exp">Expiration Date:</label>
                                    <div class="col-md-7">
                                        <input type="date" id="exp" name="exp" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="ccv">Security Code:*</label>
                                    <div class="col-md-7">
                                        <input type="text" id="ccv" name="ccv" class="form-control" maxlength="6">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="name">Name on Card:*</label>
                                    <div class="col-md-7">
                                        <input type="text" id="name" name="name" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="cust_id">Customer ID:*</label>
                                    <div class="col-md-7">
                                        <input type="text" id="cust_id" name="cust_id" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="address">Address:</label>
                                    <div class="col-md-7">
                                        <input type="text" id="address" name="address" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="city">City:</label>
                                    <div class="col-md-7">
                                        <input type="text" id="city" name="city" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="state">State:</label>
                                    <div class="col-md-7">
                                     <?php   
                                     echo form_dropdown('state', $States, '', array('class' => 'form-control'));  
                                     ?>
                                    </div>
                                </div>
                                
                               
                                <div class="form-group">
                                    <label class="control-label col-md-4">Zip Code:*</label>
                                    <div class="col-md-7">
                                        <input type="text" id="zip" name="zip" maxlength="5" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4">Email:</label>
                                    <div class="col-md-7">
                                        <input type="email" id="email" name="email" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4">&nbsp;</label>
                                    <div class="col-md-7">
                                        <input type="submit" class="btn btn-info col-md-4 col-md-offset-8" id="submit" name="submit" value="Process">
                                    </div>
                                </div>
                            </form>
                            <br>
                        </div>
                    </div>
                </div>
            </article>
        </section>
    </div>
</div>
