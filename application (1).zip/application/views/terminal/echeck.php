<?php ?>

<div id="main" role="main">
    <div id="ribbon">
        <div class="breadcrumb">
            <ol class="breadcrumb">
                <li><a href='.<? base_url(); ?>.'>Dashboard</a></li><li>Virtual Terminal</li><li>e-check Payment</li>
            </ol>
        </div>
    </div>
    <!-- Main Content -->
    <div id="content">
        <section id="widget-grid" class="">
            <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">  
                <span  id="logo">
                    <a href=' .<? base_url();?>. '><img src="/assets/img/pagasys.png" alt="Pagasys" width="150"></a> 
                </span>
                <?php echo $headline; ?>
                <div class="padding-gutter">
                    <div class="col-xs-12 col-sm-12 col-md-7 col-lg-6"> 
                        <div class="well" style="background-color:#bdd1ae"> 
                            <form id="echeck" name="echeck" class="form form-horizontal" method="post" style="font-size:9pt;" action="processCheck">
                                <div class="form-group"> 
                                    <label class="col-md-3 control-label" for="payment">Payment Amount:*</label>
                                    <div class="col-md-7">
                                        <input type="text" id="payment" name="payment" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3" for="card_num">Bank Name:*</label>
                                    <div class="col-md-7">
                                        <input type="text" id="bank" name="bank" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3" for="ccv">Routing Number:*</label>
                                    <div class="col-md-7">
                                        <input type="text" id="routing" name="routing" class="form-control" maxlength="9">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3" for="account">Account Number:*</label>
                                    <div class="col-md-7">
                                        <input type="text" id="account" name="account" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3" for="cust_id">Customer ID:</label>
                                    <div class="col-md-7">
                                        <input type="text" id="cust_id" name="cust_id" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3" for="account">Name:*</label>
                                    <div class="col-md-7">
                                        <input type="text" id="name" name="name" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3" for="address">Address:</label>
                                    <div class="col-md-7">
                                        <input type="text" id="address" name="address" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3" for="city">City:</label>
                                    <div class="col-md-7">
                                        <input type="text" id="city" name="city" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3" for="city">State:</label>
                                    <div class="col-md-7">
                                        <?php
                                        echo form_dropdown('state', $States, '', array('class' => 'form-control'));
                                        ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-3">Zip Code:</label>
                                    <div class="col-md-7">
                                        <input type="text" id="zip1" name="zip1" maxlength="5" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">&nbsp;</label>
                                    <div class="col-md-7">
                                        <input type="submit" class="btn btn-info col-md-4 col-md-offset-8" id="submit" name="submit" value="Process">
                                    </div>
                                </div>
                            </form>
                            <br>
                        </div>
                    </div>
                </div>
            </article>
        </section>
    </div>
</div>
