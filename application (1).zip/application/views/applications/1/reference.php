<?php

/* 
 * Default Coborrower Application
 * Steve Thomas
 * 12/26/2015
 * This is the default application for a client. It only collects personal info and address on co-borrower.
 */

// get the client var's that are used in this page
if(isset($cli_rec)): 
    foreach ($cli_rec as $r): 
      $clientID    = $r->client_id;
   $client_name    = $r->client_name; 
    endforeach;
endif;
$RefApplID = ($RefApplID) ? $RefApplID : '';
if($RefApplID > 0) {
 $r1_relation = $Ref_Record->ref1_relation;
     $r1_name = $Ref_Record->ref1_fname. " " .$Ref_Record->ref1_lname;
    $r1_phone = $Ref_Record->ref1_phone;
    
 $r2_relation = $Ref_Record->ref2_relation;
     $r2_name = $Ref_Record->ref2_fname. " " .$Ref_Record->ref2_lname;
    $r2_phone = $Ref_Record->ref2_phone;
    
 $r3_relation = $Ref_Record->ref3_relation;
     $r3_name = $Ref_Record->ref3_fname. " " .$Ref_Record->ref3_lname;
    $r3_phone = $Ref_Record->ref3_phone;
}
?>

<script type="text/javascript" language="JavaScript">
$(function() {
    $("#ref1_fname").focus();

  });
jQuery(function($){
    $("#ref1_phone").mask("(999) 999-9999");
    $("#ref2_phone").mask("(999) 999-9999");
    $("#ref3_phone").mask("(999) 999-9999");
});

</script>

<div id="main" data-role="page">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>Apply for Loan</li>
                </ol>
        </div>
        <div id="content">
            
                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-8">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube txt-color-blue"></i> <?php echo $client_name; ?>
                                    <span>> Loan Application </span></h1>
                        </div>
      <?php
      // This is the forms navigation
     include 'nav_forms.php';

            if($NewApplID == '') {
                $panel_color = "panel panel-default";
            }else if($RefApplID > 0) {
                $panel_color = "panel panel-success";
            }else {
                $panel_color = "panel panel-primary";
            }
            echo '</div><br>';
            
            
            // if already has application ID, show data not form
            if(isset($Ref_Record))
            {
?>
            <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-11">              
        
     <div class="<?php echo $panel_color; ?>">
      <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
      </div>  
          <div class="panel-body">                                                                 
        <div class="content">
            
             <div class="well well-lg">  
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Reference 1 Name: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $r1_name; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Reference 1 Phone: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $r1_phone; ?>
               </div>
           </div> 
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Reference 1 relation: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $r1_relation; ?>
               </div>
           </div>
        </div>
              
              
          <div class="well well-lg">  
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Reference 2 Name: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $r2_name; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Reference 2 Phone: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $r2_phone; ?>
               </div>
           </div> 
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Reference 2 relation: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $r2_relation; ?>
               </div>
           </div>
          </div>
              
              
         <div class="well well-lg">   
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Reference 3 Name: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $r3_name; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Reference 3 Phone: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $r3_phone; ?>
               </div>
           </div> 
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Reference 3 relation: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $r3_relation; ?>
               </div>
           </div>
         </div> 
            
            
            
           
            
           
            
            
            
            
            
        </div>
          </div>
     </div>
    </article>
            </div>
                    
                     <?php
            } else {
            ?>    
                
                
       
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-11">              
        
     <div class="<?php echo $panel_color; ?>">
      <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
      </div>  
          <div class="panel-body">                                                                 
        <div class="content">

             <?php 
             //*********************   Start Form   *****************************************
                    echo validation_errors(); 
                    $attributes = array('role' => 'form', 'id' => 'form_ref');
                    echo form_open($action, $attributes); 
                    echo form_hidden('client_id', $clientID); 
                    $NID = ($NewApplID > 0) ? $NewApplID : '';
                    echo form_hidden('NewApplID', $NID); 
                    echo form_hidden('app_id', $NID);
                    echo form_hidden('EmpApplID', $EmpApplID);
                    echo form_hidden('CoApplID', $CoApplID);
                    ?>
                    
         <?php
      $showrow = (!empty($NewApplID)) ? 'block;' : 'none;';   
         ?>
            <div class="well well-lg" style="display: <?php echo $showrow;?>">
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                <label for="app_id">Application #</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                    <input type="text" name="app_id" class="form-control" disabled="disabled"
                       value="<?php echo $NID ?>"/>
                <span class="input-group-addon"></span>
                </div>
            </div>     
            </div><!-- // end row -->
            </div>
            <div class="well well-lg">
              <?php echo form_fieldset('Reference One Information'); ?>  
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref1_fname">First Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                    <input type="text" name="ref1_fname" id="ref1_fname" class="form-control"
                       value="<?php echo (set_value('ref1_fname')); ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref1_lname">Last Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref1_lname" class="form-control" 
                       value="<?php echo (set_value('ref1_lname')); ?>"/> 
                <span class="input-group-addon"></span>                 
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref1_phone">Primary Phone<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                    <input type="tel" name="ref1_phone" class="form-control" id="ref1_phone"
                       value="<?php echo set_value('ref1_phone'); ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref1_relation">Relationship</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                <?php $selected = array(set_value('ref1_relation')?set_value('ref1_relation'):'Family Member');
                      echo form_dropdown('ref1_relation', $Ref_Relation, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>    
                
            </div><!-- // end reference one row -->
            
            <?php echo form_fieldset_close();
            echo '</div>';
         //***************************************************************************************************************   
            ?>
            <div class="well well-lg">
             <?php echo form_fieldset('Reference Two Information'); ?>   
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref2_fname">First Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref2_fname" class="form-control"
                       value="<?php echo (set_value('ref2_fname')); ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref2_lname">Last Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref2_lname" class="form-control" 
                       value="<?php echo (set_value('ref2_lname')); ?>"/> 
                <span class="input-group-addon"></span>                  
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref2_phone">Primary Phone<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                    <input type="tel" name="ref2_phone" class="form-control" id="ref2_phone"
                       value="<?php echo set_value('ref2_phone'); ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref2_relation">Relationship</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                <?php $selected = array(set_value('ref2_relation')?set_value('ref2_relation'):'Family Member');
                      echo form_dropdown('ref2_relation', $Ref_Relation, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
               
            </div><!-- // end reference two row -->
          <?php echo form_fieldset_close(); 
          echo '</div>';
        //********************************************************************************************************************    
            ?> 
            <div class="well well-lg">
            <?php echo form_fieldset('Reference Three Information'); ?>    
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref3_fname">First Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref3_fname" class="form-control"
                       value="<?php echo (set_value('ref3_fname')); ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref3_lname">Last Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref3_lname" class="form-control" 
                       value="<?php echo (set_value('ref3_lname')); ?>"/> 
                <span class="input-group-addon"></span>               
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref3_phone">Primary Phone<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                    <input type="tel" name="ref3_phone" class="form-control" id="ref3_phone"
                       value="<?php echo set_value('ref3_phone'); ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref3_relation">Relationship</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                <?php $selected = array(set_value('ref3_relation')?set_value('ref3_relation'):'Family Member');
                      echo form_dropdown('ref3_relation', $Ref_Relation, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
             
            </div><!-- // end reference three row -->
            <?php echo form_fieldset_close(); 
            echo '</div>';
            //*************************************************************************************************************
            ?>   
             <div class="well well-lg">
            <div class="row">    
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <?php 
                if($NewApplID == '') { //if the references has been saved, show data but remove submit button so user doesn't keep submitting.
                    echo form_submit('submit_ref','Disabled', array('class' => 'pull-left btn btn-default', 'disabled' => 'disabled' ) );
                }else if($RefApplID > 0) {
                    echo form_submit('submit_ref','Disabled', array('class' => 'pull-left btn btn-danger', 'disabled' => 'disabled' ) );
                } else { 
                    echo form_submit('submit_ref','Save References', array('class' => 'pull-left btn btn-primary' ) ); 
                }
                ?>
                </div>
                 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">   
                <?php echo form_reset('reset_ref','Reset', array('class' => 'pull-right' ) ); ?>
                 </div>
            </div>
             </div>
            <?php echo form_close(); 
            //*************************************  End Form    **************************************************************
            ?>
                    </div>
            </div>
        </div><!-- END Panel -->
    </article>
   </div>
              <?php
            } // end if to show form instead of data saved
            ?>
        </div><!-- END MAIN CONTENT -->
      
</div><!-- END MAIN -->



