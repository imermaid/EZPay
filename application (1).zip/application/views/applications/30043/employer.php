<?php

/* 
 * Default Coborrower Application
 * Steve Thomas
 * 12/26/2015
 * This is the default application for a client. It only collects personal info and address on co-borrower.
 */

// get the client var's that are used in this page
if(isset($cli_rec)): 
    foreach ($cli_rec as $r): 
      $clientID    = $r->client_id;
   $client_name    = $r->client_name; 
    endforeach;
endif;

if($EmpApplID) {
    $company_name = $Emp_Record->emp_company;
      $supervisor = $Emp_Record->emp_phone;
           $phone = $Emp_Record->emp_phone;
        $position = $Emp_Record->emp_position;
        $hiredate = $Emp_Record->emp_hiredate;
            $type = $Emp_Record->emp_type;
       $frequency = $Emp_Record->emp_frequency;
     $next_payday = $Emp_Record->emp_next_payday;
      $first_semi = $Emp_Record->emp_semi_first;
     $second_semi = $Emp_Record->emp_semi_second;
   $annual_salary = $Emp_Record->emp_annual_salary;
           $other = "Other Source: " .$Emp_Record->emp_other_source. " Amount: " .$Emp_Record->emp_other_amount. " Frequency: " .$Emp_Record->emp_other_frequency;
         $address = $Emp_Record->emp_address;
            $unit = $Emp_Record->emp_unit;
             $stz = $Emp_Record->emp_city. " " .$Emp_Record->emp_state. ", " .$Emp_Record->emp_zipcode;
             $url = $Emp_Record->emp_url;
  $direct_deposit = $Emp_Record->emp_direct_deposit;

}

?>


<script type="text/javascript" language="JavaScript">
$(function() {
   
    $("#emp_annual_salary").focus();
     
    $( "#emp_hiredate" ).datepicker({ 
             maxDate: "+1D"

    });
 
    $( "#emp_next_payday" ).datepicker({ 
            minDate: 0,
            maxDate: "+1M +5D"
    });
    $( "#emp_semi_first" ).datepicker({ 
            minDate: "-1M",
            maxDate: "+1M" 
    });
    $( "#emp_semi_second" ).datepicker({ 
            minDate: 0,
            maxDate: "+1M +5D" 
    });
    
    $('#emp_frequency').change(function(){
        if($('#emp_frequency').val() === 'Semi-Monthly'){
            $('#nextPayday').val('');
            $('#nextPayday').hide();
            $('#semiDates').show();
        } else if ($('#emp_frequency').val() !== 'Semi-Monthly') {
            $('#semiDates').val('');
            $('#semiDates').hide();
            $('#nextPayday').show();
    }
    });

  });

jQuery(function($){
   $("#emp_next_payday").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#emp_semi_first").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#emp_semi_second").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#emp_phone").mask("(999) 999-9999");

});

 function HideContent(d) {
    document.getElementById(d).style.display = "none";
    }
    function ShowContent(d) {
    document.getElementById(d).style.display = "block";
    }
    function ReverseDisplay(d) {
    if(document.getElementById(d).style.display == "none") { document.getElementById(d).style.display = "block"; }
    else { document.getElementById(d).style.display = "none"; }
    }
</script>

<div id="main" data-role="page">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>Apply for Loan</li>
                </ol>
        </div>
        <div id="content">
            
                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-8">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube txt-color-blue"></i> <?php echo $client_name; ?>
                                    <span>> Loan Application </span></h1>
                        </div>
<?php
      // This is the forms navigation
     include 'nav_forms.php';

            if($NewApplID == '') {
                $panel_color = "panel panel-default";
            }else if($EmpApplID > 0) {
                $panel_color = "panel panel-success";
            }else {
                $panel_color = "panel panel-primary";
            }
            echo '</div><br>';
            
            
            // if already has application ID, show data not form
            if(isset($Emp_Record))
            {
?>
            <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-11">              
        
     <div class="<?php echo $panel_color; ?>">
      <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
      </div>  
          <div class="panel-body">                                                                 
        <div class="content">
            
            <div class="well well-lg">
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Company Name: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $company_name; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Phone: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $phone; ?>
               </div>
           </div> 
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Supervisor: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $supervisor; ?>
               </div>
           </div>
            </div>
            
            
            <div class="well well-lg">
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Position: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $position; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Hire Date: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $hiredate; ?>
               </div>
           </div> 
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Employment Type: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $type; ?>
               </div>
           </div>
            </div>
            
            
            <div class="well well-lg">
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Pay Cycle: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $frequency; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Next Payday: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $next_payday; ?>
               </div>
           </div> 
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>First Semi Date: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $first_semi; ?>
               </div>
           </div>
                <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Second Semi Date: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $second_semi; ?>
               </div>
           </div>
                <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Annual Salary: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $annual_salary; ?>
               </div>
           </div>
                <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Other Income: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $other; ?>
               </div>
           </div>
            </div>
            
            
             <div class="well well-lg">
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Address: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $address; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Unit: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $unit; ?>
               </div>
           </div> 
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>City State Zipcode: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $stz; ?>
               </div>
           </div>
                 <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>URL: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $url; ?>
               </div>
           </div>
                 <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Direct Deposit: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $direct_deposit; ?>
               </div>
           </div>
            </div>
            
            
            
                
        </div>
          </div>
     </div>
    </article>
            </div>
                    
                     <?php
            } else {
            ?>
       
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-11">              
        
     <div class="<?php echo $panel_color; ?>">
      <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
      </div>  
          <div class="panel-body">                                                                 
        <div class="content">

             <?php 
             //*********************   Start Form   *****************************************
                    echo validation_errors(); 
                    $attributes = array('role' => 'form', 'id' => 'form_empl');
                    echo form_open($action, $attributes); 
                    echo form_hidden('client_id', $clientID); 
                    $NID = ($NewApplID > 0) ? $NewApplID : '';
                    echo form_hidden('NewApplID', $NID);
                    echo form_hidden('app_id', $NID);
                    echo form_hidden('RefApplID', $RefApplID);
                    echo form_hidden('CoApplID', $CoApplID);
                  ?>  
                    
            <div class="well well-lg">
            <?php echo form_fieldset('Income'); ?>   
            <div class="row">
              
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="emp_annual_salary">Annual Salary<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-dollar txt-color-blue"></i></span>
                    <input type="text" name="emp_annual_salary" id="emp_annual_salary" class="form-control"
                       value="<?php echo (set_value('emp_annual_salary')); ?>"/> 
                <span class="input-group-addon">00</span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <label for="emp_direct_deposit">Direct Deposit?<span style="color:red;">* </span></label><br>
                <div class="input-group">
                   <span class="input-group-addon"><i class="fa fa-download txt-color-blue"></i></span> 
                <select name="emp_direct_deposit" class="form-control">
                    <option value="Yes" <?php echo set_select('emp_direct_deposit', 'Yes', TRUE); ?> >Yes</option>
                    <option value="No" <?php echo set_select('emp_direct_deposit', 'No'); ?> >No</option>
                </select>
               <span class="input-group-addon"></span>
                </div>
            </div> 
        </div>
            
           <div class="row"> 
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
            
                <label for="emp_frequency">Pay Cycle<span style="color:red;">* </span></label><br>
                <div class="input-group">
                   <span class="input-group-addon"><i class="fa fa-repeat txt-color-blue"></i></span> 
                   <select name="emp_frequency" id="emp_frequency" class="form-control">
                    <option value="Weekly" <?php echo set_select('emp_frequency', 'Weekly', TRUE); ?> >Weekly</option>
                    <option value="Bi-Weekly" <?php echo set_select('emp_frequency', 'Bi-Weekly'); ?> >Bi-Weekly</option>
                    <option value="Semi-Monthly" <?php echo set_select('emp_frequency', 'Semi-Monthly'); ?> >Semi-Monthly</option>
                    <option value="Monthly" <?php echo set_select('emp_frequency', 'Monthly'); ?> >Monthly</option>
                </select>
               <span class="input-group-addon"></span>  
            </div>
            </div> 
               <?php
               $shownextpayday = ( ! empty(set_value('emp_semi_first'))) ? 'display:none;' : 'display:block;';
               $showsemipayday = ( ! empty(set_value('emp_semi_first'))) ? 'display:block;' : 'display:none;';
               ?>
               <div id="nextPayday" style="<?php echo $shownextpayday; ?>">
                      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                         <label for="emp_next_payday">Next Payday?<span style="color:red;">*</span></label><br>
                             <div class="input-group">
                               <span class="input-group-addon"><i class="fa fa-calendar txt-color-blue"></i></span>
                               <input type="text" name="emp_next_payday" id="emp_next_payday" class="form-control" 
                               value="<?php echo set_value('emp_next_payday'); ?>"/> 
                            <span class="input-group-addon"></span>
                             </div>
                        </div> 
               </div>
               <div id="semiDates" style="<?php echo $showsemipayday; ?>">
                      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                         <label for="emp_semi_first">First Pay Date<span style="color:red;">*</span></label><br>
                             <div class="input-group">
                               <span class="input-group-addon"><i class="fa fa-calendar txt-color-blue"></i></span>
                               <input type="text" name="emp_semi_first" id="emp_semi_first" class="form-control" 
                               value="<?php echo set_value('emp_semi_first'); ?>"/> 
                            <span class="input-group-addon"></span>
                             </div>
                        </div> 
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                         <label for="emp_semi_second">Second Pay Date<span style="color:red;">*</span></label><br>
                             <div class="input-group">
                               <span class="input-group-addon"><i class="fa fa-calendar txt-color-blue"></i></span>
                               <input type="text" name="emp_semi_second" id="emp_semi_second" class="form-control" 
                               value="<?php echo set_value('emp_semi_second'); ?>"/> 
                            <span class="input-group-addon"></span>
                             </div>
                        </div> 
               </div>
               
        </div>
            <?php echo form_fieldset_close(); ?>    
            </div>
            
            
   
                <div class="well well-lg">
               <?php echo form_fieldset('Employer'); ?>     
            <div class="row">   
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label for="emp_company">Employer Name<span style="color:red;">*</span></label><br> 
                          <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-star-o txt-color-blue"></i></span>
                            <input type="text" name="emp_company" class="form-control" 
                            value="<?php echo set_value('emp_company'); ?>"/> 
                            <span class="input-group-addon"></span>
                          </div>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="emp_phone">Phone<span style="color:red;">*</span></label><br>
                         <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-phone-square txt-color-blue"></i></span>
                            <input type="tel" name="emp_phone" id="emp_phone" class="form-control" 
                            value="<?php echo set_value('emp_phone'); ?>"/> 
                            <span class="input-group-addon"></span>
                         </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="emp_position">Position<span style="color:red;">*</span></label><br>
                         <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-puzzle-piece txt-color-blue"></i></span>
                            <input type="text" name="emp_position" class="form-control" 
                             value="<?php echo set_value('emp_position'); ?>"/> 
                            <span class="input-group-addon"></span>
                         </div>
                </div>
            </div>
            <div class="row">        
               <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="emp_supervisor">Supervisor<span style="color:red;">*</span></label><br>
                         <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-user txt-color-blue"></i></span>
                           <input type="text" name="emp_supervisor" class="form-control" 
                           value="<?php echo set_value('emp_supervisor'); ?>"/> 
                        <span class="input-group-addon"></span>
                         </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="emp_hiredate">Date Hired<span style="color:red;">*</span></label><br>
                         <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-calendar-times-o txt-color-blue"></i></span>
                           <input type="text" name="emp_hiredate" id="emp_hiredate" class="form-control" 
                           value="<?php echo set_value('emp_hiredate'); ?>"/> 
                        <span class="input-group-addon"></span>
                         </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <label for="emp_type">Employment Type<span style="color:red;">* </span></label><br>
                        <div class="input-group">
                             <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-check-square txt-color-blue"></i></span>
                                <?php $ty_selected = array(set_value('emp_type')?set_value('emp_type'):'Full Time');
                                      echo form_dropdown('emp_type', $ET, $ty_selected, array('class' => 'form-control'));  ?>
                                <span class="input-group-addon"></span>
                             </div>       
                        </div>
                </div>
             
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="emp_url">Employer Website</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-link txt-color-blue"></i></span>
                    <input type="text" name="emp_url" class="form-control" id="emp_url"
                       value="<?php echo set_value('emp_url'); ?>"/> 
                    <span class="input-group-addon"></span>
                </div>
            </div>
           </div>
               <?php echo form_fieldset_close(); ?>     
                </div>
                    
 
             <div class="well well-lg"> 
             <?php echo form_fieldset('Address'); ?>    
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="emp_address">Street Address<span style="color:red;">*</span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-map-signs txt-color-blue"></i></span>
                <input type="text" class="form-control" 
                       name="emp_address" value="<?php echo set_value('emp_address'); ?>"/> 
                <span class="input-group-addon"></span>
                            
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="emp_unit">Unit/Apt/Bldg</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-building-o txt-color-blue"></i></span>
                <input type="text" class="form-control" 
                       name="emp_unit" value="<?php echo set_value('emp_unit'); ?>"/> 
                <span class="input-group-addon"></span>
            </div>
            </div>
            </div> <!-- End STREET Row -->
            <div class="row"> 
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                 <label for="emp_city">City</label><br>
            <div class="input-group">
               
                <span class="input-group-addon"><i class="fa fa-map-pin txt-color-blue"></i></span>
                <input type="text" class="form-control" 
                       name="emp_city" value="<?php echo set_value('emp_city'); ?>"/> 
                <span class="input-group-addon"></span>
                                  
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="emp_state">State</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag txt-color-blue"></i></span>
                <?php $selected = array(set_value('emp_state')?set_value('emp_state'):'Georgia');
                      echo form_dropdown('emp_state', $States, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="emp_zipcode">Zipcode</label><br>
            <div class="input-group">
                <span class="input-group-addon"></span>
                <input type="text" name="emp_zipcode" class="form-control" value="<?php echo set_value('emp_zipcode'); ?>"/> 
                <span class="input-group-addon"></span>
                                   
            </div>
            </div>    
            </div><!-- // end CITY STATE ZIP row -->
            <?php echo form_fieldset_close(); ?>
             </div>
            
           
          
            
            
                 <div class="well well-lg">
             <?php echo form_fieldset('Other Income'); ?>        
             <div class="row">   
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="emp_other_source">Other Source of Income</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-money txt-color-blue"></i></span>
                <input type="text" name="emp_other_source" class="form-control" 
                       value="<?php echo (set_value('emp_other_source')); ?>"/> 
                <span class="input-group-addon"></span>
                                    
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="emp_other_amount">Amount of Other Source<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-dollar txt-color-blue"></i></span>
                <input type="text" name="emp_other_amount" class="form-control" 
                       value="<?php echo (set_value('emp_other_amount')); ?>"/> 
                <span class="input-group-addon">00</span>
                                     
            </div>
            </div>
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
            
                <label for="emp_other_frequency">Other Pay Cycle<span style="color:red;">* </span></label><br>
                <div class="input-group">
                   <span class="input-group-addon"><i class="fa fa-repeat txt-color-blue"></i></span> 
                <select name="emp_other_frequency" class="form-control">
                    <option value="Weekly" <?php echo set_select('emp_other_frequency', 'Weekly', TRUE); ?> >Weekly</option>
                    <option value="Bi-Weekly" <?php echo set_select('emp_other_frequency', 'Bi-Weekly'); ?> >Bi-Weekly</option>
                    <option value="Semi-Monthly" <?php echo set_select('emp_other_frequency', 'Semi-Monthly'); ?> >Semi-Monthly</option>
                    <option value="Monthly" <?php echo set_select('emp_other_frequency', 'Monthly'); ?> >Monthly</option>
                    <option value="Semi-Annual" <?php echo set_select('emp_other_frequency', 'Semi-Annual'); ?> >Semi-Annual</option>
                    <option value="Annual" <?php echo set_select('emp_other_frequency', 'Annual'); ?> >Annual</option>
                </select>
               <span class="input-group-addon"></span>  
            </div>
            </div>    
            
            </div><!-- // end NAME row -->
            <?php echo form_fieldset_close(); ?>
            </div>
            
            <div class="well well-lg">
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <?php
            if($NewApplID == '') { //if the references has been saved, show data but disable submit button so user doesn't keep submitting.
                 echo form_submit('submit_emp','Disabled', array('class' => 'pull-left btn btn-default', 'disabled' => 'disabled' ) );
                }else if($EmpApplID > 0) {
                    echo form_submit('submit_emp','Disabled', array('class' => 'pull-left btn btn-danger', 'disabled' => 'disabled' ) );   
                }else{
            echo form_submit('submit_emp','Save Employment Information', array('class' => 'pull-left btn btn-primary' ) ); 
                }
            ?>
            </div>
             <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">   
            <?php echo form_reset('reset_income','Reset', array('class' => 'pull-right' ) ); ?>
             </div>
            </div>
            </div>
            <?php echo form_close(); 
            //*************************************  End Form    **************************************************************
            ?>
                    </div>
            </div>
        </div><!-- END Panel -->
    </article>
   </div>
                    <?php
            } // end if so the form shows instead of the data
            ?>
        </div><!-- END MAIN CONTENT -->
      
</div><!-- END MAIN -->



