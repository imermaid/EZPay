<?php

/* 
 * Default Employers Application
 * Steve Thomas
 * 1/23/2016
 * This is the default application for a client. It only collects personal info and address on co-borrower.
 */

// get the client var's that are used in this page
if(isset($cli_rec)): 
    foreach ($cli_rec as $r): 
      $clientID    = $r->client_id;
   $client_name    = $r->client_name; 
    endforeach;
endif;

?>

<script type="text/javascript" language="JavaScript">
$(function() {
   
    $("#emp_annual_salary").focus();
     
    $( "#emp_hiredate" ).datepicker({ 
             maxDate: "+1D"

    });
 
    $( "#emp_next_payday" ).datepicker({ 
            minDate: 0,
            maxDate: "+1M +5D"
    });
    $( "#emp_semi_first" ).datepicker({ 
            minDate: "-1M",
            maxDate: "+1M" 
    });
    $( "#emp_semi_second" ).datepicker({ 
            minDate: 0,
            maxDate: "+1M +5D" 
    });
    
    $('#emp_frequency').change(function(){
        if($('#emp_frequency').val() === 'Semi-Monthly'){
            $('#nextPayday').val('');
            $('#nextPayday').hide();
            $('#semiDates').show();
        } else if ($('#emp_frequency').val() !== 'Semi-Monthly') {
            $('#semiDates').val('');
            $('#semiDates').hide();
            $('#nextPayday').show();
    }
    });

  });

jQuery(function($){
   $("#emp_next_payday").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#emp_semi_first").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#emp_semi_second").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#emp_phone").mask("(999) 999-9999");

});

</script>
<script type="text/javascript" language="JavaScript">


function HideContent(d) {
    document.getElementById(d).style.display = "none";
    }
    function ShowContent(d) {
    document.getElementById(d).style.display = "block";
    }
    function ReverseDisplay(d) {
    if(document.getElementById(d).style.display == "none") { document.getElementById(d).style.display = "block"; }
    else { document.getElementById(d).style.display = "none"; }
    }
</script>



<div id="main" data-role="page">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>Apply for Loan</li>
                </ol>
        </div>
        <div id="content">
            
                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-8">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube txt-color-blue"></i> <?php echo $client_name; ?>
                                    <span>> Employers </span></h1>
                        </div>
                </div>
        
                
                
       
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-11">              
        
     <div class="panel panel-primary">
      <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
      </div>  
          <div class="panel-body">                                                                 
        <div class="content">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2"><?php echo $link_back; ?> </div>
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2"><?php echo $link_app; ?> </div>
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2"><?php echo $link_ref; ?>  </div>
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2"><?php echo $link_emp; ?> </div>
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2"><?php echo $link_co; ?> </div>
            </div>
            
            
            <?php
if(empty($Employers)) {

             //*********************   Start Form   *****************************************
                    echo validation_errors(); 
                    $attributes = array('role' => 'form', 'id' => 'form_emp');
                    echo form_open($action, $attributes); 
                    echo form_hidden('app_id', $id);
                    echo form_hidden('emp_form', 'NEW');
                 ?>
                    

           
        <div class="well well-lg">
            <?php echo form_fieldset('Income'); ?>   
            <div class="row">
              
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="emp_annual_salary">Annual Salary<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-dollar txt-color-blue"></i></span>
                    <input type="text" name="emp_annual_salary" id="emp_annual_salary" class="form-control"
                       value="<?php echo (set_value('emp_annual_salary')); ?>"/> 
                <span class="input-group-addon">00</span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <label for="emp_direct_deposit">Direct Deposit?<span style="color:red;">* </span></label><br>
                <div class="input-group">
                   <span class="input-group-addon"><i class="fa fa-download txt-color-blue"></i></span> 
                <select name="emp_direct_deposit" class="form-control">
                    <option value="Yes" <?php echo set_select('emp_direct_deposit', 'Yes', TRUE); ?> >Yes</option>
                    <option value="No" <?php echo set_select('emp_direct_deposit', 'No'); ?> >No</option>
                </select>
               <span class="input-group-addon"></span>
                </div>
            </div> 
        </div>
            
           <div class="row"> 
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
            
                <label for="emp_frequency">Pay Cycle<span style="color:red;">* </span></label><br>
                     <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-check-square txt-color-blue"></i></span>
                        <?php $ty_selected = array(set_value('emp_frequency')?set_value('emp_frequency'):'Weekly');
                              echo form_dropdown('emp_frequency', $Cycle, $ty_selected, array('class' => 'form-control', 'id' => 'emp_frequency' ));  ?>
                        <span class="input-group-addon"></span>
                     </div> 
            </div> 
               <?php
                $show_semi_payday = (set_value('emp_frequency') === 'Semi-Monthly') ? 'display:block;' : 'display:none;';
                $show_next_payday = (set_value('emp_frequency') != 'Semi-Monthly') ? 'display:block;' : 'display:none;';
               ?>
               <div id="nextPayday" style="<?php echo $show_next_payday; ?>">
                      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                         <label for="emp_next_payday">Next Payday?<span style="color:red;">*</span></label><br>
                             <div class="input-group">
                               <span class="input-group-addon"><i class="fa fa-calendar txt-color-blue"></i></span>
                               <input type="text" name="emp_next_payday" id="emp_next_payday" class="form-control" 
                               value="<?php echo set_value('emp_next_payday'); ?>"/> 
                            <span class="input-group-addon"></span>
                             </div>
                        </div> 
               </div>
               <div id="semiDates" style="<?php echo $show_semi_payday; ?>">
                      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                         <label for="emp_semi_first">First Pay Date<span style="color:red;">*</span></label><br>
                             <div class="input-group">
                               <span class="input-group-addon"><i class="fa fa-calendar txt-color-blue"></i></span>
                               <input type="text" name="emp_semi_first" id="emp_semi_first" class="form-control" 
                               value="<?php echo set_value('emp_semi_first'); ?>"/> 
                            <span class="input-group-addon"></span>
                             </div>
                        </div> 
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                         <label for="emp_semi_second">Second Pay Date<span style="color:red;">*</span></label><br>
                             <div class="input-group">
                               <span class="input-group-addon"><i class="fa fa-calendar txt-color-blue"></i></span>
                               <input type="text" name="emp_semi_second" id="emp_semi_second" class="form-control" 
                               value="<?php echo set_value('emp_semi_second'); ?>"/> 
                            <span class="input-group-addon"></span>
                             </div>
                        </div> 
               </div>
               
        </div>
            <?php echo form_fieldset_close(); ?>    
            </div>
            
            
   
                <div class="well well-lg">
               <?php echo form_fieldset('Employer'); ?>     
            <div class="row">   
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label for="emp_company">Employer Name<span style="color:red;">*</span></label><br> 
                          <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-star-o txt-color-blue"></i></span>
                            <input type="text" name="emp_company" class="form-control" 
                            value="<?php echo set_value('emp_company'); ?>"/> 
                            <span class="input-group-addon"></span>
                          </div>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="emp_phone">Phone<span style="color:red;">*</span></label><br>
                         <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-phone-square txt-color-blue"></i></span>
                            <input type="tel" name="emp_phone" id="emp_phone" class="form-control" 
                            value="<?php echo set_value('emp_phone'); ?>"/> 
                            <span class="input-group-addon"></span>
                         </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="emp_position">Position<span style="color:red;">*</span></label><br>
                         <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-puzzle-piece txt-color-blue"></i></span>
                            <input type="text" name="emp_position" class="form-control" 
                             value="<?php echo set_value('emp_position'); ?>"/> 
                            <span class="input-group-addon"></span>
                         </div>
                </div>
            </div>
            <div class="row">        
               <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="emp_supervisor">Supervisor<span style="color:red;">*</span></label><br>
                         <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-user txt-color-blue"></i></span>
                           <input type="text" name="emp_supervisor" class="form-control" 
                           value="<?php echo set_value('emp_supervisor'); ?>"/> 
                        <span class="input-group-addon"></span>
                         </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="emp_hiredate">Date Hired<span style="color:red;">*</span></label><br>
                         <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-calendar-times-o txt-color-blue"></i></span>
                           <input type="text" name="emp_hiredate" id="emp_hiredate" class="form-control" 
                           value="<?php echo set_value('emp_hiredate'); ?>"/> 
                        <span class="input-group-addon"></span>
                         </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <label for="emp_type">Employment Type<span style="color:red;">* </span></label><br>
                        <div class="input-group">
                             <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-check-square txt-color-blue"></i></span>
                                <?php $ty_selected = array(set_value('emp_type')?set_value('emp_type'):'Full Time');
                                      echo form_dropdown('emp_type', $ET, $ty_selected, array('class' => 'form-control'));  ?>
                                <span class="input-group-addon"></span>
                             </div>       
                        </div>            
                </div>
             
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="emp_url">Employer Website</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-link txt-color-blue"></i></span>
                    <input type="text" name="emp_url" class="form-control" id="emp_url"
                       value="<?php echo set_value('emp_url'); ?>"/> 
                    <span class="input-group-addon"></span>
                </div>
            </div>
           </div>
               <?php echo form_fieldset_close(); ?>     
                </div>
                    
 
             <div class="well well-lg"> 
             <?php echo form_fieldset('Address'); ?>    
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="emp_address">Street Address<span style="color:red;">*</span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-map-signs txt-color-blue"></i></span>
                <input type="text" class="form-control" 
                       name="emp_address" value="<?php echo set_value('emp_address'); ?>"/> 
                <span class="input-group-addon"></span>
                            
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="emp_unit">Unit/Apt/Bldg</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-building-o txt-color-blue"></i></span>
                <input type="text" class="form-control" 
                       name="emp_unit" value="<?php echo set_value('emp_unit'); ?>"/> 
                <span class="input-group-addon"></span>
            </div>
            </div>
            </div> <!-- End STREET Row -->
            <div class="row"> 
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                 <label for="emp_city">City</label><br>
            <div class="input-group">
               
                <span class="input-group-addon"><i class="fa fa-map-pin txt-color-blue"></i></span>
                <input type="text" class="form-control" 
                       name="emp_city" value="<?php echo set_value('emp_city'); ?>"/> 
                <span class="input-group-addon"></span>
                                  
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="emp_state">State</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag txt-color-blue"></i></span>
                <?php $selected = array(set_value('emp_state')?set_value('emp_state'):'Georgia');
                      echo form_dropdown('emp_state', $States, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="emp_zipcode">Zipcode</label><br>
            <div class="input-group">
                <span class="input-group-addon"></span>
                <input type="text" name="emp_zipcode" class="form-control" value="<?php echo set_value('emp_zipcode'); ?>"/> 
                <span class="input-group-addon"></span>
                                   
            </div>
            </div>    
            </div><!-- // end CITY STATE ZIP row -->
            <?php echo form_fieldset_close(); ?>
             </div>
            
           
          
            
            
                 <div class="well well-lg">
             <?php echo form_fieldset('Other Income'); ?>        
             <div class="row">   
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="emp_other_source">Other Source of Income</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-money txt-color-blue"></i></span>
                <input type="text" name="emp_other_source" class="form-control" 
                       value="<?php echo (set_value('emp_other_source')); ?>"/> 
                <span class="input-group-addon"></span>
                                    
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="emp_other_amount">Amount of Other Source<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-dollar txt-color-blue"></i></span>
                <input type="text" name="emp_other_amount" class="form-control" 
                       value="<?php echo (set_value('emp_other_amount')); ?>"/> 
                <span class="input-group-addon">00</span>
                                     
            </div>
            </div>
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
            
                <label for="emp_other_frequency">Other Pay Cycle<span style="color:red;">* </span></label><br>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-check-square txt-color-blue"></i></span>
                            <?php $ocy_selected = array(set_value('emp_other_frequency')?set_value('emp_other_frequency'):'Weekly');
                                  echo form_dropdown('emp_other_frequency', $Cycle, $ocy_selected, array('class' => 'form-control'));  ?>
                            <span class="input-group-addon"></span>
                         </div> 
            </div>    
            
            </div><!-- // end NAME row -->
            <?php echo form_fieldset_close(); ?>
            </div>
            
            <div class="well well-lg">
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <?php
            echo form_submit('submit_emp','Save Employment Information', array('class' => 'pull-left btn btn-primary' ) ); 
            ?>
            </div>
             
            </div>
            </div>
            <?php echo form_close(); 
            //*************************************  End Form    **************************************************************
            
} else {
    
    
             //*********************   Start Form   *****************************************
                    echo validation_errors(); 
                    $attributes = array('role' => 'form', 'id' => 'form_emp');
                    echo form_open($action, $attributes); 
                    echo form_hidden('app_id', $id);
                    echo form_hidden('emp_form', 'UPDATE');
                 ?>
    
       
        <div class="well well-lg">
            <?php echo form_fieldset('Income'); ?>   
            <div class="row">
              
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="emp_annual_salary">Annual Salary<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-dollar txt-color-blue"></i></span>
                    <input type="text" name="emp_annual_salary" id="emp_annual_salary" class="form-control"
                       value="<?php echo $Employers->emp_annual_salary; ?>"/> 
                <span class="input-group-addon">00</span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <label for="emp_direct_deposit">Direct Deposit?<span style="color:red;">* </span></label><br>
                <div class="input-group">
                   <span class="input-group-addon"><i class="fa fa-download txt-color-blue"></i></span> 
                <select name="emp_direct_deposit" class="form-control">
                    <option value="Yes" <?php echo $Employers->emp_direct_deposit; ?> >Yes</option>
                    <option value="No" <?php echo $Employers->emp_direct_deposit; ?> >No</option>
                </select>
               <span class="input-group-addon"></span>
                </div>
            </div> 
        </div>
            
           <div class="row"> 
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
            
                <label for="emp_frequency">Pay Cycle<span style="color:red;">* </span></label><br>
                <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-check-square txt-color-blue"></i></span>
                                <?php $cy_selected = $Employers->emp_frequency?$Employers->emp_frequency:'Weekly';
                                      echo form_dropdown('emp_frequency', $Cycle, $cy_selected, array('class' => 'form-control'));  ?>
                                <span class="input-group-addon"></span>
                             </div> 
            </div> 
               <?php
               $showsemipayday = ($Employers->emp_frequency === 'Semi-Monthly') ? 'display:block;' : 'display:none;';
                $shownextpayday = ($Employers->emp_frequency != 'Semi-Monthly') ? 'display:block;' : 'display:none;';
               ?>
               <div id="nextPayday" style="<?php echo $shownextpayday; ?>">
                      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                         <label for="emp_next_payday">Next Payday?<span style="color:red;">*</span></label><br>
                             <div class="input-group">
                               <span class="input-group-addon"><i class="fa fa-calendar txt-color-blue"></i></span>
                               <input type="text" name="emp_next_payday" id="emp_next_payday" class="form-control" 
                               value="<?php echo $Employers->emp_next_payday; ?>"/> 
                            <span class="input-group-addon"></span>
                             </div>
                        </div> 
               </div>
               <div id="semiDates" style="<?php echo $showsemipayday; ?>">
                      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                         <label for="emp_semi_first">First Pay Date<span style="color:red;">*</span></label><br>
                             <div class="input-group">
                               <span class="input-group-addon"><i class="fa fa-calendar txt-color-blue"></i></span>
                               <input type="text" name="emp_semi_first" id="emp_semi_first" class="form-control" 
                               value="<?php echo $Employers->emp_semi_first; ?>"/> 
                            <span class="input-group-addon"></span>
                             </div>
                        </div> 
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                         <label for="emp_semi_second">Second Pay Date<span style="color:red;">*</span></label><br>
                             <div class="input-group">
                               <span class="input-group-addon"><i class="fa fa-calendar txt-color-blue"></i></span>
                               <input type="text" name="emp_semi_second" id="emp_semi_second" class="form-control" 
                               value="<?php echo $Employers->emp_semi_second; ?>"/> 
                            <span class="input-group-addon"></span>
                             </div>
                        </div> 
               </div>
               
        </div>
            <?php echo form_fieldset_close(); ?>    
            </div>
            
            
   
                <div class="well well-lg">
               <?php echo form_fieldset('Employer'); ?>     
            <div class="row">   
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label for="emp_company">Employer Name<span style="color:red;">*</span></label><br> 
                          <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-star-o txt-color-blue"></i></span>
                            <input type="text" name="emp_company" class="form-control" 
                            value="<?php echo $Employers->emp_company; ?>"/> 
                            <span class="input-group-addon"></span>
                          </div>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="emp_phone">Phone<span style="color:red;">*</span></label><br>
                         <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-phone-square txt-color-blue"></i></span>
                            <input type="tel" name="emp_phone" id="emp_phone" class="form-control" 
                            value="<?php echo $Employers->emp_phone; ?>"/> 
                            <span class="input-group-addon"></span>
                         </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="emp_position">Position<span style="color:red;">*</span></label><br>
                         <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-puzzle-piece txt-color-blue"></i></span>
                            <input type="text" name="emp_position" class="form-control" 
                             value="<?php echo $Employers->emp_position; ?>"/> 
                            <span class="input-group-addon"></span>
                         </div>
                </div>
            </div>
            <div class="row">        
               <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="emp_supervisor">Supervisor<span style="color:red;">*</span></label><br>
                         <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-user txt-color-blue"></i></span>
                           <input type="text" name="emp_supervisor" class="form-control" 
                           value="<?php echo $Employers->emp_supervisor; ?>"/> 
                        <span class="input-group-addon"></span>
                         </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="emp_hiredate">Date Hired<span style="color:red;">*</span></label><br>
                         <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-calendar-times-o txt-color-blue"></i></span>
                           <input type="text" name="emp_hiredate" id="emp_hiredate" class="form-control" 
                           value="<?php echo $Employers->emp_hiredate; ?>"/> 
                        <span class="input-group-addon"></span>
                         </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <label for="emp_type">Employment Type<span style="color:red;">* </span></label><br>
                        <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-check-square txt-color-blue"></i></span>
                                <?php $ty_selected = $Employers->emp_type?$Employers->emp_type:'Full Time';
                                      echo form_dropdown('emp_type', $ET, $ty_selected, array('class' => 'form-control'));  ?>
                                <span class="input-group-addon"></span>
                             </div> 
                </div>
             
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="emp_url">Employer Website</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-link txt-color-blue"></i></span>
                    <input type="text" name="emp_url" class="form-control" id="emp_url"
                       value="<?php echo $Employers->emp_url; ?>"/> 
                    <span class="input-group-addon"></span>
                </div>
            </div>
           </div>
               <?php echo form_fieldset_close(); ?>     
                </div>
                    
 
             <div class="well well-lg"> 
             <?php echo form_fieldset('Address'); ?>    
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="emp_address">Street Address<span style="color:red;">*</span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-map-signs txt-color-blue"></i></span>
                <input type="text" class="form-control" 
                       name="emp_address" value="<?php echo $Employers->emp_address; ?>"/> 
                <span class="input-group-addon"></span>
                            
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="emp_unit">Unit/Apt/Bldg</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-building-o txt-color-blue"></i></span>
                <input type="text" class="form-control" 
                       name="emp_unit" value="<?php echo $Employers->emp_unit; ?>"/> 
                <span class="input-group-addon"></span>
            </div>
            </div>
            </div> <!-- End STREET Row -->
            <div class="row"> 
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                 <label for="emp_city">City</label><br>
            <div class="input-group">
               
                <span class="input-group-addon"><i class="fa fa-map-pin txt-color-blue"></i></span>
                <input type="text" class="form-control" 
                       name="emp_city" value="<?php echo $Employers->emp_city; ?>"/> 
                <span class="input-group-addon"></span>
                                  
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="emp_state">State</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag txt-color-blue"></i></span>
                <?php $selected = $Employers->emp_state?$Employers->emp_state:'Georgia';
                      echo form_dropdown('emp_state', $States, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="emp_zipcode">Zipcode</label><br>
            <div class="input-group">
                <span class="input-group-addon"></span>
                <input type="text" name="emp_zipcode" class="form-control" value="<?php echo $Employers->emp_zipcode; ?>"/> 
                <span class="input-group-addon"></span>
                                   
            </div>
            </div>    
            </div><!-- // end CITY STATE ZIP row -->
            <?php echo form_fieldset_close(); ?>
             </div>
            
           
          
            
            
                 <div class="well well-lg">
             <?php echo form_fieldset('Other Income'); ?>        
             <div class="row">   
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="emp_other_source">Other Source of Income</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-money txt-color-blue"></i></span>
                <input type="text" name="emp_other_source" class="form-control" 
                       value="<?php echo $Employers->emp_other_source; ?>"/> 
                <span class="input-group-addon"></span>
                                    
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="emp_other_amount">Amount of Other Source<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-dollar txt-color-blue"></i></span>
                <input type="text" name="emp_other_amount" class="form-control" 
                       value="<?php echo $Employers->emp_other_amount; ?>"/> 
                <span class="input-group-addon">00</span>
                                     
            </div>
            </div>
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
            
                <label for="emp_other_frequency">Other Pay Cycle<span style="color:red;">* </span></label><br>
                
                <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-check-square txt-color-blue"></i></span>
                                <?php $ocy_selected = $Employers->emp_other_frequency?$Employers->emp_other_frequency:'Weekly';
                                      echo form_dropdown('emp_other_frequency', $Cycle, $ocy_selected, array('class' => 'form-control'));  ?>
                                <span class="input-group-addon"></span>
                             </div> 
            </div>    
            
            </div><!-- // end NAME row -->
            <?php echo form_fieldset_close(); ?>
            </div>
            
            <div class="well well-lg">
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <?php
            
            echo form_submit('submit_emp','Save Employment Information', array('class' => 'pull-left btn btn-primary' ) ); 
                
            ?>
            </div>
            
            </div>
            </div>
            <?php echo form_close(); 
            //*************************************  End Form    **************************************************************
        }   
         ?>
           
            
            
            
            
            
            
            
        </div>
             </div> <!-- END Panel Body -->  
          </div><!-- END Panel -->
       </article> 
     </div>
    </div><!-- END MAIN CONTENT -->
</div><!-- END MAIN -->



