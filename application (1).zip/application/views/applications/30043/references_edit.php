<?php

/* 
 * Default Coborrower Application
 * Steve Thomas
 * 12/26/2015
 * This is the default application for a client. It only collects personal info and address on co-borrower.
 */

// get the client var's that are used in this page
if(isset($cli_rec)): 
    foreach ($cli_rec as $r): 
      $clientID    = $r->client_id;
   $client_name    = $r->client_name; 
    endforeach;
endif;

?>

<script type="text/javascript" language="JavaScript">
$(function() {
    $("#ref1_fname").focus();

  });
jQuery(function($){
    $("#ref1_phone").mask("(999) 999-9999");
    $("#ref2_phone").mask("(999) 999-9999");
    $("#ref3_phone").mask("(999) 999-9999");
});

</script>




<div id="main" data-role="page">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>Apply for Loan</li>
                </ol>
        </div>
        <div id="content">
            
                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-8">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube txt-color-blue"></i> <?php echo $client_name; ?>
                                    <span>> References </span></h1>
                        </div>
                </div>
        
                
                
       
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-11">              
        
     <div class="panel panel-primary">
      <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
      </div>  
          <div class="panel-body">                                                                 
        <div class="content">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2"><?php echo $link_back; ?> </div>
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2"><?php echo $link_app; ?> </div>
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2"><?php echo $link_ref; ?>  </div>
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2"><?php echo $link_emp; ?> </div>
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2"><?php echo $link_co; ?> </div>
            </div>
            
            
            <?php
if(empty($References)) {

             //*********************   Start Form   *****************************************
                    echo validation_errors(); 
                    $attributes = array('role' => 'form', 'id' => 'form_ref');
                    echo form_open($action, $attributes); 
                    echo form_hidden('app_id', $id);
                    echo form_hidden('ref_form', 'NEW');
                 ?>
                    

           
            <div class="well well-lg">
              <?php echo form_fieldset('Reference One Information'); ?>  
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref1_fname">First Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                    <input type="text" name="ref1_fname" id="ref1_fname" class="form-control"
                       value="<?php echo (set_value('ref1_fname')); ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref1_lname">Last Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref1_lname" class="form-control" 
                       value="<?php echo (set_value('ref1_lname')); ?>"/> 
                <span class="input-group-addon"></span>                 
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref1_phone">Primary Phone<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                    <input type="tel" name="ref1_phone" class="form-control" id="ref1_phone"
                       value="<?php echo (set_value('ref1_phone')); ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref1_relation">Relationship</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                <?php $r_selected = (set_value('ref1_relation')) ? (set_value('ref1_relation')) : 'Family Member';
                      echo form_dropdown('ref1_relation', $Ref_Relation, $r_selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>    
                
            </div><!-- // end reference one row -->
            
            <?php echo form_fieldset_close();?>
            </div>
            <?php
         //***************************************************************************************************************   
            ?>
            <div class="well well-lg">
             <?php echo form_fieldset('Reference Two Information'); ?>   
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref2_fname">First Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref2_fname" class="form-control"
                       value="<?php echo (set_value('ref2_fname')); ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref2_lname">Last Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref2_lname" class="form-control" 
                       value="<?php echo (set_value('ref2_lname')); ?>"/> 
                <span class="input-group-addon"></span>                  
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref2_phone">Primary Phone<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                    <input type="tel" name="ref2_phone" class="form-control" id="ref2_phone"
                       value="<?php echo (set_value('ref2_phone')); ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref2_relation">Relationship</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                <?php $r2_selected = (set_value('ref2_relation')) ? (set_value('ref2_relation')) : 'Family Member';
                      echo form_dropdown('ref2_relation', $Ref_Relation, $r2_selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
               
            </div><!-- // end reference two row -->
          <?php echo form_fieldset_close(); ?>
          </div>
            <?php
        //********************************************************************************************************************    
            ?> 
            <div class="well well-lg">
            <?php echo form_fieldset('Reference Three Information'); ?>    
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref3_fname">First Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref3_fname" class="form-control"
                       value="<?php echo (set_value('ref3_fname')); ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref3_lname">Last Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref3_lname" class="form-control" 
                       value="<?php echo (set_value('ref3_lname')); ?>"/> 
                <span class="input-group-addon"></span>               
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref3_phone">Primary Phone<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                    <input type="tel" name="ref3_phone" class="form-control" id="ref3_phone"
                       value="<?php echo (set_value('ref3_phone')); ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref3_relation">Relationship</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                <?php $r3_selected = (set_value('ref3_relation')) ? (set_value('ref3_relation')) : 'Family Member';
                      echo form_dropdown('ref3_relation', $Ref_Relation, $r3_selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
             
            </div><!-- // end reference three row -->
            <?php echo form_fieldset_close(); ?>
            </div><!-- end well -->
                 
             </div>
         
            <div class="well well-lg">
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <?php  echo form_submit('submit_ref','Save References', array('class' => 'pull-left btn btn-primary' ) );?>
            </div>
            </div>
             </div>
            <?php echo form_close(); 
            //*************************************  End Form    **************************************************************
            
}else {
    
//*********************   Start Form   *****************************************
                    echo validation_errors(); 
                    $attributes = array('role' => 'form', 'id' => 'form_ref');
                    echo form_open($action, $attributes); 
                    echo form_hidden('app_id', $References->app_id);
                    echo form_hidden('ref_form', 'UPDATE');
                 ?>
                    

           
            <div class="well well-lg">
              <?php echo form_fieldset('Reference One Information'); ?>  
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref1_fname">First Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                    <input type="text" name="ref1_fname" id="ref1_fname" class="form-control"
                       value="<?php echo $References->ref1_fname; ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref1_lname">Last Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref1_lname" class="form-control" 
                       value="<?php echo $References->ref1_lname; ?>"/> 
                <span class="input-group-addon"></span>                 
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref1_phone">Primary Phone<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                    <input type="tel" name="ref1_phone" class="form-control" id="ref1_phone"
                       value="<?php echo $References->ref1_phone; ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref1_relation">Relationship</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                <?php $r_selected = $References->ref1_relation ? $References->ref1_relation : 'Family Member';
                      echo form_dropdown('ref1_relation', $Ref_Relation, $r_selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>    
                
            </div><!-- // end reference one row -->
            
            <?php echo form_fieldset_close();?>
            </div>
            <?php
         //***************************************************************************************************************   
            ?>
            <div class="well well-lg">
             <?php echo form_fieldset('Reference Two Information'); ?>   
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref2_fname">First Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref2_fname" class="form-control"
                       value="<?php echo $References->ref2_fname; ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref2_lname">Last Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref2_lname" class="form-control" 
                       value="<?php echo $References->ref2_lname; ?>"/> 
                <span class="input-group-addon"></span>                  
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref2_phone">Primary Phone<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                    <input type="tel" name="ref2_phone" class="form-control" id="ref2_phone"
                       value="<?php echo $References->ref2_phone; ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref2_relation">Relationship</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                <?php $r2_selected = $References->ref2_relation ? $References->ref2_relation : 'Family Member';
                      echo form_dropdown('ref2_relation', $Ref_Relation, $r2_selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
               
            </div><!-- // end reference two row -->
          <?php echo form_fieldset_close(); ?>
          </div>
            <?php
        //********************************************************************************************************************    
            ?> 
            <div class="well well-lg">
            <?php echo form_fieldset('Reference Three Information'); ?>    
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref3_fname">First Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref3_fname" class="form-control"
                       value="<?php echo $References->ref3_fname; ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref3_lname">Last Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="ref3_lname" class="form-control" 
                       value="<?php echo $References->ref3_lname; ?>"/> 
                <span class="input-group-addon"></span>               
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref3_phone">Primary Phone<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                    <input type="tel" name="ref3_phone" class="form-control" id="ref3_phone"
                       value="<?php echo $References->ref3_phone; ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="ref3_relation">Relationship</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                <?php $r3_selected = $References->ref3_relation ? $References->ref3_relation : 'Family Member';
                      echo form_dropdown('ref3_relation', $Ref_Relation, $r3_selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
             
            </div><!-- // end reference three row -->
            <?php echo form_fieldset_close(); ?>
            </div><!-- end well -->
                 
             
         
            <div class="well well-lg">
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <?php  echo form_submit('submit_ref','Save References', array('class' => 'pull-left btn btn-primary' ) );?>
            </div>
            </div>
             </div>
            <?php echo form_close(); 
            //*************************************  End Form    **************************************************************
}
            ?>
              
             </div> <!-- END Panel Body -->  
          </div><!-- END Panel -->
       </article> 
     </div>
    </div><!-- END MAIN CONTENT -->
</div><!-- END MAIN -->



