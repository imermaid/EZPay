<?php

/* 
 * Default Application
 * Steve Thomas
 * 12/26/2015
 * This is the default application for a client. It only collects personal info and address on primary borrower.
 */

// get the client var's that are used in this page
//if(isset($cli_rec)): 
//    foreach ($cli_rec as $r): 
//      $clientID    = $r->client_id;
//   $client_name    = $r->client_name; 
//    endforeach;
//endif;

if($NewApplID) {
  $appl_name = $Appl_Record->app_fname. " " .$Appl_Record->app_mname. " " .$Appl_Record->app_lname. " " .$Appl_Record->app_suffix;
      $phone = $Appl_Record->app_phone;
   $altphone = $Appl_Record->app_altphone;
        $dob = $Appl_Record->app_dob;
        $ssn = $Appl_Record->app_primary_ssn;
    $marital = $Appl_Record->app_marital;
     $gender = $Appl_Record->app_gender;
$spouse_name = $Appl_Record->app_spouse_fname. " " .$Appl_Record->app_spouse_lname;
 $spouse_dob = $Appl_Record->app_spouse_dob;
 $spouse_ssn = $Appl_Record->app_spouse_ssn;
      $email = $Appl_Record->app_email;
      $ident = $Appl_Record->app_id_type. " Number: " .$Appl_Record->app_picture_id. " Issuer: " .$Appl_Record->app_state_issue. " Expire: " .$Appl_Record->app_id_expire;
    $address = $Appl_Record->app_street;
       $unit = $Appl_Record->app_unit;
        $stz = $Appl_Record->app_city. " " .$Appl_Record->app_state. ", " .$Appl_Record->app_zipcode;
    $mailing = $Appl_Record->app_mailing_address. " " .$Appl_Record->app_mailing_city. ", " .$Appl_Record->app_mailing_state. " " .$Appl_Record->app_mailing_zipcode;
      $owner = $Appl_Record->app_possession;
      $since = $Appl_Record->app_since;

}
?>

<style type="text/css">
    #form_appl .error {
    color: red;
}
</style>


<div id="main" data-role="page">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>Apply for Loan</li>
                </ol>
        </div>
        <div id="content">
            <div class="row">
              <?php
              
              // This it the forms navigation
                        include 'nav_forms.php';
                        
                        if($NewApplID == '') {
                $panel_color = "panel panel-primary";
            }else if($NewApplID > 0) {
                $panel_color = "panel panel-success";
            }else {
                $panel_color = "panel panel-primary";
            }
            ?>
            </div><br>
            
            <?php
            // if already has application ID, show data not form
            if(isset($Appl_Record))
            {
?>
            <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-11">              
        
     <div class="<?php echo $panel_color; ?>">
      <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
      </div>  
          <div class="panel-body">                                                                 
        <div class="content">
            
          <div class="well well-lg">  
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Applicant Name: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $appl_name; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Phone: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $phone; ?>
               </div>
           </div> 
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Alternate Phone: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $altphone; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Address: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $address; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Unit: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $unit; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>City State Zipcode: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $stz; ?>
               </div>
           </div>
          </div>
            
            
            <div class="well well-lg">
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Email Address: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $email; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Date of Birth: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $dob; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Social Security Number: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $ssn; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Marital Status: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $marital; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Gender: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $gender; ?>
               </div>
           </div>
            </div>
            
            
            <div class="well well-lg">
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Spouse's Name: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $spouse_name; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Spouses Social Security Number: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $spouse_ssn; ?>
               </div>
           </div>
            </div>
            
            
            <div class="well well-lg">
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Identification:: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $ident; ?>
               </div>
           </div>
            </div>
            
            <div class="well well-lg">
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Mailing Address: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $mailing; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Rent/Own: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $owner; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Occupied since:: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $since; ?>
               </div>
           </div>
            </div>
            
            
            
            
            
        </div>
          </div>
     </div>
    </article>
            </div>
            
            
            
            <?php
            } else {
            ?>
                
       
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-11">              
        
     <div class="<?php echo $panel_color; ?>">
      <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
      </div>  
          <div class="panel-body">                                                                 
        <div class="content">

             <?php 
             //*********************   Start Form   *****************************************
                    echo validation_errors(); 
                //    $attributes = array('role' => 'form', 'id' => 'form_appl');
                 //   echo form_open($action, $attributes); 
                 //   echo form_hidden('client_id', $clientID); 
                   // $NID = ($NewApplID <> '') ? $NewApplID : '';
                  //  echo form_hidden('NewApplID', $NID); 
           ?>
            <form action="<?php echo $action; ?>" method="post" id="form_appl"> 
                <?php  //echo form_hidden('client_id', $clientID); ?>
            
            <div class="well well-lg">
                <fieldset><legend>Personal Info</legend>
            <?php  
            //echo form_fieldset('Personal Information'); ?>  
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label for="app_primary_ssn">Primary's SSN/TIN<span style="color:red;">*</span></label><br> 
                  <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-certificate"></i></span>
                <input type="text" name="app_primary_ssn" id="app_primary_ssn" class="form-control" 
                   value="<?php echo (set_value('app_primary_ssn')); ?>"/> 
                   <span class="input-group-addon"></span>
                       
                  </div>
               </div> 
                
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label for="app_primary_ssn">Primary's SSN/TIN<span style="color:red;">*</span></label><br> 
                <div class="input-group date" data-provide="datepicker">
                    <input type="text" class="datepicker form-control" data-date-format="mm/dd/yyyy">
 
    <div class="input-group-addon">
        <span class="glyphicon glyphicon-th"></span>
    </div>
</div>
                </div>
                
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
            
                <label for="app_internal_id">Internal ID</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                <input type="text" name="app_internal_id" class="form-control" 
                       value="<?php echo set_value('app_internal_id'); ?>"/>
                <span class="input-group-addon"></span>
            </div>
            </div>  
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                 <label for="app_dob">DOB<span style="color:red;">*</span></label><br>
                     <div class="input-group">
                       <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                       <input type="text" name="app_dob" id="app_dob" class="form-control" 
                       value="<?php echo set_value('app_dob'); ?>"/> 
                    <span class="input-group-addon"></span>
                     </div>
            </div>
            </div>
            <div class="row">
            </div><!-- end row -->
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_fname">First Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="app_fname" class="form-control"
                       value="<?php echo (set_value('app_fname')); ?>"/> 
                <span class="input-group-addon"></span>
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_mname">Middle Name</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star-o"></i></span>
                <input type="text" name="app_mname" class="form-control" 
                       value="<?php echo (set_value('app_mname')); ?>"/> 
                <span class="input-group-addon"></span>
                                    
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_lname">Last Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="app_lname" class="form-control" 
                       value="<?php echo (set_value('app_lname')); ?>"/> 
                <span class="input-group-addon"></span>
                                     
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_suffix">Suffix</label><br>
                <div class="input-group">
                    <span class="input-group-addon"></span>
                <input type="text" name="app_suffix" class="form-control" 
                       value="<?php echo (set_value('app_suffix')); ?>"/> 
                <span class="input-group-addon"></span>
                                     
            </div>
            </div>
            </div><!-- // end NAME row -->
            
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_phone">Primary Phone<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                    <input type="tel" name="app_phone" class="form-control" id="app_phone"
                       value="<?php echo set_value('app_phone'); ?>"/> 
                <span class="input-group-addon"></span>
                            
                

            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_altphone">Alternate Phone</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone-square"></i></span>
                    <input type="tel" name="app_altphone" id="app_altphone" class="form-control" 
                       value="<?php echo set_value('app_altphone'); ?>"/>
                <span class="input-group-addon"></span>
                                  
            </div>
            </div>
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="app_email">Email Address<span style="color:red;">* </span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-envelope-square"></i></span>
                <input type="email" name="app_email" class="form-control" placeholder="email address"
                       value="<?php echo set_value('app_email'); ?>"/> 
                <span class="input-group-addon"></span>
                           
                
            </div>
            </div>
            
            </div><!-- // end PHONE row -->
            
            
            
            
            
            <div class="row">

            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <label for="app_marital">Marital Status<span style="color:red;">* </span></label><br>
                <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <input type="radio" name="app_marital" onchange="HideContent('hasSpouse')"
                            value="Not Married" <?php echo  set_radio('app_marital', 'Not Married', TRUE, $radclass ); ?> /> Not Married
                     <input type="radio" name="app_marital" onchange="ShowContent('hasSpouse')"
                           value="Married" <?php echo  set_radio('app_marital', 'Married','', $radclass ); ?> /> Married
                </div> 
            </div>
            
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <div class="input-group">
                <label for="app_gender">Gender<span style="color:red;"> * </span></label><br>
                 <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <input type="radio" name="app_gender" 
                            value="Female" <?php echo  set_radio('app_gender', 'Female', TRUE, $radclass ); ?> /> Female
                    <input type="radio" name="app_gender"
                           value="Male" <?php echo  set_radio('app_gender', 'Male', $radclass ); ?> /> Male
                </div>  
                </div>
            </div>     
            </div><!-- // end DOB row -->
            <?php echo form_fieldset_close(); ?>
            </div> <!-- end well -->
            
            
            <div id="hasSpouse" style="display: none;">
            
            <div class="well well-lg">
             <?php echo form_fieldset('Spouse Information'); ?>   
            <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_spouse_fname">Spouse First Name</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="app_spouse_fname" class="form-control"
                       value="<?php echo (set_value('app_spouse_fname')); ?>"/> 
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_spouse_lname">Spouse Last Name</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="app_spouse_lname" class="form-control" 
                       value="<?php echo (set_value('app_spouse_lname')); ?>"/> 
                <span class="input-group-addon"></span>
                                     
                </div>
            </div> 
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label for="app_apouse_ssn">Spouse SSN</label><br> 
                  <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-certificate"></i></span>
                <input type="text" name="app_spouse_ssn" id="app_spouse_ssn" class="form-control" 
                   value="<?php echo set_value('app_spouse_ssn'); ?>"/> 
                   <span class="input-group-addon"></span>
                       
                  </div>
            </div>    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="app_spouse_dob">Spouse DOB</label><br>
                     <div class="input-group">
                       <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                       <input type="text" name="app_spouse_dob" id="app_spouse_dob" class="form-control" 
                       value="<?php echo set_value('app_spouse_dob'); ?>"/> 
                    <span class="input-group-addon"></span>
                     </div>
            </div>    
            </div>
              <?php echo form_fieldset_close(); ?>   
            </div>
            </div>
           
            
            <div class="well well-lg">
               <?php echo form_fieldset('Identification'); ?> 
            <div class="row"><!-- ID -->
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_picture_id">ID Number</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star-o"></i></span>
                <input type="text" name="app_picture_id" class="form-control" 
                       value="<?php echo (set_value('app_picture_id')); ?>"/> 
                <span class="input-group-addon"></span>
                                    
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_id_type">Type of ID<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="app_id_type" class="form-control" 
                       value="<?php echo (set_value('app_id_type')); ?>"/> 
                <span class="input-group-addon"></span>
                                     
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="app_state_issue">Issuing State</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                <?php $selected = array(set_value('app_state_issue')?set_value('app_state_issue'):'Georgia');
                      echo form_dropdown('app_state_issue', $States, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="app_id_expire">ID Expire Date</label><br>
                <div class="input-group">
                    <span class="input-group-addon"></span>
                    <input type="text" name="app_id_expire" id="app_id_expire" class="form-control" 
                       value="<?php echo (set_value('app_id_expire')); ?>"/> 
                <span class="input-group-addon"></span>
                                     
            </div>
            </div>       
            </div>
             <?php echo form_fieldset_close(); ?>   
            </div>
            
            
            <div class="well well-lg">
              <?php echo form_fieldset('Current Address'); ?>  
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            <div class="form-group">
                <label for="app_type">Address Type<span style="color:red;">*</span></label><br>
                            
               <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <input type="radio" name="app_type" 
                            value="Residence" <?php echo  set_radio('app_type', 'Residence', TRUE, $radclass ); ?> /> Residence
                    <input type="radio" name="app_type"
                           value="Business" <?php echo  set_radio('app_type', 'Business','', $radclass ); ?> /> Business
                </div>              
            </div>
             </div> 
             <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            <div class="form-group">
                <label for="app_possession">Rent or Own<span style="color:red;">*</span></label><br>
                 <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <input type="radio" name="app_possession" 
                            value="Own" <?php echo  set_radio('app_possession', 'Own', TRUE, $radclass ); ?> /> Own
                    <input type="radio" name="app_possession"
                           value="Rent" <?php echo  set_radio('app_possession', 'Rent','', $radclass ); ?> /> Rent
                </div>            
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            <div class="form-group">
                <label for="app_mailing_same">Mailing Address is Same<span style="color:red;">*</span></label><br>
                 <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <input type="radio" name="app_mailing_same" id="app_mailing_yes"
                            value="Yes" <?php echo  set_radio('app_mailing_same', 'Yes', TRUE, $radclass ); ?> /> Yes, Same
                     <input type="radio" name="app_mailing_same" id="app_mailing_no"
                           value="No" <?php echo  set_radio('app_mailing_same', 'No','', $radclass ); ?> /> No, Different
                </div>            
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
               <label for="app_since">Occupied Since</label><br> 
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                <input type="text" name="app_since" id="app_since" class="form-control" placeholder="Date"
                       value="<?php echo set_value('app_since'); ?>"/> 
                <span class="input-group-addon"></span>
                                 
                </div>
            </div>     
            </div> <!-- End TYPE row --> 
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="app_street">Street Address<span style="color:red;">*</span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-map-signs"></i></span>
                <input type="text" class="form-control" 
                       name="app_street" value="<?php echo set_value('app_street'); ?>"/> 
                <span class="input-group-addon"></span>
                            
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="app_unit">Unit/Apt/Bldg</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-building-o"></i></span>
                <input type="text" class="form-control" 
                       name="app_unit" value="<?php echo set_value('app_unit'); ?>"/> 
                <span class="input-group-addon"></span>
            </div>
            </div>
            </div> <!-- End STREET Row -->
            <div class="row"> 
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="app_city">City</label><br>
            <div class="input-group">
               
                <span class="input-group-addon"><i class="fa fa-map-pin"></i></span>
                <input type="text" class="form-control" 
                       name="app_city" value="<?php echo set_value('app_city'); ?>"/> 
                <span class="input-group-addon"></span>
                                  
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="app_state">State</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                <?php $selected = set_value('app_state')?set_value('app_state'):'Georgia';
                      echo form_dropdown('app_state', $States, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="app_zipcode">Zipcode</label><br>
            <div class="input-group">
                <span class="input-group-addon"></span>
                <input type="text" name="app_zipcode" class="form-control" value="<?php echo set_value('app_zipcode'); ?>"/> 
                <span class="input-group-addon"></span>
                                   
            </div>
            </div> 
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="app_payment">Monthly Payment</label><br>
            <div class="input-group">
                <span class="input-group-addon">$</span>
                <input type="text" name="app_payment" class="form-control"  placeholder="Rent/Mortgage"
                       value="<?php echo set_value('app_payment'); ?>"/> 
               <span class="input-group-addon">00</span>
                                  
            </div>
            </div>    
            </div><!-- // end CITY STATE ZIP row -->
            <?php echo form_fieldset_close(); ?> 
          </div><!-- end well -->
             
           
          
          <div id="mailing" style="display: none;"> 
           
            <div class="well well-lg"> 
             <?php echo form_fieldset('Mailing Address (if different)'); ?>   
        <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="app_mailing_address">Mailing Address<span style="color:red;">*</span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-map-signs"></i></span>
                <input type="text" class="form-control" 
                       name="app_mailing_address" value="<?php echo set_value('app_mailing_address'); ?>"/> 
                <span class="input-group-addon"></span>
                            
                </div>
            </div>
          
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="app_mailing_city">City</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-map-pin"></i></span>
                <input type="text" class="form-control" 
                       name="app_mailing_city" value="<?php echo set_value('app_mailing_city'); ?>"/> 
                <span class="input-group-addon"></span>
                                  
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="app_mailing_state">State</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                <?php $selected = array(set_value('app_mailing_state')?set_value('app_mailing_state'):'Georgia');
                      echo form_dropdown('app_mailing_state', $States, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="app_mailing_zipcode">Zipcode</label><br>
                <div class="input-group">
                <span class="input-group-addon"></span>
                <input type="text" name="app_mailing_zipcode" class="form-control" value="<?php echo set_value('app_mailing_zipcode'); ?>"/> 
                <span class="input-group-addon"></span>
                                   
                </div>
            </div>    
        </div><!-- // end Mailing CITY STATE ZIP row -->
        
           <?php echo form_fieldset_close(); ?> 
        </div><!-- end well -->
                 
             </div>
          
          
        <div class="row">    
              
        </div><br> <!--//End SINCE Row -->
            
            <div class="well well-lg">
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                
            <?php 
            if($NewApplID > 0) { //if the applicant has been saved, show data but disable submit button so user doesn't keep submitting.
                    echo form_submit('submit_appl','Disabled', array('class' => 'pull-left btn btn-danger', 'disabled' => 'disabled' ) );
                }else {
                    echo form_submit('submit_appl','Save Personal Information', array('class' => 'pull-left btn btn-primary' ) ); 
                }
            ?>
            </div>
             <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">   
            <?php echo form_reset('reset_personal','Reset', array('class' => 'pull-right' ) ); ?>
             </div>
            </div>
            </div>
            <?php echo form_close(); 
            //*************************************  End Form    **************************************************************
            ?>
                    </div>
            </div>
        </div><!-- END Panel -->
    </article>
   </div>
                
                <?php
            } // this ends the if to show the form instead of the data
            ?>
       
        </div>  <!-- END MAIN CONTENT --> 
</div><!-- END MAIN -->


<script>
		// validate custom application requirements form on keyup and submit
                $(function() {
		 $("#form_appl").validate({
                     onfocusout: function (element) {
                                $(element).valid();
                            },
			rules: {
				app_fname: {
                                     required: true,
                                    maxlength: 45
                                },
                                app_lname: {
                                     required: true,
                                    maxlength: 45
                                },
                                app_primary_ssn: {
                                     required: true,
                                    maxlength: 11,
                                    minlength: 11
                                },
				app_dob: {
					 required: true,
					maxlength: 10
				},
				app_phone: {
					 required: true,
					minlength: 14
				},
                                app_altphone: {
                                        required: true,
					minlength: 14
				},
				app_email: {
					required: true,
					   email: true,
                                            maxlength: 85,
					  remote: "emails.action"
				},
                                app_spouse_fname: {
                                    maxlength: 45
                                }, 
                                app_spouse_lname: {
                                    maxlength: 45
                                },
                                app_spouse_ssn: {
                                    maxlength: 11
                                },
                                app_picture_id: {
					required: true,
					maxlength: 45
				},
                                app_street: {
					required: true,
					maxlength: 65
				},
                                app_unit: {
					maxlenght: 65
				},
                                app_city: {
					required: true,
					maxlength: 45
				},
                                app_zipcode: {
					required: true,
                                        digits: true,
					minlength: 5,
                                        maxlength: 5
				},
                                app_mailing_address: {
                                    required: true,
					maxlength: 5,
                                    depends: function(element) {
                                        return $("#app_mailing_no").is(":checked");
                                    }
				},
                                app_mailing_city: {
					required: true,
					maxlength: 45,
                                        depends: function(element) {
                                        return $("#app_mailing_no").is(":checked");
                                    }
				},
                                app_mailing_zipcode: {
					required: true,
                                        digits: true,
					minlength: 5,
                                        maxlength: 5,
                                        depends: function(element) {
                                        return $("#app_mailing_no").is(":checked");
                                    }
				}

			},
			messages: {
                                app_primary_ssn: {
                                        required: "Enter your Social Security Number/Tax Number",
                                        maxlength: jQuery.validator.format("No more than {0} characters"),
                                        minlength: jQuery.validator.format("No less than {0} characters required")
                                    },
				app_fname: {
                                        required: "Enter your First Name",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                    },
				app_lname: {
                                        required: "Enter your Last Name",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
				app_phone: {
                                        required: "Enter your Main Phone",
                                        minlength: jQuery.validator.format("No less than {0} characters")
                                },
                                app_altphone: {
                                        required: "Enter your Alternate Phone",
                                        minlength: jQuery.validator.format("No less than {0} characters")
                                },
				app_email: {
					required: "Please enter a valid email address",
                                        email: "Your email address must be in the format of name@domain.com",
					maxlength: jQuery.validator.format("At least {0} characters required"),
					remote: jQuery.validator.format("{0} is already in use")
				},
                                app_spouse_fname: {
					maxlength: jQuery.validator.format("No more that {0} characters")
				},
				app_spouse_lname: {
					maxlength: jQuery.validator.format("No more than {0} characters")
				},
				app_spouse_ssn: {
					maxlength: jQuery.validator.format("No more than {0} characters")
				},
                                app_picture_id: {
					maxlength: jQuery.validator.format("No more than {0} characters")
				},
                                app_street: {
                                        required: "Please enter a valid street address",
					maxlength: jQuery.validator.format("No more than {0} characters")
				},
                                app_unit: {
					maxlength: jQuery.validator.format("No more than {0} characters")
				},
                                app_city: {
                                        required: "Please enter a valid city",
					maxlength: jQuery.validator.format("No more than {0} characters")
				},
                                app_zipcode: {
                                        required: "Please enter a valid zipcode",
                                        maxlength: jQuery.validator.format("No more than {0} characters"),
					minlength: jQuery.validator.format("No less than {0} characters")
				},
                                app_mailing_address: {
                                        required: "Please enter a valid PO Box",
					maxlength: jQuery.validator.format("No more than {0} characters")
				},

                                  highlight: function(element, errorClass, validClass) {
                                    $(element).addClass(errorClass).removeClass(validClass);
                                    $(element.form).find("label[for=" + element.id + "]")
                                      .addClass(errorClass);
                                  },
                                  unhighlight: function(element, errorClass, validClass) {
                                    $(element).removeClass(errorClass).addClass(validClass);
                                    $(element.form).find("label[for=" + element.id + "]")
                                      .removeClass(errorClass);
                                  }
			}
                 });
	});
	</script>


<script type=text/javascript>
$(function() {
    
    $(".datepicker").datepicker();
  
    $("#app_primary_ssn").focus();
    $("#app_dob").datepicker({ 
        maxDate: "-18Y" 
    });
    $( "#app_spouse_dob" ).datepicker({ 
        maxDate: "-18Y" 
    });
    $( "#app_since" ).datepicker({ 
            maxDate: "+1D" 
    });
    $( "#app_id_expire" ).datepicker({ 
        minDate: "+1D" 
    });
    $('#app_mailing_no').change(function(){
        if($('#app_mailing_no').val() === 'No'){
            $('#mailing').show();
    }
    });
    $('#app_mailing_yes').change(function(){
        if($('#app_mailing_yes').val() === 'Yes'){
            $('#mailing').hide();
    }
    });
  });
jQuery(function($){
   $("#app_dob").mask("99/99/9999");
   $("#app_spouse_dob").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#app_id_expire").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#app_phone").mask("(999) 999-9999");
   $("#app_altphone").mask("(999) 999-9999");
   $("#app_primary_ssn").mask("999-99-9999");
   $("#app_spouse_ssn").mask("999-99-9999");
});
</script>

<script type="text/javascript" language="JavaScript">


function HideContent(d) {
    document.getElementById(d).style.display = "none";
    }
    function ShowContent(d) {
    document.getElementById(d).style.display = "block";
    }
    function ReverseDisplay(d) {
    if(document.getElementById(d).style.display === "none") { document.getElementById(d).style.display = "block"; }
    else { document.getElementById(d).style.display = "none"; }
    }
</script>
