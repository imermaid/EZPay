<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


    $activeBtn = "btn btn-primary";
   $defaultBtn = "btn btn-default";
  $PersonalBtn = (uri_string()== "applications/create_appl") ? "btn btn-primary" : "btn btn-default";
$CoborrowerBtn = (uri_string()== "applications/create_coappl") ? "btn btn-primary" : "btn btn-default";
$ReferencesBtn = (uri_string()== "applications/create_ref") ? "btn btn-primary" : "btn btn-default";
$EmploymentBtn = (uri_string()== "applications/create_empl") ? "btn btn-primary" : "btn btn-default";
     $CoApplID = ($CoApplID >  0) ? $CoApplID  : '';
    $RefApplID = ($RefApplID > 0) ? $RefApplID : '';
    $EmpApplID = ($EmpApplID > 0) ? $EmpApplID : '';
         
?>

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 pull-right">
                <div class="btn-group" role="group" aria-label="Application Menu">
                    <form action="create_appl" method="post" >
                   <?php //echo form_open('applications/create_appl');
                         echo form_hidden('NewApplID', $NewApplID);
                         echo form_hidden('CoApplID', $CoApplID);
                         echo form_hidden('RefApplID', $RefApplID);
                         echo form_hidden('EmpApplID', $EmpApplID);
                         echo form_hidden('appl', 'appl'); 
                         echo '<button type="submit" name="personal" class="'.$PersonalBtn.'">Personal</button>'; 
                         echo form_close();
                    ?>
                </div>
                <div class="btn-group" role="group" aria-label="Application Menu">
                    <form action="create_ref" method="post">
                   <?php //echo form_open(site_url('applications/create_ref'));
                         echo form_hidden('NewApplID', $NewApplID);
                         echo form_hidden('CoApplID', $CoApplID);
                         echo form_hidden('RefApplID', $RefApplID);
                         echo form_hidden('EmpApplID', $EmpApplID);
                         echo form_hidden('ref', 'ref');
                         echo '<button type="submit" class="'.$ReferencesBtn.'">References</button>'; 
                         echo form_close();
                    ?>
                </div>
                <div class="btn-group" role="group" aria-label="Application Menu">
                    <form action="create_empl" method="post">
                   <?php //echo form_open(site_url('applications/create_empl'));
                         echo form_hidden('NewApplID', $NewApplID);
                         echo form_hidden('CoApplID', $CoApplID);
                         echo form_hidden('RefApplID', $RefApplID);
                         echo form_hidden('EmpApplID', $EmpApplID);
                         echo form_hidden('empl', 'empl');
                         echo '<button type="submit" class="'.$EmploymentBtn.'">Employment</button>'; 
                         echo form_close();
                    ?>
                </div>
                <div class="btn-group" role="group" aria-label="Application Menu">
                    <form action="create_coappl" method="post">
                   <?php //echo form_open(site_url('applications/create_coappl'));
                         echo form_hidden('NewApplID', $NewApplID);
                         echo form_hidden('CoApplID', $CoApplID);
                         echo form_hidden('RefApplID', $RefApplID);
                         echo form_hidden('EmpApplID', $EmpApplID);
                         echo form_hidden('coappl', 'coappl');
                         echo '<button type="submit" class="'.$CoborrowerBtn.'">Co-borrower</button>'; 
                         echo form_close();
                    ?>
                </div>
             </div>