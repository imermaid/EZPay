<?php

/* 
 * Default Employers Application
 * Steve Thomas
 * 1/23/2016
 * This is the default application for a client. It only collects personal info and address on co-borrower.
 */

// get the client var's that are used in this page
if(isset($cli_rec)): 
    foreach ($cli_rec as $r): 
      $clientID    = $r->client_id;
   $client_name    = $r->client_name; 
    endforeach;
endif;

?>
<style type="text/css">
    #form_edit_coappl .error {
    color: red;
}
</style>



<div id="main" data-role="page">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>Apply for Loan</li>
                </ol>
        </div>
        <div id="content">
            
                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-8">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube txt-color-blue"></i> <?php echo $client_name; ?>
                                    <span>> Employers </span></h1>
                        </div>
                </div>
        
                
                
       
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-11">              
        
     <div class="panel panel-primary">
      <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
      </div>  
          <div class="panel-body">                                                                 
        <div class="content">
            
            <div class="row">
                <ul class="pager">
                    <li class="previous"><?php echo $link_back; ?></li>
                    <li><?php echo $link_app; ?></li>
                    <li><?php echo $link_ref; ?></li>
                    <li><?php echo $link_emp; ?></li>
                    <li><?php echo $link_co; ?></li>
                    <li class="next"><?php echo $link_back_r; ?></li>
                </ul>
            </div>
            
            <?php
if(empty($Coapplicant)) {

             //*********************   Start Form   *****************************************
                    echo validation_errors(); 
                  //  $attributes = array('role' => 'form', 'id' => 'form_edit_coappl');
                    
                 //   echo form_open($action, $attributes, $passhidden); 
                  //  echo form_hidden('app_id', $id);
                  //  echo form_hidden('co_form', 'NEW');
                 ?>
                    <form action="<?php echo $action; ?>" method="post" id="form_edit_coappl">
              <?php
                    echo form_hidden('app_id', $id);
                    echo form_hidden('co_form', 'NEW');
                 ?>
<div class="well well-lg">
             <?php echo form_fieldset('Personal Information'); ?>  
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="coapp_relation">Relation to Applicant</label><br>
                      <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-users"></i></span>
                      <?php $selected = set_value('coapp_relation')?set_value('coapp_relation'):'Family Member';
                          echo form_dropdown('coapp_relation', $Coapp_Relation, $selected, array('class' => 'form-control'));  ?>
                      <span class="input-group-addon"></span>
                      </div>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label for="coapp_ssn">Coborrower SSN/TIN<span style="color:red;">*</span></label><br> 
                      <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-certificate"></i></span>
                      <input type="text" name="coapp_ssn" id="coapp_ssn" class="form-control" 
                       value="<?php echo set_value('coapp_ssn'); ?>"/> 
                      <span class="input-group-addon"></span>  
                      </div>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="coapp_dob">DOB<span style="color:red;">*</span></label><br>
                     <div class="input-group">
                       <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                       <input type="text" name="coapp_dob" id="coapp_dob" class="form-control" 
                       value="<?php echo set_value('coapp_dob'); ?>"/> 
                    <span class="input-group-addon"></span>
                      
                     </div>
                </div>
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
            <div class="input-group">
                <label for="coapp_gender">Gender<span style="color:red;"> * </span></label><br>
                 <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <input type="radio" name="coapp_gender" 
                            value="Female" <?php echo  set_radio('coapp_gender', 'Female', TRUE, $radclass ); ?> /> Female
                    <input type="radio" name="coapp_gender"
                           value="Male" <?php echo  set_radio('coapp_gender', 'Male', $radclass ); ?> /> Male
                </div>  
            </div>
            </div>    
            </div>
            <div class="row">

            
               
            </div><!-- end row -->
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="coapp_fname">First Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="coapp_fname" class="form-control"
                       value="<?php echo (set_value('coapp_fname')); ?>"/> 
                <span class="input-group-addon"></span>
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="coapp_mname">Middle Name</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star-o"></i></span>
                <input type="text" name="coapp_mname" class="form-control" 
                       value="<?php echo (set_value('coapp_mname')); ?>"/> 
                <span class="input-group-addon"></span>
                                    
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="coapp_lname">Last Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="coapp_lname" class="form-control" 
                       value="<?php echo (set_value('coapp_lname')); ?>"/> 
                <span class="input-group-addon"></span>
                                     
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="coapp_suffix">Suffix</label><br>
                <div class="input-group">
                    <span class="input-group-addon"></span>
                <input type="text" name="coapp_suffix" class="form-control" 
                       value="<?php echo (set_value('coapp_suffix')); ?>"/> 
                <span class="input-group-addon"></span>
                                     
            </div>
            </div>
            </div><!-- // end NAME row -->
            
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="coapp_phone">Primary Phone<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                    <input type="tel" name="coapp_phone" class="form-control" id="coapp_phone"
                       value="<?php echo set_value('coapp_phone'); ?>"/> 
                <span class="input-group-addon"></span>
                            
                

            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="coapp_altphone">Alternate Phone</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone-square"></i></span>
                    <input type="tel" name="coapp_altphone" id="coapp_altphone" class="form-control" 
                       value="<?php echo set_value('coapp_altphone'); ?>"/>
                <span class="input-group-addon"></span>
                                  
            </div>
            </div>
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="coapp_email">Email Address<span style="color:red;">* </span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-envelope-square"></i></span>
                <input type="email" name="coapp_email" class="form-control" placeholder="email address"
                       value="<?php echo set_value('coapp_email'); ?>"/> 
                <span class="input-group-addon"></span>
                           
                
            </div>
            </div>
            
            </div><!-- // end PHONE row -->
            
            
            <div class="row">

            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
            
                <label for="coapp_marital">Marital Status<span style="color:red;">* </span></label><br>
                <div class="input-group">
                   <span class="input-group-addon"><i class="fa fa-venus-mars"></i></span> 
                <select name="coapp_marital" class="form-control">
                    <option value="Married" <?php echo set_select('coapp_marital', 'Married', TRUE); ?> >Married</option>
                    <option value="Not Married" <?php echo set_select('coapp_marital', 'Not Married'); ?> >Not Married</option>
                </select>
               <span class="input-group-addon"></span>
                   
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
            
                <label for="app_id">Primary ID</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                    <input type="text" name="app_id" class="form-control" disabled="disabled"
                       value="<?php echo $id ?>"/>
                <span class="input-group-addon"></span>
            </div>
            </div>     
            </div><!-- // end DOB row -->
            <?php echo form_fieldset_close(); ?>
            </div><!-- // end well -->
            
            
            <div class="well well-lg">
             <?php echo form_fieldset('Address Information'); ?>       
            <div class="row">  
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="coapp_street">Street Address<span style="color:red;">*</span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-map-signs"></i></span>
                <input type="text" class="form-control" 
                       name="coapp_street" value="<?php echo set_value('coapp_street'); ?>"/> 
                <span class="input-group-addon"></span>
                            
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="coapp_unit">Unit/Apt/Bldg</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-building-o"></i></span>
                <input type="text" class="form-control" 
                       name="coapp_unit" value="<?php echo set_value('coapp_unit'); ?>"/> 
                <span class="input-group-addon"></span>
            </div>
            </div>
            </div> <!-- End STREET Row -->
            <div class="row"> 
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="coapp_city">City<span style="color:red;">*</span></label><br>
            <div class="input-group">
               
                <span class="input-group-addon"><i class="fa fa-map-pin"></i></span>
                <input type="text" class="form-control" 
                       name="coapp_city" value="<?php echo set_value('coapp_city'); ?>"/> 
                <span class="input-group-addon"></span>
                                  
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="coapp_state">State<span style="color:red;">*</span></label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                <?php $selected = array(set_value('coapp_state')?set_value('coapp_state'):'Georgia');
                      echo form_dropdown('coapp_state', $States, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="coapp_zipcode">Zipcode<span style="color:red;">*</span></label><br>
            <div class="input-group">
                <span class="input-group-addon"></span>
                <input type="text" name="coapp_zipcode" class="form-control" value="<?php echo set_value('coapp_zipcode'); ?>"/> 
                <span class="input-group-addon"></span>
                                   
            </div>
            </div>      
            </div><!-- // end CITY STATE ZIP row -->
            <?php echo form_fieldset_close(); ?>
            </div>
            
        
            
            <div class="well well-lg">
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <?php 
            
                    echo form_submit('submit_coapp','Save Coborrower Information', array('class' => 'pull-left btn btn-primary' ) ); 
            
            ?>
            </div>
            </div>
            </div>
            <?php echo form_close(); 
            //*************************************  End Form    **************************************************************
           
      
                    
} else {
    
    
             //*********************   Start Form   *****************************************
                    echo validation_errors(); 
               //     $attributes = array('role' => 'form', 'id' => 'form_edit_coappl');
              //      echo form_open($action, $attributes); 
              //      echo form_hidden('app_id', $id);
              //      echo form_hidden('co_form', 'UPDATE');
                 ?>
                  <form action="<?php echo $action; ?>" method="post" id="form_edit_coappl">
              <?php
                    echo form_hidden('app_id', $id);
                    echo form_hidden('co_form', 'UPDATE');
                 ?>
       
        
            
                <div class="well well-lg">
             <?php echo form_fieldset('Personal Information'); ?>  
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="coapp_relation">Relation to Applicant</label><br>
                      <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-users"></i></span>
                      <?php $selected = ($Coapplicant->coapp_relation) ? $Coapplicant->coapp_relation : 'Family Member';
                          echo form_dropdown('coapp_relation', $Coapp_Relation, $selected, array('class' => 'form-control'));  ?>
                      <span class="input-group-addon"></span>
                      </div>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label for="coapp_ssn">Coborrower SSN/TIN<span style="color:red;">*</span></label><br> 
                      <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-certificate"></i></span>
                      <input type="text" name="coapp_ssn" id="coapp_ssn" class="form-control" 
                       value="<?php echo $Coapplicant->coapp_ssn; ?>"/> 
                      <span class="input-group-addon"></span>  
                      </div>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="coapp_dob">DOB<span style="color:red;">*</span></label><br>
                     <div class="input-group">
                       <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                       <input type="text" name="coapp_dob" id="coapp_dob" class="form-control" 
                       value="<?php echo $Coapplicant->coapp_dob; ?>"/> 
                    <span class="input-group-addon"></span>
                      
                     </div>
                </div>
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
            <div class="input-group">
                <label for="coapp_gender">Gender<span style="color:red;"> * </span></label><br>
                 <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); 
                            $female = ($Coapplicant->coapp_gender == "Female" || $Coapplicant->coapp_gender == "") ? TRUE :"";
                            $male = ($Coapplicant->coapp_gender == "Male") ? TRUE :"";
                            ?>
                         
                     <input type="radio" name="coapp_gender" 
                            value="Female" <?php echo  set_radio('app_gender', 'Female', $female, $radclass); ?> /> Female
                    <input type="radio" name="coapp_gender"
                           value="Male" <?php echo  set_radio('app_gender', 'Male', $male, $radclass); ?> /> Male
                </div>  
            </div>
            </div>    
            </div>
            <div class="row">

            
               
            </div><!-- end row -->
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="coapp_fname">First Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="coapp_fname" class="form-control"
                       value="<?php echo $Coapplicant->coapp_fname; ?>"/> 
                <span class="input-group-addon"></span>
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="coapp_mname">Middle Name</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star-o"></i></span>
                <input type="text" name="coapp_mname" class="form-control" 
                       value="<?php echo $Coapplicant->coapp_mname; ?>"/> 
                <span class="input-group-addon"></span>
                                    
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="coapp_lname">Last Name<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-star"></i></span>
                <input type="text" name="coapp_lname" class="form-control" 
                       value="<?php echo $Coapplicant->coapp_lname; ?>"/> 
                <span class="input-group-addon"></span>
                                     
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="coapp_suffix">Suffix</label><br>
                <div class="input-group">
                    <span class="input-group-addon"></span>
                <input type="text" name="coapp_suffix" class="form-control" 
                       value="<?php echo $Coapplicant->coapp_suffix; ?>"/> 
                <span class="input-group-addon"></span>
                                     
            </div>
            </div>
            </div><!-- // end NAME row -->
            
            <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="coapp_phone">Primary Phone<span style="color:red;">*</span></label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                    <input type="tel" name="coapp_phone" class="form-control" id="coapp_phone"
                       value="<?php echo $Coapplicant->coapp_phone; ?>"/> 
                <span class="input-group-addon"></span>
                            
                

            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
            
                <label for="coapp_altphone">Alternate Phone</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-phone-square"></i></span>
                    <input type="tel" name="coapp_altphone" id="coapp_altphone" class="form-control" 
                       value="<?php echo $Coapplicant->coapp_altphone; ?>"/>
                <span class="input-group-addon"></span>
                                  
            </div>
            </div>
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="coapp_email">Email Address<span style="color:red;">* </span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-envelope-square"></i></span>
                <input type="email" name="coapp_email" class="form-control" placeholder="email address"
                       value="<?php echo $Coapplicant->coapp_email; ?>"/> 
                <span class="input-group-addon"></span>
                           
                
            </div>
            </div>
            
            </div><!-- // end PHONE row -->
            
            
            <div class="row">

            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
            
                <label for="coapp_marital">Marital Status<span style="color:red;">* </span></label><br>
                <div class="input-group">
                   <span class="input-group-addon"><i class="fa fa-venus-mars"></i></span> 
                   <?php $marr = ($Coapplicant->coapp_marital == 'Married') ? 'selected' : '';
                         $notM = ($Coapplicant->coapp_marital == 'Not Married' || $Coapplicant->coapp_marital == '') ? 'selected' : '';
                   ?>
                <select name="coapp_marital" class="form-control">
                    <option value="Married" <?php echo $marr; ?> >Married</option>
                    <option value="Not Married" <?php echo $notM; ?> >Not Married</option>
                </select>
               <span class="input-group-addon"></span>
                   
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
            
                <label for="app_id">Primary ID</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                    <input type="text" name="app_id" class="form-control" disabled="disabled"
                       value="<?php echo $id ?>"/>
                <span class="input-group-addon"></span>
            </div>
            </div>     
            </div><!-- // end DOB row -->
            <?php echo form_fieldset_close(); ?>
            </div><!-- // end well -->
            
            
            <div class="well well-lg">
             <?php echo form_fieldset('Address Information'); ?>       
            <div class="row">  
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="coapp_street">Street Address<span style="color:red;">*</span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-map-signs"></i></span>
                <input type="text" class="form-control" 
                       name="coapp_street" value="<?php echo $Coapplicant->coapp_street; ?>"/> 
                <span class="input-group-addon"></span>
                            
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="coapp_unit">Unit/Apt/Bldg</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-building-o"></i></span>
                <input type="text" class="form-control" 
                       name="coapp_unit" value="<?php echo $Coapplicant->coapp_unit; ?>"/> 
                <span class="input-group-addon"></span>
            </div>
            </div>
            </div> <!-- End STREET Row -->
            <div class="row"> 
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="coapp_city">City<span style="color:red;">*</span></label><br>
            <div class="input-group">
               
                <span class="input-group-addon"><i class="fa fa-map-pin"></i></span>
                <input type="text" class="form-control" 
                       name="coapp_city" value="<?php echo $Coapplicant->coapp_city; ?>"/> 
                <span class="input-group-addon"></span>
                                  
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="coapp_state">State<span style="color:red;">*</span></label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                <?php $selected = $Coapplicant->coapp_state?$Coapplicant->coapp_state:'Georgia';
                      echo form_dropdown('coapp_state', $States, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="coapp_zipcode">Zipcode<span style="color:red;">*</span></label><br>
            <div class="input-group">
                <span class="input-group-addon"></span>
                <input type="text" name="coapp_zipcode" class="form-control" value="<?php echo $Coapplicant->coapp_zipcode; ?>"/> 
                <span class="input-group-addon"></span>
                                   
            </div>
            </div>      
            </div><!-- // end CITY STATE ZIP row -->
            <?php echo form_fieldset_close(); ?>
            </div>
            
        
            
            <div class="well well-lg">
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
            <?php 
            
                    echo form_submit('submit_coapp','Save Coborrower Information', array('class' => 'pull-left btn btn-primary' ) ); 
            
            ?>
            </div>
            </div>
            </div>
            <?php echo form_close(); 
            //*************************************  End Form    **************************************************************
              
        }   
         ?>
           
            
            
            
            
            
            
            
        </div>
             </div> <!-- END Panel Body -->  
          </div><!-- END Panel -->
       </article> 
     </div>
    </div><!-- END MAIN CONTENT -->
</div><!-- END MAIN -->

<script>


		// validate custom application requirements form on keyup and submit
                $(function() {
		 $("#form_edit_coappl").validate({
                     onfocusout: function (element) {
                                $(element).valid();
                            },
			rules: {
				coapp_fname: {
                                     required: true,
                                    maxlength: 45
                                },
                                coapp_lname: {
                                     required: true,
                                    maxlength: 45
                                },
                                coapp_ssn: {
                                     required: true,
                                    minlength: 11
                                },
				coapp_dob: {
					 required: true,
					maxlength: 10
				},
				coapp_phone: {
					 required: true,
                                        minlength: 14
				},
                                coapp_altphone: {
                                        required: true,
                                        minlength: 14
				},
				coapp_email: {
					required: true,
					   email: true,
                                            maxlength: 85,
					  remote: "emails.action"
				},
                               
                                coapp_street: {
					required: true,
					maxlength: 65
				},
                                coapp_unit: {
					required: true,
					maxlenght: 65
				},
                                coapp_city: {
					required: true,
					maxlength: 45
				},
                                coapp_zipcode: {
					required: true,
                                        digits: true,
					minlength: 5,
                                        maxlength: 5
				}
			},
			messages: {
                                coapp__ssn: {
                                        required: "Enter your Social Security Number/Tax Number",
                                        minlength: jQuery.validator.format("No less than {0} characters required")
                                    },
				coapp_fname: {
                                        required: "Enter your First Name",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                    },
				coapp_lname: {
                                        required: "Enter your Last Name",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
				coapp_phone: {
                                        required: "Enter your Phone Number",
                                        minlength: jQuery.validator.format("No less than {0} characters")
                                },
                                coapp_altphone: {
                                        required: "Enter your Alternate Phone Number",
                                        minlength: jQuery.validator.format("No less than {0} characters")
                                },
				coapp_email: {
					required: "Please enter a valid email address",
                                        email: "Your email address must be in the format of name@domain.com",
					maxlength: jQuery.validator.format("At least {0} characters required"),
					remote: jQuery.validator.format("{0} is already in use")
				},
                                coapp_street: {
                                        required: "Please enter a valid street address",
					maxlength: jQuery.validator.format("No more than {0} characters")
				},
                                coapp_unit: {
					maxlength: jQuery.validator.format("No more than {0} characters")
				},
                                coapp_city: {
                                        required: "Please enter a valid city",
					maxlength: jQuery.validator.format("No more than {0} characters")
				},
                                coapp_zipcode: {
                                        required: "Please enter a valid zipcode",
                                        maxlength: jQuery.validator.format("No more than {0} characters"),
					minlength: jQuery.validator.format("No less than {0} characters")
				},
                                

                                  highlight: function(element, errorClass, validClass) {
                                    $(element).addClass(errorClass).removeClass(validClass);
                                    $(element.form).find("label[for=" + element.id + "]")
                                      .addClass(errorClass);
                                  },
                                  unhighlight: function(element, errorClass, validClass) {
                                    $(element).removeClass(errorClass).addClass(validClass);
                                    $(element.form).find("label[for=" + element.id + "]")
                                      .removeClass(errorClass);
                                  }
			}
                 });
	});
	</script>

<script type="text/javascript">
$(function() {
    $( "#add_since" ).datepicker({ 
            maxDate: "+1d"
    });
    $( "#coapp_dob" ).datepicker({ 
            maxDate: "-18Y"
        
    });
    
    
    $("#coapp_ssn").focus();
    


  });
jQuery(function($){
   $("#coapp_dob").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#coapp_phone").mask("(999) 999-9999");
   $("#coapp_altphone").mask("(999) 999-9999");
   $("#coapp_ssn").mask("999-99-9999");
});
 function HideContent(d) {
    document.getElementById(d).style.display = "none";
    }
    function ShowContent(d) {
    document.getElementById(d).style.display = "block";
    }
    function ReverseDisplay(d) {
    if(document.getElementById(d).style.display == "none") { document.getElementById(d).style.display = "block"; }
    else { document.getElementById(d).style.display = "none"; }
    }
</script>
