<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// get the var's that are used in this page
if(isset($cli_rec)): foreach ($cli_rec as $r): 
   $client_id     = $r->client_id; 
   $client_name   = $r->client_name; 
endforeach;
endif;

?>





<!-- MAIN PANEL -->
<div id="main" role="main">

        <!-- RIBBON -->
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>View</li>
                </ol>
        </div>
        <!-- MAIN CONTENT -->
        <div id="content">
                <div class="row">

                        <!-- col -->
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube"></i> <?php echo $client_name; ?>
                                    <span>> Approvals </span></h1>
                        </div>
                </div>
 
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">  
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h1><?php echo $title; ?></h1>
                </div>  
        
                <div class="panel-body">                   
                    <div> 
                        <div class="paging">
                            <?php echo $pagination; ?>
                        </div> 
                        <div class="data">
                            <?php echo $table; ?>
                        </div> 
                        <div class="paging">
                            <?php echo $pagination; ?>
                        </div> 
                    </div>                    
                </div>
             
             </div>
          
    </article>
   </div>
    </div>
        <!-- END MAIN CONTENT -->

</div>
<!-- END MAIN PANEL -->
