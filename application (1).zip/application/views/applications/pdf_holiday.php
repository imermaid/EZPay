
<!-- MAIN PANEL -->
<div id="main" role="main">

       
        <!-- MAIN CONTENT -->
        <div id="content">
               
 
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">  
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h1>Federal Holiday</h1>
                </div>  
        
                <div class="panel-body">                   
                    <div> 
                         <table width="700" cellpadding="2" cellspacing="0" class="generic2" border="0">
      <tbody>
          <tr style="color: #000;">
        <th width="30%">
          &#160;
        </th>
        <th scope="col">
          2015
        </th>
        <th scope="col">
          2016
        </th>
        <th scope="col">
          2017
        </th>
        <th scope="col">
          2018
        </th>
        <th scope="col">
          2019
        </th>
      </tr>
      <tr>
        <td scope="row" class="rowstub">
          New Year's Day
        </td>
        <td>
          January 1
        </td>
        <td>
          January 1
        </td>
        <td>
          January 2
        </td>
        <td>
          January 1
        </td>
        <td>
          January 1
        </td>
      </tr>
      <tr>
        <td scope="row" class="rowstub">
          Birthday of Martin Luther King,&#160;Jr.
        </td>
        <td>
          January 19
        </td>
        <td>
          January 18
        </td>
        <td>
          January 16
        </td>
        <td>
          January 15
        </td>
        <td>
          January 21
        </td>
      </tr>
      <tr>
        <td scope="row" class="rowstub">
          Washington's Birthday
        </td>
        <td>
          February 16
        </td>
        <td>
          February 15
        </td>
        <td>
          February 20
        </td>
        <td>
          February 19
        </td>
        <td>
          February 18
        </td>
      </tr>
      <tr>
        <td scope="row" class="rowstub">
          Memorial Day
        </td>
        <td>
          May 25
        </td>
        <td>
          May 30
        </td>
        <td>
          May 29
        </td>
        <td>
          May 28
        </td>
        <td>
          May 27
        </td>
      </tr>
      <tr>
        <td scope="row" class="rowstub">
          Independence Day
        </td>
        <td>
          July 4*
        </td>
        <td>
          July 4
        </td>
        <td>
          July 4
        </td>
        <td>
          July 4
        </td>
        <td>
          July 4
        </td>
      </tr>
      <tr>
        <td scope="row" class="rowstub">
          Labor Day
        </td>
        <td>
          September 7
        </td>
        <td>
          September 5
        </td>
        <td>
          September 4
        </td>
        <td>
          September 3
        </td>
        <td>
          September 2
        </td>
      </tr>
      <tr>
        <td scope="row" class="rowstub">
          Columbus Day
        </td>
        <td>
          October 12
        </td>
        <td>
          October 10
        </td>
        <td>
          October 9
        </td>
        <td>
          October 8
        </td>
        <td>
          October 14
        </td>
      </tr>
      <tr>
        <td scope="row" class="rowstub">
          Veterans Day
        </td>
        <td>
          November 11
        </td>
        <td>
          November 11
        </td>
        <td>
          November 11*
        </td>
        <td>
          November 12
        </td>
        <td>
          November 11
        </td>
      </tr>
      <tr>
        <td scope="row" class="rowstub">
          Thanksgiving Day
        </td>
        <td>
          November 26
        </td>
        <td>
          November 24
        </td>
        <td>
          November 23
        </td>
        <td>
          November 22
        </td>
        <td>
          November 28
        </td>
      </tr>
      <tr>
        <td scope="row" class="rowstub">
          Christmas Day
        </td>
        <td>
          December 25
        </td>
        <td>
          December 26
        </td>
        <td>
          December 25
        </td>
        <td>
          December 25
        </td>
        <td>
          December 25
        </td>
      </tr>
      </tbody>
    </table>
                        
                         <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <a href="<?php echo secure_site_url('dompdf_pdf/holidays'); ?>">      
                                            <button type="button" class="btn btn-primary">
                                            <span>PDF Version</span>
                                            </button>
                                        </a>
                </div>
                    </div>                    
                </div>
             
             </div>
          
    </article>
   </div>
    </div>
        <!-- END MAIN CONTENT -->

</div>
<!-- END MAIN PANEL -->

<script type="text/javascript">
$(function() {
    $("#search_id").focus();
    $("#app_phone").mask("(999) 999-9999");
    $("#app_primary_ssn").mask("999-99-9999");
    $( "tr:odd" ).css( "background-color", "#dbdbdb" );
    $("tr").not(':first').hover(
  function () {
    $(this).css("background","#3074ae");
    $(this).css("color", "#ffffff");
  }, 
  function () {
    $(this).css("background","");
    $( "tr:odd" ).css( "background-color", "#dbdbdb" );
    $(this).css("color", "#000000");

  }
);
    
});

</script> 