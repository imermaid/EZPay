<?php

/* 
 * Applicant_View
 * This displays the applicant View
 * Steve Thomas
 * 1/19/2016
 */

// get the var's that are used in this page
if(isset($cli_rec)): foreach ($cli_rec as $r): 
   $client_name    = $r->client_name; 
   $contact_name  = $r->contact_name;
   $contact_phone = $r->contact_phone; 
endforeach;
endif;

 $appl_name = $Applicant->app_fname. " " .$Applicant->app_mname. " " .$Applicant->app_lname. " " .$Applicant->app_suffix;
      $phone = $Applicant->app_phone;
   $altphone = $Applicant->app_altphone;
        $dob = $Applicant->app_dob;
        $ssn = $Applicant->app_primary_ssn;
    $marital = $Applicant->app_marital;
     $gender = $Applicant->app_gender;
$spouse_name = $Applicant->app_spouse_fname. " " .$Applicant->app_spouse_lname;
 $spouse_dob = $Applicant->app_spouse_dob;
 $spouse_ssn = $Applicant->app_spouse_ssn;
      $email = $Applicant->app_email;
      $ident = $Applicant->app_id_type. " Number: " .$Applicant->app_picture_id. "<br> Issuer: " .$Applicant->app_state_issue. " Expire: " .$Applicant->app_id_expire;
    $address = $Applicant->app_street;
       $unit = $Applicant->app_unit;
        $stz = $Applicant->app_city. ", " .$Applicant->app_state. " " .$Applicant->app_zipcode;
        if(!empty($Applicant->app_mailing_address) && !empty($Applicant->app_mailing_address)  ){
    $mailing = $Applicant->app_mailing_address. " " .$Applicant->app_mailing_city. ", " .$Applicant->app_mailing_state. " " .$Applicant->app_mailing_zipcode;
        }else {
            $mailing = "Same as above.";
        }
      $owner = $Applicant->app_possession;
      $since = $Applicant->app_since;


?>
<!-- MAIN PANEL -->
<div id="main" role="main">

        <!-- RIBBON -->
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>View</li>
                </ol>
        </div>
        <!-- MAIN CONTENT -->
        <div id="content">
 
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">  
       <div class="panel panel-primary">
    <div class="panel-heading">
        <h1><?php echo $title; ?><span class="pull-right"><?php echo $appl_name;?></span></h1>
    </div>  
          <div class="panel-body">
            <div class="content"> 
                <div class="row">
                <ul class="pager">
                    <li class="previous"><?php echo $link_edit; ?></li>
                                     <li><?php echo $link_bank; ?></li>
                                     <li><?php echo $link_loan; ?></li>
                        <li class="next"><?php echo $link_back; ?></li>
                </ul>
            </div>
                
       <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">       
        <div class="well well-lg">  
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Applicant: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $appl_name; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Phone: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $phone; ?>
               </div>
           </div> 
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Alt Phone: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $altphone; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Address: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $address; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Unit: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $unit; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>City State Zipcode: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $stz; ?>
               </div>
           </div>
        </div>
            
            
        <div class="well well-lg">
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Email: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $email; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Birth Date: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $dob; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>SSN: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $ssn; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Marital Status: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $marital; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Gender: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $gender; ?>
               </div>
           </div>
        </div>
            
            
        <div class="well well-lg">
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Spouse's Name: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $spouse_name; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Spouses Social Security Number: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $spouse_ssn; ?>
               </div>
           </div>
        </div>
            
            
        <div class="well well-lg">
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Identification: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $ident; ?>
               </div>
           </div>
        </div>
            
        <div class="well well-lg">
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Mailing Address: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $mailing; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Rent/Own: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $owner; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                 <label>Occupied since:: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-9">
                <?php echo $since; ?>
               </div>
           </div>
        </div>
      </div>
                
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-8"> 
           <div class="well well-lg">  
               <div class="row">
                   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                       <h3 class="text-center">Current Loan Status<br>
                           for Loan # <?php echo $Loan->loa_id; ?> is:<br><span class="font-lg txt-color-red"><?php echo $Loan->loa_status; ?></span></h3>

                   </div>
                   <?php if ($Loan->loa_status == 'Funded' || $Loan->loa_status == 'Applied'){  // If funded or applied status don't change this way. Applied must complete application.
                       $showhide = 'display:none;';
                   }else{
                       $showhide = 'display:block;';
                   } 
                   ?>
                   <div id="changeStatus" style="<?php echo $showhide; ?>">
                   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6"> 
                       <div class="panel panel-primary">
                          <div class="panel-heading">
                            <h3 class="panel-title">Change status to:</h3>
                          </div>
                          <div class="panel-body">
                              <div class="row">
                              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 text-center">
                                  <button type="button" value="APPROVED" id="btn_approved" class="btn btn-success" onclick="ShowContent('if_approved')">APPROVED</button> 
                              </div> 
                                  <?php if( $Loan->loa_status == 'Denied') {  ?>
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 text-center">
                                  <form action="<?php echo $action; ?>" method="post" id="form_pending" name="form_pending">
                                  <input type="hidden" name="pending" value="pending" />
                                  <input type="hidden" name="loa" value="<?php echo $Loan->loa_id; ?>" />
                                  <input type="submit" id="btn_pending" name="btn_pending" class="btn btn-primary" value="PENDING" />
                                  </form>
                                </div>
                                  <?php } 
                                   if( $Loan->loa_status == 'Pending') {  ?>
                                  
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 text-center">
                                  <form action="<?php echo $action; ?>" method="post" id="form_denied" name="form_denied">
                                  <input type="hidden" name="denied" value="denied" />
                                  <input type="hidden" name="loa" value="<?php echo $Loan->loa_id; ?>" />
                                  <input type="submit" id="btn_denied" name="btn_denied" class="btn btn-danger" value="DENIED" />
                                  </form>
                                </div>  
                                  <?php } ?>
                              </div>
                              
                          </div>
                        </div>
                   </div>
                   </div>
           </div>
         </div>
      </div>
            
                
                <div id="if_approved" class="col-xs-12 col-sm-12 col-md-12 col-lg-6" style="display: none;"> 
               <form action="<?php echo $action; ?>" method="post" autocomplete="off" id="form_approved" name="form_approved">
            <div class="well well-lg">  
                <div class="row">
                   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"> 
                       <div class="panel panel-primary">
                          <div class="panel-heading">
                            <h3 class="panel-title text-center">Risk <br>Discount</h3>
                            
                          </div>
                          <div class="panel-body">
                              <input type="text" size="8" name="risk_discount" /> 
                          </div>
                        </div>
                   </div>
                   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"> 
                       <div class="panel panel-primary">
                          <div class="panel-heading">
                            <h3 class="panel-title text-center">Down <br>payment</h3>
                            
                          </div>
                          <div class="panel-body">
                              <input type="text" size="8" name="down_payment" /> 
                          </div>
                        </div>
                   </div> 
                   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"> 
                       <div class="panel panel-primary">
                          <div class="panel-heading">
                              <h3 class="panel-title text-center">Approval <br> Amount</h3>
                            
                          </div>
                          <div class="panel-body">
                              <input type="text" size="8" name="approval_amount" /> 
                          </div>
                        </div>
                   </div>
                   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"> 
                       <div class="panel panel-primary">
                          <div class="panel-heading">
                              <h3 class="panel-title text-center">Approval <br> Term</h3>
                            
                          </div>
                          <div class="panel-body">
                              <input type="text" size="8" name="approval_term" /> 
                          </div>
                        </div>
                   </div> 
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"> 
                       <div class="panel panel-primary">
                          <div class="panel-heading">
                            <h3 class="panel-title text-center">Bid <br>Percent</h3>
                            
                          </div>
                          <div class="panel-body">
                              <input type="text" size="8" name="bid_percent" /> 
                          </div>
                        </div>
                   </div> 
                   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"> 
                       <div class="panel panel-primary">
                          <div class="panel-heading">
                              <h3 class="panel-title text-center">Commitment <br> (in days)</h3>
                            
                          </div>
                          <div class="panel-body">
                              <input type="text" size="8" name="commitment" /> 
                          </div>
                        </div>
                   </div>
                   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"> 
                       <div class="panel panel-primary">
                          <div class="panel-heading">
                            <h3 class="panel-title text-center">Electronic <br>Signature</h3>
                            
                          </div>
                          <div class="panel-body">
                              <input type="text" size="8" name="esign" /> 
                          </div>
                        </div>
                   </div>  
                   <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"> 
                       
                              <input type="submit" class="btn btn-success" value="Submit Approval" />
                         
                   </div>  
                </div>     
            </div>
               </form>
           </div>    
        </div>    
       </div>
    </article>
   </div> <!-- end row -->
 
           
        </div>
        <!-- END MAIN CONTENT -->
</div>
<!-- END MAIN PANEL -->

<script type="text/javascript">


function HideContent(d) {
    document.getElementById(d).style.display = "none";
    }
    function ShowContent(d) {
    document.getElementById(d).style.display = "block";
    }
    function ReverseDisplay(d) {
    if(document.getElementById(d).style.display == "none") { document.getElementById(d).style.display = "block"; }
    else { document.getElementById(d).style.display = "none"; }
    }
</script>

