<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<!-- HEADER -->
<header id="header">
        <div id="logo-group">

                <!-- PLACE YOUR LOGO HERE -->
                <span id="logo"> <img src="assets/img/logo.png" alt="SmartAdmin"> </span>
                <!-- END LOGO PLACEHOLDER -->

                <!-- Note: The activity badge color changes when clicked and resets the number to 0
                Suggestion: You may want to set a flag when this happens to tick off all checked messages / notifications -->
                <span id="activity" class="activity-dropdown"> <i class="fa fa-user"></i> <b class="badge"> 21 </b> </span>

                <!-- AJAX-DROPDOWN : control this dropdown height, look and feel from the LESS variable file -->
                <div class="ajax-dropdown">

                        <!-- the ID links are fetched via AJAX to the ajax container "ajax-notifications" -->
                        <div class="btn-group btn-group-justified" data-toggle="buttons">
                                <label class="btn btn-default">
                                        <input type="radio" name="activity" id="ajax/notify/mail.html">
                                        Msgs (14) </label>
                                <label class="btn btn-default">
                                        <input type="radio" name="activity" id="ajax/notify/notifications.html">
                                        notify (3) </label>
                                <label class="btn btn-default">
                                        <input type="radio" name="activity" id="ajax/notify/tasks.html">
                                        Tasks (4) </label>
                        </div>

                        <!-- notification content -->
                        <div class="ajax-notifications custom-scroll">

                                <div class="alert alert-transparent">
                                        <h4>Click a button to show messages here</h4>
                                        This blank page message helps protect your privacy, or you can show the first message here automatically.
                                </div>

                                <i class="fa fa-lock fa-4x fa-border"></i>

                        </div>
                        <!-- end notification content -->

                        <!-- footer: refresh area -->
                        <span> Last updated on: 12/12/2013 9:43AM
                                <button type="button" data-loading-text="<i class='fa fa-refresh fa-spin'></i> Loading..." class="btn btn-xs btn-default pull-right">
                                        <i class="fa fa-refresh"></i>
                                </button> </span>
                        <!-- end footer -->

                </div>
                <!-- END AJAX-DROPDOWN -->
        </div>

        <!-- projects dropdown -->
        <div class="project-context hidden-xs">

                <span class="label">Projects:</span>
                <span class="project-selector dropdown-toggle" data-toggle="dropdown">Recent projects <i class="fa fa-angle-down"></i></span>

                <!-- Suggestion: populate this list with fetch and push technique -->
                <ul class="dropdown-menu">
                        <li>
                                <a href="javascript:void(0);">Online e-merchant management system - attaching integration with the iOS</a>
                        </li>
                        <li>
                                <a href="javascript:void(0);">Notes on pipeline upgradee</a>
                        </li>
                        <li>
                                <a href="javascript:void(0);">Assesment Report for merchant account</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                                <a href="javascript:void(0);"><i class="fa fa-power-off"></i> Clear</a>
                        </li>
                </ul>
                <!-- end dropdown-menu-->

        </div>
        <!-- end projects dropdown -->

        <!-- pulled right: nav area -->
        <div class="pull-right">

                <!-- collapse menu button -->
                <div id="hide-menu" class="btn-header pull-right">
                        <span> <a href="javascript:void(0);" data-action="toggleMenu" title="Collapse Menu"><i class="fa fa-reorder"></i></a> </span>
                </div>
                <!-- end collapse menu -->

                <!-- #MOBILE -->
                <!-- Top menu profile link : this shows only when top menu is active -->
                <ul id="mobile-profile-img" class="header-dropdown-list hidden-xs padding-5">
                        <li class="">
                                <a href="#" class="dropdown-toggle no-margin userdropdown" data-toggle="dropdown"> 
                                        <img src="img/avatars/sunny.png" alt="John Doe" class="online" />  
                                </a>
                                <ul class="dropdown-menu pull-right">
                                        <li>
                                                <a href="javascript:void(0);" class="padding-10 padding-top-0 padding-bottom-0"><i class="fa fa-cog"></i> Setting</a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                                <a href="profile.html" class="padding-10 padding-top-0 padding-bottom-0"> <i class="fa fa-user"></i> <u>P</u>rofile</a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                                <a href="javascript:void(0);" class="padding-10 padding-top-0 padding-bottom-0" data-action="toggleShortcut"><i class="fa fa-arrow-down"></i> <u>S</u>hortcut</a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                                <a href="javascript:void(0);" class="padding-10 padding-top-0 padding-bottom-0" data-action="launchFullscreen"><i class="fa fa-arrows-alt"></i> Full <u>S</u>creen</a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                                <a href="login.html" class="padding-10 padding-top-5 padding-bottom-5" data-action="userLogout"><i class="fa fa-sign-out fa-lg"></i> <strong><u>L</u>ogout</strong></a>
                                        </li>
                                </ul>
                        </li>
                </ul>

                <!-- logout button -->
                <div id="logout" class="btn-header transparent pull-right">
                        <span> <a href="login.html" title="Sign Out" data-action="userLogout" data-logout-msg="You can improve your security further after logging out by closing this opened browser"><i class="fa fa-sign-out"></i></a> </span>
                </div>
                <!-- end logout button -->

                <!-- search mobile button (this is hidden till mobile view port) -->
                <div id="search-mobile" class="btn-header transparent pull-right">
                        <span> <a href="javascript:void(0)" title="Search"><i class="fa fa-search"></i></a> </span>
                </div>
                <!-- end search mobile button -->

                <!-- input: search field -->
                <form action="search.html" class="header-search pull-right">
                        <input id="search-fld"  type="text" name="param" placeholder="Find reports and more" data-autocomplete='[
                        "ActionScript",
                        "AppleScript",
                        "Asp",
                        "BASIC",
                        "C",
                        "C++",
                        "Clojure",
                        "COBOL",
                        "ColdFusion",
                        "Erlang",
                        "Fortran",
                        "Groovy",
                        "Haskell",
                        "Java",
                        "JavaScript",
                        "Lisp",
                        "Perl",
                        "PHP",
                        "Python",
                        "Ruby",
                        "Scala",
                        "Scheme"]'>
                        <button type="submit">
                                <i class="fa fa-search"></i>
                        </button>
                        <a href="javascript:void(0);" id="cancel-search-js" title="Cancel Search"><i class="fa fa-times"></i></a>
                </form>
                <!-- end input: search field -->

                <!-- fullscreen button -->
                <div id="fullscreen" class="btn-header transparent pull-right">
                        <span> <a href="javascript:void(0);" data-action="launchFullscreen" title="Full Screen"><i class="fa fa-arrows-alt"></i></a> </span>
                </div>
                <!-- end fullscreen button -->

                <!-- multiple lang dropdown : find all flags in the flags page -->
                <ul class="header-dropdown-list hidden-xs">
                        <li>
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <img src="img/blank.gif" class="flag flag-us" alt="United States"> <span> US </span> <i class="fa fa-angle-down"></i> </a>
                                <ul class="dropdown-menu pull-right">
                                        <li class="active">
                                                <a href="javascript:void(0);"><img src="img/blank.gif" class="flag flag-us" alt="United States"> US</a>
                                        </li>
                                        <li>
                                                <a href="javascript:void(0);"><img src="img/blank.gif" class="flag flag-es" alt="Spanish"> Spanish</a>
                                        </li>
                                        <li>
                                                <a href="javascript:void(0);"><img src="img/blank.gif" class="flag flag-de" alt="German"> German</a>
                                        </li>
                                </ul>
                        </li>
                </ul>
                <!-- end multiple lang -->

        </div>
        <!-- end pulled right: nav area -->

</header>
<!-- END HEADER -->

<!-- Left panel : Navigation area -->
<!-- Note: This width of the aside area can be adjusted through LESS variables -->
<aside id="left-panel">

        <!-- User info -->
        <div class="login-info">
                <span> <!-- User image size is adjusted inside CSS, it should stay as it --> 

                        <a href="javascript:void(0);" id="show-shortcut" data-action="toggleShortcut">
                                <img src="img/avatars/sunny.png" alt="me" class="online" /> 
                                <span>
                                        john.doe 
                                </span>
                                <i class="fa fa-angle-down"></i>
                        </a> 

                </span>
        </div>
        <!-- end user info -->

        <!-- NAVIGATION : This navigation is also responsive

        To make this navigation dynamic please make sure to link the node
        (the reference to the nav > ul) after page load. Or the navigation
        will not initialize.
        -->
        <nav>
                <!-- NOTE: Notice the gaps after each icon usage <i></i>..
                Please note that these links work a bit different than
                traditional href="" links. See documentation for details.
                -->

                <ul>
                        <li>
                                <a href="index.html" title="Dashboard"><i class="fa fa-lg fa-fw fa-home"></i> <span class="menu-item-parent">Dashboard</span></a>
                        </li>
                        <li>
                                <a href="inbox.html"><i class="fa fa-lg fa-fw fa-inbox"></i> <span class="menu-item-parent">Inbox</span><span class="badge pull-right inbox-badge">14</span></a>
                        </li>
                        <li>
                                <a href="#"><i class="fa fa-lg fa-fw fa-bar-chart-o"></i> <span class="menu-item-parent">Graphs</span></a>
                                <ul>
                                        <li>
                                                <a href="flot.html">Flot Chart</a>
                                        </li>
                                        <li>
                                                <a href="morris.html">Morris Charts</a>
                                        </li>
                                        <li>
                                                <a href="inline-charts.html">Inline Charts</a>
                                        </li>
                                        <li>
                                                <a href="dygraphs.html">Dygraphs <span class="badge pull-right inbox-badge bg-color-yellow">new</span></a>
                                        </li>
                                </ul>
                        </li>
                        <li>
                                <a href="#"><i class="fa fa-lg fa-fw fa-table"></i> <span class="menu-item-parent">Tables</span></a>
                                <ul>
                                        <li>
                                                <a href="table.html">Normal Tables</a>
                                        </li>
                                        <li>
                                                <a href="datatables.html">Data Tables <span class="badge inbox-badge bg-color-greenLight">v1.10</span></a>
                                        </li>
                                        <li>
                                                <a href="jqgrid.html">Jquery Grid</a>
                                        </li>
                                </ul>
                        </li>
                        <li>
                                <a href="#"><i class="fa fa-lg fa-fw fa-pencil-square-o"></i> <span class="menu-item-parent">Forms</span></a>
                                <ul>
                                        <li>
                                                <a href="form-elements.html">Smart Form Elements</a>
                                        </li>
                                        <li>
                                                <a href="form-templates.html">Smart Form Layouts</a>
                                        </li>
                                        <li>
                                                <a href="validation.html">Smart Form Validation</a>
                                        </li>
                                        <li>
                                                <a href="bootstrap-forms.html">Bootstrap Form Elements</a>
                                        </li>
                                        <li>
                                                <a href="plugins.html">Form Plugins</a>
                                        </li>
                                        <li>
                                                <a href="wizard.html">Wizards</a>
                                        </li>
                                        <li>
                                                <a href="other-editors.html">Bootstrap Editors</a>
                                        </li>
                                        <li>
                                                <a href="dropzone.html">Dropzone </a>
                                        </li>
                                        <li>
                                                <a href="image-editor.html">Image Cropping <span class="badge pull-right inbox-badge bg-color-yellow">new</span></a>
                                        </li>
                                </ul>
                        </li>
                        <li>
                                <a href="#"><i class="fa fa-lg fa-fw fa-desktop"></i> <span class="menu-item-parent">UI Elements</span></a>
                                <ul>
                                        <li>
                                                <a href="general-elements.html">General Elements</a>
                                        </li>
                                        <li>
                                                <a href="buttons.html">Buttons</a>
                                        </li>
                                        <li>
                                                <a href="#">Icons</a>
                                                <ul>
                                                        <li>
                                                                <a href="fa.html"><i class="fa fa-plane"></i> Font Awesome</a>
                                                        </li>	
                                                        <li>
                                                                <a href="glyph.html"><i class="glyphicon glyphicon-plane"></i> Glyph Icons</a>
                                                        </li>	
                                                        <li>
                                                                <a href="flags.html"><i class="fa fa-flag"></i> Flags</a>
                                                        </li>
                                                </ul>
                                        </li>
                                        <li>
                                                <a href="grid.html">Grid</a>
                                        </li>
                                        <li>
                                                <a href="treeview.html">Tree View</a>
                                        </li>
                                        <li>
                                                <a href="nestable-list.html">Nestable Lists</a>
                                        </li>
                                        <li>
                                                <a href="jqui.html">JQuery UI</a>
                                        </li>
                                        <li>
                                                <a href="typography.html">Typography</a>
                                        </li>
                                        <li>
                                                <a href="#">Six Level Menu</a>
                                                <ul>
                                                        <li>
                                                                <a href="#"><i class="fa fa-fw fa-folder-open"></i> Item #2</a>
                                                                <ul>
                                                                        <li>
                                                                                <a href="#"><i class="fa fa-fw fa-folder-open"></i> Sub #2.1 </a>
                                                                                <ul>
                                                                                        <li>
                                                                                                <a href="#"><i class="fa fa-fw fa-file-text"></i> Item #2.1.1</a>
                                                                                        </li>
                                                                                        <li>
                                                                                                <a href="#"><i class="fa fa-fw fa-plus"></i> Expand</a>
                                                                                                <ul>
                                                                                                        <li>
                                                                                                                <a href="#"><i class="fa fa-fw fa-file-text"></i> File</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                                <a href="#"><i class="fa fa-fw fa-trash-o"></i> Delete</a></li>
                                                                                                </ul>
                                                                                        </li>
                                                                                </ul>
                                                                        </li>
                                                                </ul>
                                                        </li>
                                                        <li>
                                                                <a href="#"><i class="fa fa-fw fa-folder-open"></i> Item #3</a>

                                                                <ul>
                                                                        <li>
                                                                                <a href="#"><i class="fa fa-fw fa-folder-open"></i> 3ed Level </a>
                                                                                <ul>
                                                                                        <li>
                                                                                                <a href="#"><i class="fa fa-fw fa-file-text"></i> File</a>
                                                                                        </li>
                                                                                        <li>
                                                                                                <a href="#"><i class="fa fa-fw fa-file-text"></i> File</a>
                                                                                        </li>
                                                                                </ul>
                                                                        </li>
                                                                </ul>

                                                        </li>
                                                </ul>
                                        </li>
                                </ul>
                        </li>

                        <li>
                                <a href="calendar.html"><i class="fa fa-lg fa-fw fa-calendar"><em>3</em></i> <span class="menu-item-parent">Calendar</span></a>
                        </li>
                        <li>
                                <a href="widgets.html"><i class="fa fa-lg fa-fw fa-list-alt"></i> <span class="menu-item-parent">Widgets</span></a>
                        </li>
                        <li>
                                <a href="gallery.html"><i class="fa fa-lg fa-fw fa-picture-o"></i> <span class="menu-item-parent">Gallery</span></a>
                        </li>
                        <li>
                                <a href="gmap-xml.html"><i class="fa fa-lg fa-fw fa-map-marker"></i> <span class="menu-item-parent">GMap Skins</span><span class="badge bg-color-greenLight pull-right inbox-badge">9</span></a>
                        </li>
                        <li>
                                <a href="#"><i class="fa fa-lg fa-fw fa-windows"></i> <span class="menu-item-parent">Miscellaneous</span></a>
                                <ul>
                                        <li>
                                                <a href="#"><i class="fa fa-lg fa-fw fa-file"></i> Other Pages</a>
                                                <ul>
                                                        <li>
                                                                <a href="forum.html">Forum Layout</a>
                                                        </li>
                                                        <li>
                                                                <a href="profile.html">Profile</a>
                                                        </li>
                                                        <li>
                                                                <a href="timeline.html">Timeline</a>
                                                        </li>
                                                </ul>
                                        </li>
                                        <li>
                                                <a href="pricing-table.html">Pricing Tables</a>
                                        </li>
                                        <li>
                                                <a href="invoice.html">Invoice</a>
                                        </li>
                                        <li>
                                                <a href="login.html" target="_top">Login</a>
                                        </li>
                                        <li>
                                                <a href="register.html" target="_top">Register</a>
                                        </li>
                                        <li>
                                                <a href="lock.html" target="_top">Locked Screen</a>
                                        </li>
                                        <li>
                                                <a href="error404.html">Error 404</a>
                                        </li>
                                        <li>
                                                <a href="error500.html">Error 500</a>
                                        </li>
                                        <li>
                                                <a href="blank_.html">Blank Page</a>
                                        </li>
                                        <li>
                                                <a href="email-template.html">Email Template</a>
                                        </li>
                                        <li>
                                                <a href="search.html">Search Page</a>
                                        </li>
                                        <li>
                                                <a href="ckeditor.html">CK Editor</a>
                                        </li>
                                </ul>
                        </li>
                        <li class="top-menu-hidden active">
                                <a href="#"><i class="fa fa-lg fa-fw fa-cube txt-color-blue"></i> <span class="menu-item-parent">SmartAdmin Intel</span></a>
                                <ul>
                                        <li>
                                                <a href="difver.html"><i class="fa fa-stack-overflow"></i> Different Versions</a>
                                        </li>
                                        <li class="active">
                                                <a href="applayout.html"><i class="fa fa-cube"></i> App Settings</a>
                                        </li>
                                        <li>
                                                <a href="http://bootstraphunter.com/smartadmin/BUGTRACK/track_/documentation/index.html" target="_blank"><i class="fa fa-book"></i> Documentation</a>
                                        </li>
                                        <li>
                                                <a href="http://bootstraphunter.com/smartadmin/BUGTRACK/track_/" target="_blank"><i class="fa fa-bug"></i> Bug Tracker</a>
                                        </li>
                                </ul>
                        </li>
                </ul>
        </nav>
        <span class="minifyme" data-action="minifyMenu"> 
                <i class="fa fa-arrow-circle-left hit"></i> 
        </span>

</aside>
<!-- END NAVIGATION -->

<!-- MAIN PANEL -->
<div id="main" role="main">

        <!-- RIBBON -->
        <div id="ribbon">

                <span class="ribbon-button-alignment"> 
<span id="refresh" class="btn btn-ribbon" data-action="resetWidgets" data-title="refresh"  
       data-placement="bottom" data-original-title="<i class='text-warning fa fa-warning'></i> Warning! This will reset all your widget settings." data-html="true">
                                <i class="fa fa-refresh"></i>
                        </span> 
                </span>

                <!-- breadcrumb -->
                <ol class="breadcrumb">
                        <li>Home</li><li>SmartAdmin Intel</li><li>App Settings</li>
                </ol>
                <!-- end breadcrumb -->

                <!-- You can also add more buttons to the
                ribbon for further usability

                Example below:

                <span class="ribbon-button-alignment pull-right">
                <span id="search" class="btn btn-ribbon hidden-xs" data-title="search"><i class="fa-grid"></i> Change Grid</span>
                <span id="add" class="btn btn-ribbon hidden-xs" data-title="add"><i class="fa-plus"></i> Add</span>
                <span id="search" class="btn btn-ribbon" data-title="search"><i class="fa-search"></i> <span class="hidden-mobile">Search</span></span>
                </span> -->

        </div>
        <!-- END RIBBON -->



        <!-- MAIN CONTENT -->
        <div id="content">

                <!-- row -->
                <div class="row">

                        <!-- col -->
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER --><i class="fa fa-lg fa-fw fa-cube"></i> SmartAdmin Intel <span>>
                                        App Settings </span></h1>
                        </div>
                        <!-- end col -->

                </div>
                <!-- end row -->

                <!--
                The ID "widget-grid" will start to initialize all widgets below
                You do not need to use widgets if you dont want to. Simply remove
                the <section></section> and you can use wells or panels instead
                -->

                <!-- widget grid -->
                <section id="widget-grid" class="">

                        <!-- row -->
                        <div class="row">

                                <!-- NEW WIDGET START -->
                                <article class="col-xs-12 col-sm-12 col-md-12 col-lg-7">

                                        <!-- Widget ID (each widget will need unique ID)-->
                                        <div class="jarviswidget" id="wid-id-0" data-widget-colorbutton="false"	data-widget-editbutton="false" data-widget-togglebutton="false" data-widget-deletebutton="false" data-widget-fullscreenbutton="false">
                                                <header>
                                                        <h2> Menu Toggle / Collapse / Minify </h2>
                                                        <span class="badge pull-right margin-right-5 margin-top-5">new</span>
                                                </header>

                                                <!-- widget div-->
                                                <div>

                                                        <!-- widget edit box -->
                                                        <div class="jarviswidget-editbox">
                                                                <!-- This area used as dropdown edit box -->
                                                                <input class="form-control" type="text">
                                                        </div>
                                                        <!-- end widget edit box -->

                                                        <!-- widget content -->
                                                        <div class="widget-body no-padding">

                                                                <!-- this is what the user will see -->
                                                                <div class="padding-gutter">
                                                                        To toggle minify menu manually add the class <code>
                                                                                minified</code>
                                                                        to the <b><i>BODY</i></b> element. To collapse the main menu on desktops, add class <code>
                                                                                hidden-menu</code>
                                                                        to the <b><i>BODY</i></b> element.
                                                                        <br>
                                                                        <br>

                                                                        <span class="btn btn-default" data-action="minifyMenu"> Toggle .minify class </span>
                                                                        &nbsp;&nbsp;
                                                                        <button class="btn btn-default" data-action="toggleMenu">
                                                                                Toggle .collapse class
                                                                        </button>

                                                                </div>

                                                                <div class="table-responsive no-margin">

                                                                        <table class="table table-bordered">
                                                                                <thead>
                                                                                        <tr>
                                                                                                <th><b><i>attribute*</i></b></th>
                                                                                                <th>Description</th>
                                                                                                <th>Action</th>
                                                                                        </tr>
                                                                                </thead>
                                                                                <tbody>
                                                                                        <tr>
                                                                                                <td>
                                                                                                <code>
                                                                                                        data-action="userLogout"
                                                                                                </code></td>
                                                                                                <td>Logout message popup, use it with <code>
                                                                                                        data-logout-msg = "..."</code></td>
                                                                                                <td><a href="login.html" class="btn btn-default btn-xs" data-action="userLogout" data-logout-msg="Your message here..."> action </a></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td>
                                                                                                <code>
                                                                                                        data-action="resetWidgets"
                                                                                                </code></td>
                                                                                                <td>Resets all localStorage <i>(restores all app settings and widgets)</i></td>
                                                                                                <td>
                                                                                                <button class="btn btn-default btn-xs" data-action="resetWidgets">
                                                                                                        action
                                                                                                </button></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td>
                                                                                                <code>
                                                                                                        data-action="launchFullscreen"
                                                                                                </code></td>
                                                                                                <td>Launch full screen view <i>(works only in Chrome, Safari, Firefox and Latest IE)</i></td>
                                                                                                <td>
                                                                                                <button class="btn btn-default btn-xs" data-action="launchFullscreen">
                                                                                                        action
                                                                                                </button></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td>
                                                                                                <code>
                                                                                                        data-action="minifyMenu"
                                                                                                </code></td>
                                                                                                <td>Minify main nav <i>(works only with vertical menu case)</i></td>
                                                                                                <td>
                                                                                                <button class="btn btn-default btn-xs" data-action="minifyMenu">
                                                                                                        action
                                                                                                </button></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td>
                                                                                                <code>
                                                                                                        data-action="toggleMenu"
                                                                                                </code></td>
                                                                                                <td>Collapse left menu <i>(but still accessable by hovering left edge of screen)</i></td>
                                                                                                <td>
                                                                                                <button class="btn btn-default btn-xs" data-action="toggleMenu">
                                                                                                        action
                                                                                                </button></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td>
                                                                                                <code>
                                                                                                        data-action="toggleShortcut"
                                                                                                </code></td>
                                                                                                <td>Top slidedown / Metro menu toggle</td>
                                                                                                <td>
                                                                                                <button class="btn btn-default btn-xs" data-action="toggleShortcut">
                                                                                                        action
                                                                                                </button></td>
                                                                                        </tr>
                                                                                </tbody>
                                                                        </table>

                                                                </div>

                                                        </div>
                                                        <!-- end widget content -->

                                                </div>
                                                <!-- end widget div -->

                                        </div>
                                        <!-- end widget -->

                                        <!-- Widget ID (each widget will need unique ID)-->
                                        <div class="jarviswidget" id="wid-id-1" data-widget-colorbutton="false"	data-widget-editbutton="false" data-widget-togglebutton="false" data-widget-deletebutton="false" data-widget-fullscreenbutton="false">
                                                <header>
                                                        <h2>App Settings</h2>

                                                </header>

                                                <!-- widget div-->
                                                <div>

                                                        <!-- widget edit box -->
                                                        <div class="jarviswidget-editbox">
                                                                <!-- This area used as dropdown edit box -->
                                                                <input class="form-control" type="text">
                                                        </div>
                                                        <!-- end widget edit box -->

                                                        <!-- widget content -->
                                                        <div class="widget-body no-padding">

                                                                <!-- this is what the user will see -->
                                                                <div class="padding-gutter">
                                                                        <span class="badge bg-color-green">Note:</span> You can adjust these settings inside <span class="text-primary">app.js</span> file to your comfort.
                                                                </div>

                                                                <div class="table-responsive">

                                                                        <table class="table table-bordered margin-top-10">
                                                                                <thead>
                                                                                        <tr>
                                                                                                <th>Name</th>
                                                                                                <th>Default/Value</th>
                                                                                                <th>Description</th>
                                                                                        </tr>
                                                                                </thead>
                                                                                <tbody>
                                                                                        <tr>
                                                                                                <td><b><i>$.throttle_delay</i></b></td>
                                                                                                <td>
                                                                                                <code>
                                                                                                        350
                                                                                                </code></td>
                                                                                                <td>Impacts the responce rate of some of the responsive elements (lower value affects CPU but improves speed)</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td><b><i>$.menu_speed</i></b></td>
                                                                                                <td>
                                                                                                <code>
                                                                                                        235
                                                                                                </code></td>
                                                                                                <td>The rate at which the menu expands revealing child elements on click</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td><b><i>$.navAsAjax</i></b></td>
                                                                                                <td>
                                                                                                <code>
                                                                                                        true/false
                                                                                                </code></td>
                                                                                                <td>Your left nav in your app will no longer fire ajax calls, set it to false for HTML version</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td><b><i>$.enableJarvisWidgets</i></b></td>
                                                                                                <td>
                                                                                                <code>
                                                                                                        true/false
                                                                                                </code></td>
                                                                                                <td>Please make sure you have included "jarvis.widget.min.js" in your page for this below feature to work</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td><b><i>$.enableMobileWidgets</i></b></td>
                                                                                                <td>
                                                                                                <code>
                                                                                                        true/false
                                                                                                </code></td>
                                                                                                <td>Warning: Enabling mobile widgets could potentially crash your webApp if you have too many widgets running at once (<i>must have <b><i>$.enableJarvisWidgets</i></b> to
                                                                                                <code>true</code></i>)</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td><b><i>closedSign</i></b></td>
                                                                                                <td>
                                                                                                <code>
                                                                                                        fa-plus-square-o
                                                                                                </code></td>
                                                                                                <td>Menu open icon</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td><b><i>openedSign</i></b></td>
                                                                                                <td>
                                                                                                <code>
                                                                                                        fa-minus-square-o
                                                                                                </code></td>
                                                                                                <td>Menu close icon</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td><b><i>setup_widgets_desktop()</i></b></td>
                                                                                                <td><i>function<b>()</b></i></td>
                                                                                                <td>Setup widgets for desktop (<i>must have <b><i>$.enableJarvisWidgets</i></b> to
                                                                                                <code>
                                                                                                        true
                                                                                                </code></i>) </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td><b><i>setup_widgets_mobile()</i></b></td>
                                                                                                <td><i>function<b>()</b></i></td>
                                                                                                <td>Setup widgets for desktop <i>(must have <b>$.enableJarvisWidgets</b> and <b>$.enableMobileWidgets</b> to <code>true</code>)</i></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td><b><i>runAllCharts()</i></b></td>
                                                                                                <td><i>function<b>()</b></i></td>
                                                                                                <td>Runs all inline charts including: $.sparkline and $.easyPieChart</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td><b><i>runAllForms()</i></b></td>
                                                                                                <td><i>function<b>()</b></i></td>
                                                                                                <td>Runs all form related scripts such as $.select2, $.mask, $.datepicker and $.autocomplete</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                                <td><b><i>pageSetUp()</i></b></td>
                                                                                                <td><i>function<b>()</b></i></td>
                                                                                                <td>Runs the following functions all at once: <i>setup_widgets_desktop<b>()</b>, setup_widgets_mobile<b>()</b>, runAllCharts<b>()</b>, runAllForms<b>()</b></i> - and also activates all tooltip and popovers</td>
                                                                                        </tr>
                                                                                </tbody>
                                                                        </table>

                                                                </div>
                                                        </div>
                                                        <!-- end widget content -->

                                                </div>
                                                <!-- end widget div -->

                                        </div>
                                        <!-- end widget -->

                                </article>
                                <!-- WIDGET END -->

                                <article class="col-xs-12 col-sm-12 col-md-12 col-lg-5">

                                        <!-- Widget ID (each widget will need unique ID)-->
                                        <div class="jarviswidget" id="wid-id-2" data-widget-colorbutton="false"	data-widget-editbutton="false" data-widget-togglebutton="false" data-widget-deletebutton="false" data-widget-fullscreenbutton="false">
                                                <header>
                                                        <h2> Page layout options </h2>
                                                </header>

                                                <!-- widget div-->
                                                <div>

                                                        <!-- widget edit box -->
                                                        <div class="jarviswidget-editbox">
                                                                <!-- This area used as dropdown edit box -->
                                                                <input class="form-control" type="text">
                                                        </div>
                                                        <!-- end widget edit box -->

                                                        <!-- widget content -->
                                                        <div class="widget-body no-padding">

                                                                <div class="padding-gutter padding-bottom-0">
                                                                        Possible classes for the <b><i>BODY</i></b> tag: <code>
                                                                                smart-skin-{SKIN_NUMBER}</code>
                                                                        , <code>
                                                                                smart-rtl</code>
                                                                        , <code>
                                                                                fixed-header</code>
                                                                        , <code>
                                                                                fixed-navigation</code>
                                                                        , <code>
                                                                                fixed-ribbon</code>
                                                                        , <code>
                                                                                fixed-footer</code>
                                                                        , <code>
                                                                                container</code>

                                                                </div>

                                                                <!-- this is what the user will see -->
                                                                <div class="padding-gutter">
                                                                        <div style="background: #f1f1f1;border-radius:3px;overflow: hidden">
                                                                                <div style="width: 100%;height: auto;background:#ddd;font-size:11px;font-weight: bold;padding:13px 10px">
                                                                                        <img src="img/logo.png" alt="SmartAdmin" style="width:75px;">
                                                                                </div>
                                                                                <div style="width: 25%;height: 296px; background:#949291;" class="pull-left"></div>
                                                                                <div style="width: 75%;height: 255px; background:#f1f1f1;" class="pull-left">
                                                                                        <div style="width: 100%; height:20px; padding:3px; background:#C5C5C5; font-size:10px; font-weight: bold;">
                                                                                                <i class="fa fa-home"></i> breadcrumb &gt;
                                                                                        </div>
                                                                                </div>
                                                                                <div style="width: 75%;height: auto;background:#ddd;font-size:11px;font-weight: bold;padding:13px 10px" class="text-right pull-right">
                                                                                        Footer
                                                                                </div>
                                                                        </div>
                                                                </div>

                                                                <hr>

                                                                <div class="padding-gutter padding-top-0 padding-bottom-0">
                                                                        Switch to top menu by adding class <code>
                                                                                .menu-on-top</code>
                                                                </div>

                                                                <div class="padding-gutter">

                                                                        <div style="background: #f1f1f1;border-radius:3px;overflow: hidden">
                                                                                <div style="width: 100%;height: auto;background:#ddd;font-size:11px;font-weight: bold;padding:13px 10px">
                                                                                        <img src="img/logo.png" alt="SmartAdmin" style="width:75px;">
                                                                                </div>
                                                                                <div style="width: 100%;height: 50px; background:#949291;" class="pull-left"></div>
                                                                                <div style="width: 100%;height: 255px; background:#f1f1f1;" class="pull-left">
                                                                                        <div style="width: 100%; height:20px; padding:3px; background:#C5C5C5; font-size:10px; font-weight: bold;">
                                                                                                <i class="fa fa-home"></i> breadcrumb >
                                                                                        </div>
                                                                                </div>
                                                                                <div style="width: 100%;height: auto;background:#ddd;font-size:11px;font-weight: bold;padding:13px 10px" class="text-right pull-right">
                                                                                        Footer
                                                                                </div>
                                                                        </div>

                                                                </div>

                                                        </div>
                                                        <!-- end widget content -->

                                                </div>
                                                <!-- end widget div -->

                                        </div>
                                        <!-- end widget -->

                                </article>

                        </div>

                        <!-- end row -->

                        <!-- row -->

                        <div class="row">

                                <!-- a blank row to get started -->
                                <div class="col-sm-12">
                                        <!-- your contents here -->
                                </div>

                        </div>

                        <!-- end row -->

                </section>
                <!-- end widget grid -->

        </div>
        <!-- END MAIN CONTENT -->

</div>
<!-- END MAIN PANEL -->

<!-- PAGE FOOTER -->
<div class="page-footer">
        <div class="row">
                <div class="col-xs-12 col-sm-6">
                        <span class="txt-color-white">SmartAdmin WebApp © 2013-2014</span>
                </div>

                <div class="col-xs-6 col-sm-6 text-right hidden-xs">
                        <div class="txt-color-white inline-block">
                                <i class="txt-color-blueLight hidden-mobile">Last account activity <i class="fa fa-clock-o"></i> <strong>52 mins ago &nbsp;</strong> </i>
                                <div class="btn-group dropup">
                                        <button class="btn btn-xs dropdown-toggle bg-color-blue txt-color-white" data-toggle="dropdown">
                                                <i class="fa fa-link"></i> <span class="caret"></span>
                                        </button>
                                        <ul class="dropdown-menu pull-right text-left">
                                                <li>
                                                        <div class="padding-5">
                                                                <p class="txt-color-darken font-sm no-margin">Download Progress</p>
                                                                <div class="progress progress-micro no-margin">
                                                                        <div class="progress-bar progress-bar-success" style="width: 50%;"></div>
                                                                </div>
                                                        </div>
                                                </li>
                                                <li class="divider"></li>
                                                <li>
                                                        <div class="padding-5">
                                                                <p class="txt-color-darken font-sm no-margin">Server Load</p>
                                                                <div class="progress progress-micro no-margin">
                                                                        <div class="progress-bar progress-bar-success" style="width: 20%;"></div>
                                                                </div>
                                                        </div>
                                                </li>
                                                <li class="divider"></li>
                                                <li>
                                                        <div class="padding-5">
                                                                <p class="txt-color-darken font-sm no-margin">Memory Load <span class="text-danger">*critical*</span></p>
                                                                <div class="progress progress-micro no-margin">
                                                                        <div class="progress-bar progress-bar-danger" style="width: 70%;"></div>
                                                                </div>
                                                        </div>
                                                </li>
                                                <li class="divider"></li>
                                                <li>
                                                        <div class="padding-5">
                                                                <button class="btn btn-block btn-default">refresh</button>
                                                        </div>
                                                </li>
                                        </ul>
                                </div>
                        </div>
                </div>
        </div>
</div>
<!-- END PAGE FOOTER -->

<!-- SHORTCUT AREA : With large tiles (activated via clicking user name tag)
Note: These tiles are completely responsive,
you can add as many as you like
-->
<div id="shortcut">
        <ul>
                <li>
                        <a href="#inbox.html" class="jarvismetro-tile big-cubes bg-color-blue"> <span class="iconbox"> <i class="fa fa-envelope fa-4x"></i> <span>Mail <span class="label pull-right bg-color-darken">14</span></span> </span> </a>
                </li>
                <li>
                        <a href="#calendar.html" class="jarvismetro-tile big-cubes bg-color-orangeDark"> <span class="iconbox"> <i class="fa fa-calendar fa-4x"></i> <span>Calendar</span> </span> </a>
                </li>
                <li>
                        <a href="#gmap-xml.html" class="jarvismetro-tile big-cubes bg-color-purple"> <span class="iconbox"> <i class="fa fa-map-marker fa-4x"></i> <span>Maps</span> </span> </a>
                </li>
                <li>
                        <a href="#invoice.html" class="jarvismetro-tile big-cubes bg-color-blueDark"> <span class="iconbox"> <i class="fa fa-book fa-4x"></i> <span>Invoice <span class="label pull-right bg-color-darken">99</span></span> </span> </a>
                </li>
                <li>
                        <a href="#gallery.html" class="jarvismetro-tile big-cubes bg-color-greenLight"> <span class="iconbox"> <i class="fa fa-picture-o fa-4x"></i> <span>Gallery </span> </span> </a>
                </li>
                <li>
                        <a href="javascript:void(0);" class="jarvismetro-tile big-cubes selected bg-color-pinkDark"> <span class="iconbox"> <i class="fa fa-user fa-4x"></i> <span>My Profile </span> </span> </a>
                </li>
        </ul>
</div>
<!-- END SHORTCUT AREA -->

<!--================================================== -->

<!-- PACE LOADER - turn this on if you want ajax loading to show (caution: uses lots of memory on iDevices)-->
<script data-pace-options='{ "restartOnRequestAfter": true }' src="js/plugin/pace/pace.min.js"></script>

<!-- Link to Google CDN's jQuery + jQueryUI; fall back to local -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
<script>
        if (!window.jQuery) {
                document.write('<script src="js/libs/jquery-2.0.2.min.js"><\/script>');
        }
</script>

<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script>
        if (!window.jQuery.ui) {
                document.write('<script src="js/libs/jquery-ui-1.10.3.min.js"><\/script>');
        }
</script>

<!-- JS TOUCH : include this plugin for mobile drag / drop touch events
<script src="js/plugin/jquery-touch/jquery.ui.touch-punch.min.js"></script> -->

<!-- BOOTSTRAP JS -->
<script src="js/bootstrap/bootstrap.min.js"></script>

<!-- CUSTOM NOTIFICATION -->
<script src="js/notification/SmartNotification.min.js"></script>

<!-- JARVIS WIDGETS -->
<script src="js/smartwidgets/jarvis.widget.min.js"></script>

<!-- EASY PIE CHARTS -->
<script src="js/plugin/easy-pie-chart/jquery.easy-pie-chart.min.js"></script>

<!-- SPARKLINES -->
<script src="js/plugin/sparkline/jquery.sparkline.min.js"></script>

<!-- JQUERY VALIDATE -->
<script src="js/plugin/jquery-validate/jquery.validate.min.js"></script>

<!-- JQUERY MASKED INPUT -->
<script src="js/plugin/masked-input/jquery.maskedinput.min.js"></script>

<!-- JQUERY SELECT2 INPUT -->
<script src="js/plugin/select2/select2.min.js"></script>

<!-- JQUERY UI + Bootstrap Slider -->
<script src="js/plugin/bootstrap-slider/bootstrap-slider.min.js"></script>

<!-- browser msie issue fix -->
<script src="js/plugin/msie-fix/jquery.mb.browser.min.js"></script>

<!-- FastClick: For mobile devices -->
<script src="js/plugin/fastclick/fastclick.min.js"></script>

<!--[if IE 8]>

<h1>Your browser is out of date, please update your browser by going to www.microsoft.com/download</h1>

<![endif]-->

<!-- Demo purpose only -->
<script src="js/demo.min.js"></script>

<!-- MAIN APP JS FILE -->
<script src="js/app.min.js"></script>

<!-- PAGE RELATED PLUGIN(S) 
<script src="..."></script>-->

<script type="text/javascript">

        $(document).ready(function() {

                /* DO NOT REMOVE : GLOBAL FUNCTIONS!
                 *
                 * pageSetUp(); WILL CALL THE FOLLOWING FUNCTIONS
                 *
                 * // activate tooltips
                 * $("[rel=tooltip]").tooltip();
                 *
                 * // activate popovers
                 * $("[rel=popover]").popover();
                 *
                 * // activate popovers with hover states
                 * $("[rel=popover-hover]").popover({ trigger: "hover" });
                 *
                 * // activate inline charts
                 * runAllCharts();
                 *
                 * // setup widgets
                 * setup_widgets_desktop();
                 *
                 * // run form elements
                 * runAllForms();
                 *
                 ********************************
                 *
                 * pageSetUp() is needed whenever you load a page.
                 * It initializes and checks for all basic elements of the page
                 * and makes rendering easier.
                 *
                 */

                 pageSetUp();

                /*
                 * ALL PAGE RELATED SCRIPTS CAN GO BELOW HERE
                 * eg alert("my home function");
                 * 
                 * var pagefunction = function() {
                 *   ...
                 * }
                 * loadScript("js/plugin/_PLUGIN_NAME_.js", pagefunction);
                 * 
                 * TO LOAD A SCRIPT:
                 * var pagefunction = function (){ 
                 *  loadScript(".../plugin.js", run_after_loaded);	
                 * }
                 * 
                 * OR
                 * 
                 * loadScript(".../plugin.js", run_after_loaded);
                 */

        })

</script>

<!-- Your GOOGLE ANALYTICS CODE Below -->
<script type="text/javascript">
        var _gaq = _gaq || [];
                _gaq.push(['_setAccount', 'UA-XXXXXXXX-X']);
                _gaq.push(['_trackPageview']);

        (function() {
                var ga = document.createElement('script');
                ga.type = 'text/javascript';
                ga.async = true;
                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(ga, s);
        })();

</script>


