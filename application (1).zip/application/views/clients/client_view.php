<?php

/* 
 * Client_View
 * This displays the client View
 * Steve Thomas
 * 11/22/2015
 */

// get the var's that are used in this page
if(isset($cli_rec)): foreach ($cli_rec as $r): 
       $client_id = $r->client_id;
     $client_name = $r->client_name; 
    $contact_name = $r->contact_name;
   $contact_phone = $r->contact_phone; 
   $client_active = $r->status;
          $street = $r->client_street;
            $unit = $r->client_unit;
            $city = $r->client_city;
    $client_state = $r->client_state;
             $zip = $r->client_zipcode;
   
   
   
endforeach;
endif;
//get the product name to displat instead of the id.
//$product_name = $Prod->MODEL_NAME;

?>
<!-- MAIN PANEL -->
<div id="main" role="main">

        <!-- RIBBON -->
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>View</li>
                </ol>
        </div>
        <!-- MAIN CONTENT -->
        <div id="content">

                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-8">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube"></i> <?php echo $client_name; ?>
                                    <span>> View Client </span></h1>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-4">
                            <?php //echo $link_back; ?> 
                        </div>

                </div>
 
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">  
       <div class="panel panel-primary">
    <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
    </div>  
        
          <div class="panel-body">
            <div class="content"> 
                <div class="data"> 
                    <table> 
                        <tr> 
                            <td width="30%">ID</td> 
                            <td><?php echo $client_id; ?></td> 
                        </tr> 
                        <tr> 
                            <td valign="top">Client Name</td> 
                            <td><?php echo $client_name; ?></td> 
                        </tr> 
                        <tr> 
                            <td valign="top">Product</td> 
                            <td><?php echo $Prod->model_name; ?></td> 
                        </tr> 
                        <tr> 
                            <td valign="top">Contact</td> 
                            <td><?php echo $contact_name; ?></td> 
                        </tr> 
                        <tr> 
                            <td valign="top">Phone</td> 
                            <td><?php echo $contact_phone; ?></td> 
                        </tr> 

                        <tr> 
                            <td valign="top">Active</td> 
                            <td><?php $status = ($client_active === 'Active') ? 'Active' : 'Disabled'; 
                                        echo $status; ?>
                            </td> 
                        </tr> 
                       
                        <tr> 
                            <td valign="top">Address</td> 
                            <td><?php echo $street; ?></td> 
                        </tr> 
                        <tr> 
                            <td valign="top">Unit</td> 
                            <td><?php echo $unit; ?></td> 
                        </tr>
                        <tr> 
                            <td valign="top">City</td> 
                            <td><?php echo $city; ?></td> 
                        </tr>
                        <tr> 
                            <td valign="top">State</td> 
                            <td><?php echo $client_state; ?></td> 
                        </tr>
                        <tr> 
                            <td valign="top">Zipcode</td> 
                            <td><?php echo $zip; ?></td> 
                        </tr>

 
                        
                    </table> 
                </div> 
                    <br />
                    <?php //echo $link_back; ?> 
            </div>
        </div>    
       </div>
    </article>
   </div> <!-- end row -->
 
                <!-- new row -->
                           <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">  
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h1><?php echo $titlec; ?></h1>
                </div>  
        
                <div class="panel-body">                   
                    <div> 
                        <div class="paging">
                            <?php echo $pagination; ?>
                        </div> 
                        <div class="data">
                            <?php echo $table; ?>
                        </div> 
                        <div class="paging">
                            <?php echo $pagination; ?>
                        </div> <br /> 
                            <?php echo secure_anchor(
                                    'users/create_user/',
                                    '<i class="fa fa-lg fa-fw fa-user-plus txt-color-blue"></i> Add new user',
                                    array('class'=>'add')); ?> 
                    </div>        
                   
                </div>  
             </div>
          
    </article>
   </div>
                        <!-- end row -->
        </div>
        <!-- END MAIN CONTENT -->
</div>
<!-- END MAIN PANEL -->


                              