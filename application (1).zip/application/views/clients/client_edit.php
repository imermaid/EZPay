<?php

/* 
 * Client_Edit
 */

// get the var's that are used in this page
if(isset($cli_rec)): foreach ($cli_rec as $r): 
   $client_name    = $r->client_name; 
 //  $contact_name  = $r->contact_name;
 //  $contact_phone = $r->contact_phone; 
endforeach;
endif;
//if(isset($records)): foreach ($records as $row): 
//    $user_email = $row->user_email; 
//    $user_id = $row->user_id; 
//    $user_name = $row->user_name; 
//    endforeach;
//    endif; 
?>
<div id="main" role="main">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>Update</li>
                </ol>
        </div>
        <div id="content">
                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-8">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube"></i> <?php echo $client_name; ?>
                                    <span>> Edit Client </span></h1>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-4">
                            <?php echo $link_back; ?> 
                        </div>
                </div>
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">              
     <div class="panel panel-primary">
      <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
      </div>  
          <div class="panel-body">                                   
                                        
        <div class="content"> 
                    <?php echo '<h2>'.$message.'</h2>'; ?> 
                    <?php echo validation_errors(); ?>
                    <?php //echo form_open($action); ?> 
            <form action="<?php echo $action; ?>" method="post" autocomplete="off" id="form_client" name="form_client">
            <div class="data"> 
                <table> 
                    <tr> 
                        <td width="30%">ID</td> 
                        <td>
                            <input type="text" name="client_id" disabled class="text" value="<?php echo (isset($Client['client_id']))?$Client['client_id']:''; ?>"/>
                            <input type="hidden" name="client_id" value="<?php echo (isset($Client['client_id']))?$Client['client_id']:''; ?>"/>
                            
                        </td> 
                </tr> 
                <tr> 
                    <td valign="top">Client Name<span style="color:red;">*</span></td> 
                    <td>
                        <input type="text" name="client_name" value="<?php echo (set_value('client_name'))?set_value('client_name'):$Client['client_name']; ?>"/> 
                            <?php echo form_error('client_name'); ?>
                    </td> 
                </tr> 
                <tr> 
                    <td valign="top">Contact<span style="color:red;">*</span></td> 
                    <td>
                        <input type="text" name="contact_name" value="<?php echo set_value('contact_name')?set_value('contact_name'):$Client['contact_name']; ?>"/> 
                            <?php echo form_error('contact_name'); ?>
                    </td> 
                </tr> 
                <tr> 
                    <td valign="top">Phone<span style="color:red;">*</span></td> 
                    <td>
                        <input type="text" name="contact_phone" value="<?php echo set_value('contact_phone')?set_value('contact_phone'):$Client['contact_phone']; ?>"/> 
                            <?php echo form_error('contact_phone'); ?>
                    </td> 
                </tr> 
                <tr> 
                    <td valign="top">Config ID</td> 
                    <td>
                        <input type="text" name="conf_id" value="<?php echo set_value('conf_id')?set_value('conf_id'):$Client['conf_id']; ?>"/> 
                            <?php echo form_error('conf_id'); ?>
                    </td> 
                </tr> 
                 <tr> 
                    <td valign="top">Status<span style="color:red;">*</span></td> 
                    <td>
                        <select name="status">
                            <?php
                            $display = $Client['status'] == 'Disabled' ? 'Disabled' : 'Active';    
                            $def = (empty($Client['status'])) ? 'TRUE' : '';
                            ?>
                            
                            <option value="<?php echo $Client['status']; ?>" <?php echo set_select('status', $Client['status'], TRUE); ?> ><?php echo $display; ?></option>
                            <option value="Active" <?php echo set_select('status', $Client['status'], $def); ?> >Active</option>
                            <option value="Disabled" <?php echo set_select('status', $Client['status']); ?> >Disabled</option>
                        </select>
                       
                            <?php echo form_error('status'); ?>
                    </td> 
                </tr> 

                <tr> 
                    <td valign="top">Street Address<span style="color:red;">*</span></td> 
                    <td>
                        <input size="60" type="text" name="client_street" value="<?php echo set_value('client_street')?set_value('client_street'):$Client['client_street']; ?>"/> 
                            <?php echo form_error('client_street'); ?>
                    </td> 
                </tr> 
                <tr> 
                    <td valign="top">Unit/Suite/Building</td> 
                    <td>
                        <input size="60" type="text" name="client_unit" value="<?php echo set_value('client_unit')?set_value('client_unit'):$Client['client_unit']; ?>"/> 
                    </td> 
                </tr> 
                <tr> 
                    <td valign="top">City<span style="color:red;">*</span></td> 
                    <td>
                        <input size="60" type="text" name="client_city" value="<?php echo set_value('client_city')?set_value('client_city'):$Client['client_city']; ?>"/> 
                            <?php echo form_error('client_city'); ?>
                    </td> 
                </tr> 
                 <tr> 
                    <td valign="top">State<span style="color:red;">*</span></td> 
                    <td>
                        <?php
                       $selected = $Client['client_state']; 
                      echo form_dropdown('client_state', $States, $selected); 
                         ?>
                    </td> 
                </tr> 
                <tr> 
                    <td valign="top">Zipcode<span style="color:red;">*</span></td> 
                    <td>
                        <input type="text" name="client_zipcode" value="<?php echo set_value('client_zipcode')?set_value('client_zipcode'):$Client['client_zipcode']; ?>"/> 
                            <?php echo form_error('client_zipcode'); ?>
                    </td> 
                </tr>
                <tr> 
                    <td valign="top">Default Product<span style="color:red;">*</span></td> 
                    <td>
                        
                        <?php
                        if (uri_string() == "clients/add") {
                            $selected = "none";
                        } else {
                          $selected = $Client['default_product'];  
                        }
                        
                      echo form_dropdown('default_product', $Prods, $selected); 
                         ?>
                    </td> 
                </tr> 

                
                <tr> 
                    <td></td> 
                    <td>
                        <input type="submit" value="Save"/>
                    </td> 
                </tr> 
                </table> 
            </div> 

        <?= form_close(); ?>
        <br /> 
            <?php echo $link_back; ?> 
        </div>                        
           </div>
         <div class="panel-footer"> Edit Clients</div>
       </div>        
    </article>
   </div>
          
        </div><!-- END MAIN CONTENT -->
</div><!-- END MAIN PANEL -->


                              