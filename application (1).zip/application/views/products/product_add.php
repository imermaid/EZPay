<?php

/* 
 * Add Product
 * 02/15/2016
 * Steve Thomas
 */

// get the Client name this user is assigned to.
if(isset($cli_rec)): foreach ($cli_rec as $r): 
      $clientID  = $r->client_id;
   $client_name  = $r->client_name; 
endforeach;
endif;
?>
<style type="text/css">
    #form_prod .error {
    color: red;
}
</style>
<div id="main" role="main">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>Add Product</li>
                </ol>
        </div>
 <div id="content">
                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-4">
                            <?php echo $link_back; ?> 
                        </div>
                </div>
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">              
     <div class="panel panel-primary">
      <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
      </div>  
          <div class="panel-body">                                                               
        <div class="content"> 
            
             <?php 
             //*********************   Start Form   *****************************************
                    echo validation_errors(); 
                    $attributes = array('role' => 'form', 'id' => 'form_product');
                   // echo form_open($action, $attributes);  
                   // echo form_open('products/add');

           ?>
            <form action="<?php echo $action; ?>" method="post" autocomplete="off" id="form_prod" name="form_prod">
            <div class="well well-lg">
                
            <?php  echo form_fieldset('Product Details'); ?>  
          <div class="row">
              <p><?php echo $action; ?></p>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="prod_name">Product Name</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" id="prod_name" name="prod_name" class="form-control" placeholder="Product Name" 
                           value="<?php echo set_value('prod_name'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="prod_loan_type">Loan Type</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag txt-color-blue"></i></span>
                <?php $selected = set_value('prod_loan_type')?set_value('prod_loan_type'):'Standard 360';
                      echo form_dropdown('prod_loan_type', $LoanType, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div> 
                
          </div> 
          <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="prod_min_term">Minimum Term</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="prod_min_term" id="prod_min_term" class="form-control" placeholder="06" 
                           value="<?php echo set_value('prod_min_term'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="prod_max_term">Maximum Term</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="prod_max_term" class="form-control" placeholder="36"
                           value="<?php echo set_value('prod_max_term'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="prod_default_term">Default Term</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="prod_default_term" class="form-control" placeholder="12"
                           value="<?php echo set_value('prod_default_term'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
            </div> 
                <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="prod_min_rate">Minimum Rate</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="prod_min_rate" class="form-control" placeholder="9.00000"
                           value="<?php echo set_value('prod_min_rate'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="prod_max_rate">Maximum Rate</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="prod_max_rate" class="form-control" placeholder="21.99999"
                           value="<?php echo set_value('prod_max_rate'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="prod_default_rate">Default Rate</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="prod_default_rate" class="form-control" placeholder="12.99999"
                           value="<?php echo set_value('prod_default_rate'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="prod_min_amount">Minimum Amount</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="prod_min_amount" class="form-control" placeholder="500.00"
                           value="<?php echo set_value('prod_min_amount'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="prod_max_amount">Maximum Amount</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="prod_max_amount" class="form-control" placeholder="5000.00"
                           value="<?php echo set_value('prod_max_amount'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="prod_default_amount">Default Amount</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="prod_default_amount" class="form-control" placeholder="1000.00"
                           value="<?php echo set_value('prod_default_amount'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
            </div>    
            <div class="row"> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <label for="prod_default_freq">Default Frequency<span style="color:red;">* </span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag txt-color-blue"></i></span>
                <?php $selected = set_value('prod_default_freq') ? set_value('prod_default_freq') : 'Monthly';
                      echo form_dropdown('prod_default_freq', $PayCycle, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
                </div>
            </div>   
              <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <div class="input-group">
                <label for="prod_status">Status<span style="color:red;"> * </span></label><br>
                 <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <input type="radio" name="prod_status" 
                            value="Active" <?php echo  set_radio('prod_status', 'Active', TRUE, $radclass ); ?> /> Active
                    <input type="radio" name="user_status"
                           value="Disabled" <?php echo  set_radio('prod_status', 'Disabled', $radclass ); ?> /> Disabled
                </div>  
                </div>
            </div> 
                
            </div>  
         <?php echo form_fieldset_close(); ?>  
           </div>
        
           
        
                
       <div class="well well-lg"> 
           <?php  echo form_fieldset('User Information'); ?> 
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <label for="prod_decision_model">Decision Model<span style="color:red;">* </span></label><br>
                <div class="input-group">
                   <span class="input-group-addon"><i class="fa fa-download txt-color-blue"></i></span> 
                <select name="prod_decision_model" class="form-control">
                    <option value="Installment" <?php echo set_select('prod_decision_model', 'Installment', TRUE); ?> >Installment</option>
                    <option value="Revolving" <?php echo set_select('prod_decision_model', 'Revolving'); ?> >Revolving</option>
                </select>
                <span class="input-group-addon"></span>
                </div>
            </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <label for="prod_signature_type">Signature Type<span style="color:red;">* </span></label><br>
                <div class="input-group">
                   <span class="input-group-addon"><i class="fa fa-download txt-color-blue"></i></span> 
                <select name="prod_signature_type" class="form-control">
                    <option value="Print" <?php echo set_select('prod_signature_type', 'Print', TRUE); ?> >Print Docs</option>
                    <option value="Esign" <?php echo set_select('prod_signature_type', 'Esign'); ?> >Electronic Signature</option>
                </select>
                <span class="input-group-addon"></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                <label for="prod_state">State</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag txt-color-blue"></i></span>
                <?php $selected = set_value('prod_state')?set_value('prod_state'):'Georgia';
                      echo form_dropdown('prod_state', $States, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>    
                
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                  <label for="prod_int_abatement_term">Interest Abatement Term</label><br> 
                   <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                    <input type="text" name="prod_int_abatement_term"  class="form-control" placeholder="6"
                    value="<?php echo set_value('prod_int_abatement_term'); ?>"/> 
                    <span class="input-group-addon"></span> 
                  </div>
               </div>
               
            </div>
                
         
           <?php echo form_fieldset_close(); ?>
       </div>
                
               
            
           

            
          <div class="well well-lg">
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                
            <?php 
           
                    echo form_submit('submit_prod','Save Product Information', array('class' => 'pull-left btn btn-primary' ) ); 
                
            ?>
            </div>
             <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">   
            <?php echo form_reset('reset_prod','Reset', array('class' => 'pull-right' ) ); ?>
             </div>
            </div>
            </div>  
                 

        <?php echo form_close(); ?>
        <br /> 
            <?php echo $link_back; ?> 
        </div>                        
           </div>

       </div>        
    </article>
   </div>
        </div><!-- END MAIN CONTENT -->
</div><!-- END MAIN PANEL -->

<script type="text/javascript">

jQuery(function($){
     $("#prod_name").focus();
});
</script>

 <script>
		// validate custom application requirements form on keyup and submit
                $(function() {
		 $("#form_prod").validate({
                     onfocusout: function (element) {
                                $(element).valid();
                            },
			rules: {
				prod_name: {
                                     required: true,
                                    maxlength: 35
                                },
                                prod_loan_type: {
                                     required: true,
                                    maxlength: 15
                                },
				prod_min_term: {
                                    required: true,
                                    maxlength: 3
				},
                                prod_max_term: {
                                    required: true,
                                    maxlength: 3
				},
                            prod_default_term: {
                                    maxlength: 3
				},
                                prod_min_rate: {
                                    required: true,
                                    maxlength: 8
				},
                                prod_max_rate: {
                                    required: true,
                                    maxlength: 8
				},
                            prod_default_rate: {
                                    maxlength: 8
				},
                              prod_min_amount: {
                                  required: true,
                                    maxlength: 8
				},
                              prod_max_amount: {
                                    maxlength: 8
				},
                          prod_default_amount: {
                                    maxlength: 8
				},
                            prod_default_freq: {
                                    maxlength: 14
				},
                                prod_status: {
                                    required: true,
                                    maxlength: 10
				},
                          prod_decision_model: {
                                    required: true,
                                    maxlength: 10
				},
                          prod_signature_type: {
                                    required: true,
                                    maxlength: 10
				},
                      prod_int_abatement_term: {
                                    maxlength: 3
				},
                                   prod_state: {
                                    required: true,
                                    maxlength: 35
				}
                                
			},
			messages: {
				prod_name: {
                                        required: "Enter the Product Name",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                    },
				prod_loan_type: {
                                        required: "Enter the Loan Type",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                prod_min_term: {
                                        required: "Enter the Minimum Term",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                prod_max_term: {
                                        required: "Enter the Maximum Term",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                    },
				prod_default_term: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                 prod_min_rate: {
                                        required: "Enter the Minimum Rate",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                prod_max_rate: {
                                        required: "Enter the Maximum Rate",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                    },
				prod_default_rate: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                 prod_min_amount: {
                                        required: "Enter the Minimum Amount",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                prod_max_amount: {
                                        required: "Enter the Maximum Amount",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                    },
				prod_default_amount: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                prod_default_freq: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                prod_state: {
                                        required: "Enter the loan State",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                prod_status: {
                                        required: "Enter the Status",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                prod_decision_model: {
                                        required: "Enter the Decision Model",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                prod_signature_type: {
                                        required: "Enter the Signature Type",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                prod_int_abatement_term: {
                                        required: "Enter the Abatement Term",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                
				highlight: function(element, errorClass, validClass) {
                                    $(element).addClass(errorClass).removeClass(validClass);
                                    $(element.form).find("label[for=" + element.id + "]")
                                      .addClass(errorClass);
                                  },
                                  unhighlight: function(element, errorClass, validClass) {
                                    $(element).removeClass(errorClass).addClass(validClass);
                                    $(element.form).find("label[for=" + element.id + "]")
                                      .removeClass(errorClass);
                                  }
			}
                        });
			

		
	});
	</script>

                            