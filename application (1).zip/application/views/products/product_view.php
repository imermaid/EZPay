<?php

/* 
 * Client_View
 * This displays the client View
 * Steve Thomas
 * 11/22/2015
 */

// get the var's that are used in this page
if(isset($cli_rec)): foreach ($cli_rec as $r): 
   $client_name    = $r->client_name; 
endforeach;
endif;
?>
<!-- MAIN PANEL -->
<div id="main" role="main">

        <!-- RIBBON -->
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>View</li>
                </ol>
        </div>
        <!-- MAIN CONTENT -->
        <div id="content">

                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-8">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube"></i> <?php echo $client_name; ?>
                                    <span>> View Products </span></h1>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-4">
                            <?php echo $link_back; ?> 
                        </div>

                </div>
 
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">  
       <div class="panel panel-primary">
    <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
    </div>  
        
          <div class="panel-body">
            <div class="content"> 
                <div class="data"> 
                    <div class="well well-lg">  
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Product ID: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Prod->prod_id; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Product Name: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Prod->model_name; ?>
               </div>
           </div> 
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Convenient Fee: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Prod->conv_fee; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2">
                 <label>Percentage: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Prod->percent_fee; ?>
               </div>
           </div>
           
           
           
                        
                    
                         
           
          </div>
                    
             
                </div> 
                    <br />
                    <?php echo $link_back; ?> 
            </div>
        </div>    
       </div>
    </article>
   </div> <!-- end row -->
 
 
        </div>
        <!-- END MAIN CONTENT -->
</div>
<!-- END MAIN PANEL -->


                              