<?php

/* 
 * admin_main_view
 */

// get the var's that are used in this page
if(isset($cli_rec)): foreach ($cli_rec as $r): 
   $client_name    = $r->client_name; 
   $contact_name  = $r->contact_name;
   $contact_phone = $r->contact_phone; 
endforeach;
endif;

?>
<!-- MAIN PANEL -->
<div id="main" role="main">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>Products</li>
                </ol>
        </div>
        <!-- MAIN CONTENT -->
<div id="content">

<section id="widget-grid" class="">
 
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-8">
        <div class="jarviswidget">
                    <header>
                            <h2> Product Search </h2>
                            <span class="badge pull-right margin-right-5 margin-top-5"><?php echo $client_name; ?></span>
                    </header>
    <div class="padding-gutter">           
        <div class="list-group">
 


         

                            
            
                    </div> <!-- List-Group-->
                </div>
            </div><!-- jarviswidget -->
    </article>
      
   
    
<article class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
    <div class="list-group">
                            
        <div class="jarviswidget" >
                    <header>
                            <h2> Product List </h2>
                            <span class="badge pull-right margin-right-5 margin-top-5"><?php echo $tab; ?></span>
                    </header>
                    <div class="padding-gutter">
                        <div class="pagination pagination-lg">
                            <?php echo $pagination; ?>
                        </div> 
                        <div class="data">
                            <?php echo $table; ?>
                        </div> 
                        <div class="paging">
                            <?php echo $pagination; ?>
                        </div> <br /> 
                        
                            <?php echo secure_anchor(
                                    'products/add/',
                                    '<i class="fa fa-lg fa-fw fa-user-plus txt-color-blue"></i> New Product',
                                    array('class'=>'add')); ?> 
                    </div>
      </div>
    </div>
    </article>  
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
       
    </article> 
                                
                     
                </section>
        </div>
</div>
<!-- END MAIN PANEL -->

<script type="text/javascript">
$(function() {
    $("#search_id").focus();
    $( "tr:odd" ).css( "background-color", "#bbbbff" );
    $("tr").not(':first').hover(
  function () {
    $(this).css("background","#3074ae");
    $(this).css("color", "#ffffff");
  }, 
  function () {
    $(this).css("background","");
    $( "tr:odd" ).css( "background-color", "#bbbbff" );
    $(this).css("color", "#000000");

  }
);
    
});


 function HideContent(d) {
    document.getElementById(d).style.display = "none";
    }
    function ShowContent(d) {
    document.getElementById(d).style.display = "block";
    }
    function ReverseDisplay(d) {
    if(document.getElementById(d).style.display == "none") { document.getElementById(d).style.display = "block"; }
    else { document.getElementById(d).style.display = "none"; }
    }
</script>


