<?php
defined('BASEPATH') OR exit('No direct script access allowed');


if( ! isset( $optional_login ) )
{
//	echo '<h1>Login</h1>';
}
      $out_msg = '';
    $error_msg = '';
if( isset( $on_hold_message ) )
{
		// EXCESSIVE LOGIN ATTEMPTS ERROR MESSAGE
		$error_msg = '
			<div style="border:1px solid red; padding:2px;">
				<p><strong>
					Excessive Login Attempts
				</strong></p>
				<p>
					You have exceeded the maximum number of failed login<br />
					attempts that EZ Pay will allow.
				<p>
				<p>
					Your access to login and account recovery has been<br> blocked for ' . ( (int) config_item('seconds_on_hold') / 60 ) . ' minutes.
				</p>
				<p>
					Please use the ' . secure_anchor('users/recover','Account Recovery') . ' after ' . ( (int) config_item('seconds_on_hold') / 60 ) . ' minutes has passed,<br />
					or ' .secure_anchor('pages/contact','contact us'). ' if you require assistance gaining access to your account.
				</p>
			</div>
		';
	} else {

	if( isset( $login_error_mesg ) )
	{
		$error_msg = '
			<div style="border:1px solid red; padding:2px;">
				<p>Login Error: Invalid Username, Email Address, or Password.</p>
				<p>Username, email address and password are all case sensitive.</p>
			</div>
		';
	}

	if( $this->input->get('logout') )
	{
		$out_msg = '
			<div style="border:1px solid green; padding:2px;">
				<p>You have successfully logged out of EZ Pay.</p>
			</div>
		';
	}
        }
  ?>

<script type="text/javascript" language="JavaScript">
$(function() {
    $("#login_string").focus();
    $("#app_dob").datepicker({ 
        maxDate: "-18Y" 
    });
   
  });

</script>


<div id="main" role="main">

	<!-- MAIN CONTENT -->
	<div id="content" class="container">
            
           
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-10 col-lg-5">
				<h1 class="txt-color-red login-header-big">EZ Login</h1>
                                
                                
                 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="well no-padding">
 <?php
	echo form_open( $login_url, array( 
            'class' => 'std-form smart-form client-form',
            'id'  => 'login-form'
            ) ); 
        $mlen = config_item('max_chars_for_password'); 
?>

			
    <header>
        <h2><span class="fa fa-sign-in"> Sign In</span></h2>  
    </header>
                                    

    <fieldset>
        <div class="row">
            <?php echo $out_msg; ?>
             <?php echo $error_msg; ?>
        </div>
        
        <div class="row">
        <section class="pull-left padding-10">               
            <label for="login_string" class="form_label"><span class="fa fa-user-secret"> Username or Email</span></label><br>
    <input type="text" value="<?php echo set_value('login_string'); ?>" name="login_string" 
           id="login_string" class="form_input" autocomplete="off" maxlength="255" />

            </section>
                                </div>
                     <div class="row">
        <section class="pull-left padding-10">

            <label for="login_pass" class="form_label"><span class="fa fa-unlock"> Password</span></label><br>
    <?php echo '<input type="password" name="login_pass" id="login_pass" class="form_input password" autocomplete="off" maxlength="'.$mlen. '"/>'; ?>
            </section>
              </div>       
            <section>

		<?php
			if( config_item('allow_remember_me') )
			{
		?>

                                                    
                                                    

			<label for="remember_me" class="form_label">Remember Me</label>
			<input type="checkbox" id="remember_me" name="remember_me" value="yes" />

		<?php
			}
		?>
                            </section>
                                                    
		<section>
			<a href="<?php echo secure_site_url('users/recover'); ?>">
				Can't access your account?
			</a>
		</section>
        <section>
            <p><span class="fa fa-exclamation-triangle">  This is a proprietary software system, unauthorized access is not permitted. By entering, you agree to the terms and conditions.</span></p>
        </section>

<footer>
         
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <?php echo form_submit('submit','Login', array('class' => 'pull-right btn btn-primary', 'id' => 'submit_button' ) ); ?>
            </div>
            </div>
</footer>


<?php
echo form_close();
?>
            
                                                     </fieldset>
                                            
                        </div>
                 </div>
                        </div>
                </div>
        </div>
</div>       
            
<?php            
/* End of file form_login.php */
/* Location: views/users/form_login.php   */