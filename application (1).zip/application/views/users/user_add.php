<?php

/* 
 * Client_Edit
 */

// get the Client name this user is assigned to.
if(isset($cli_rec)): foreach ($cli_rec as $r): 
      $clientID  = $r->client_id;
   $client_name  = $r->client_name; 
endforeach;
endif;
?>
<script type="text/javascript" language="JavaScript">
$(function() {
    $("#app_primary_ssn").focus();
    $("#app_dob").datepicker({ 
        maxDate: "-18Y" 
    });
    $( "#app_spouse_dob" ).datepicker({ 
        maxDate: "-18Y" 
    });
    $( "#app_since" ).datepicker({ 
            maxDate: "+1D" 
    });
    $( "#app_id_expire" ).datepicker({ 
        minDate: "+1D" 
    });
    $('#app_mailing_no').change(function(){
        if($('#app_mailing_no').val() === 'No'){
            $('#mailing').show();
    }
    });
    $('#app_mailing_yes').change(function(){
        if($('#app_mailing_yes').val() === 'Yes'){
            $('#mailing').hide();
    }
    });
  });
jQuery(function($){
   $("#app_dob").mask("99/99/9999");
   $("#app_spouse_dob").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#app_id_expire").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
   $("#user_phone").mask("(999) 999-9999");
   $("#app_altphone").mask("(999) 999-9999");
   $("#app_primary_ssn").mask("999-99-9999");
   $("#app_spouse_ssn").mask("999-99-9999");
});
</script>
<div id="main" role="main">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href="<?php base_url(); ?>">Home</a></li>
                    <li><a href="<?php echo secure_site_url('dashboard'); ?>">Dashboard</a></li>
                    <li><a href="<?php echo secure_site_url('users/index'); ?>">Users</a></li>
                    <li>Add</li>
                </ol>
        </div>
        <div id="content">
                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-10 col-lg-8">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube"></i> <?php echo $client_name; ?>
                                    <span>> Add User </span></h1>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-2 col-lg-4">
                            <?php echo $link_back; ?> 
                        </div>
                </div>
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">              
     <div class="panel panel-primary">
      <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
      </div>  
          <div class="panel-body">                                   
                                        
        <div class="content"> 
            
         <div class="content">

             <?php 
             //*********************   Start Form   *****************************************
                    echo validation_errors(); 
                    $attributes = array('role' => 'form', 'id' => 'form_user');
                    echo form_open($action, $attributes); 
                    echo form_hidden('client_id', $clientID); 

           ?>
            <div class="well well-lg">
                
            <?php  echo form_fieldset('User Authentication'); ?>  
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="user_name">User Name</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="user_name" class="form-control" 
                           value="<?php echo set_value('user_name'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="user_pass">Password</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="password" name="user_pass" class="form-control" 
                           value=""/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="passconf">Confirm Password</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="password" name="passconf" class="form-control" 
                           value=""/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
            </div>
                
        <?php echo form_fieldset_close(); ?>
            </div>
                
       <div class="well well-lg">
                
            <?php  echo form_fieldset('User Authorization'); ?>          
            <div class="row"> 
                 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="user_level">User Level</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                <?php $selected = array(set_value('user_level')?set_value('user_level'):'user');
                      echo form_dropdown('user_level', $Level, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
              <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <div class="input-group">
                <label for="user_status">Status<span style="color:red;"> * </span></label><br>
                 <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <input type="radio" name="user_status" 
                            value="Active" <?php echo  set_radio('user_status', 'Active', TRUE, $radclass ); ?> /> Active
                    <input type="radio" name="user_status"
                           value="Disabled" <?php echo  set_radio('user_status', 'Disabled', $radclass ); ?> /> Disabled
                </div>  
                </div>
            </div> 
                
            </div>  
         <?php echo form_fieldset_close(); ?>  
           </div>
        
           
        
                
       <div class="well well-lg"> 
           <?php  echo form_fieldset('User Information'); ?> 
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                  <label for="user_fname">First Name<span style="color:red;">*</span></label><br> 
                   <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                    <input type="text" name="user_fname"  class="form-control" 
                    value="<?php echo set_value('user_fname'); ?>"/> 
                    <span class="input-group-addon"></span> 
                  </div>
               </div>
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                  <label for="user_mname">Middle Initial</label><br> 
                  <div class="input-group">
                   <span class="input-group-addon"><i class="fa fa-user"></i></span>
                   <input type="text" name="user_mname"  class="form-control" 
                   value="<?php echo set_value('user_mname'); ?>"/> 
                   <span class="input-group-addon"></span>
                  </div>
               </div>
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                  <label for="user_lname">Last Name</label><br> 
                  <div class="input-group">
                   <span class="input-group-addon"><i class="fa fa-user"></i></span>
                   <input type="text" name="user_lname"  class="form-control" 
                   value="<?php echo set_value('user_lname'); ?>"/> 
                   <span class="input-group-addon"></span>
                  </div>
               </div>
            </div>
                
                
            <div class="row">    
             <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
            
                <label for="user_email">Email</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                <input type="text" name="user_email" class="form-control" 
                       value="<?php echo set_value('user_email'); ?>"/>
                <span class="input-group-addon"></span>
            </div>
            </div>  
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                 <label for="user_phone">Phone<span style="color:red;">*</span></label><br>
                     <div class="input-group">
                       <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                       <input type="tel" name="user_phone" id="user_phone" class="form-control" 
                       value="<?php echo set_value('user_phone'); ?>"/> 
                    <span class="input-group-addon"></span>
                     </div>
            </div>   
            </div>
           <?php echo form_fieldset_close(); ?>
       </div>
                
             <div class="well well-lg">
              <?php echo form_fieldset('User Address'); ?>  
            <div class="row">
            
              
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="user_street">Street Address<span style="color:red;">*</span></label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-map-signs"></i></span>
                <input type="text" class="form-control" 
                       name="user_street" value="<?php echo set_value('user_street'); ?>"/> 
                <span class="input-group-addon"></span>
                            
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                <label for="user_unit">Unit/Apt/Bldg</label><br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-building-o"></i></span>
                <input type="text" class="form-control" 
                       name="user_unit" value="<?php echo set_value('user_unit'); ?>"/> 
                <span class="input-group-addon"></span>
            </div>
            </div>
            </div> <!-- End STREET Row -->
            <div class="row"> 
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="user_city">City</label><br>
            <div class="input-group">
               
                <span class="input-group-addon"><i class="fa fa-map-pin"></i></span>
                <input type="text" class="form-control" 
                       name="user_city" value="<?php echo set_value('user_city'); ?>"/> 
                <span class="input-group-addon"></span>
                                  
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="user_state">State</label><br>
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                <?php $selected = array(set_value('user_state')?set_value('user_state'):'Georgia');
                      echo form_dropdown('user_state', $States, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
            </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="user_zipcode">Zipcode</label><br>
            <div class="input-group">
                <span class="input-group-addon"></span>
                <input type="text" name="user_zipcode" class="form-control" value="<?php echo set_value('user_zipcode'); ?>"/> 
                <span class="input-group-addon"></span>
                                   
            </div>
            </div> 
                
            </div><!-- // end CITY STATE ZIP row -->
            <?php echo form_fieldset_close(); ?> 
          </div><!-- end well -->    
            
           
         </div>
            
          <div class="well well-lg">
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                
            <?php 
           
                    echo form_submit('submit_user','Save User Information', array('class' => 'pull-left btn btn-primary' ) ); 
                
            ?>
            </div>
             <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">   
            <?php echo form_reset('reset_user','Reset', array('class' => 'pull-right' ) ); ?>
             </div>
            </div>
            </div>  
                 

        <?php echo form_close(); ?>
        <br /> 
            <?php echo $link_back; ?> 
        </div>                        
           </div>

       </div>        
    </article>
   </div>
            <div class="row">
                    <div class="col-sm-12">
                            <!-- some contents here -->
                    </div>
            </div>
        </div><!-- END MAIN CONTENT -->
</div><!-- END MAIN PANEL -->

<script type="text/javascript">
 
         $(document).ready(function(){
            $("#user_name").change(function(){
                 $("#message").html("<img src='ajax-loader.gif' /> checking...");
             
 
            var user_name = $("#user_name").val();
 
              $.ajax({
                    type:"post",
                    url:"create_user",
                    data:"user_name="+user_name,
                        success:function(data){
                        if(data==0){
                            $("#message").html("<img src='tick.png' /> Username available");
                        }
                        else{
                            $("#message").html("<img src='cross.png' /> Username already taken");
                        }
                    }
                 });
 
            });
 
         });
 
       </script>

                              