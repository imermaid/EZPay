<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// get the var's that are used in this page
if(isset($cli_rec)): foreach ($cli_rec as $r): 
   $client_id     = $r->client_id; 
   $client_name   = $r->client_name; 
endforeach;
endif;

?>





<!-- MAIN PANEL -->
<div id="main" role="main">

        <!-- RIBBON -->
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href="<?php base_url(); ?>">Home</a></li>
                    <li><a href="<?php echo secure_site_url('dashboard'); ?>">Dashboard</a></li>
                    <li>View</li>
                </ol>
        </div>
        <!-- MAIN CONTENT -->
        <div id="content">
                <div class="row">

                        <!-- col -->
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube"></i> <?php echo $client_name; ?>
                                    <span>> View Users </span></h1>
                        </div>
                </div>
 
   <div class="row">
          <!-- table -->

    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">  
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h1><?php echo $title; ?></h1>
                </div>  
        
                <div class="panel-body">                   
                    <div class="well well-lg"> 
                       <div class="pagination pagination-lg">
                            <?php echo $pagination; ?>
                        </div> 
                        <div class="data">
                            <?php echo $table; ?>
                        </div> 
                        <div class="paging">
                            <?php echo $pagination; ?>
                        </div> <br /> 
                        <?php if($this->auth_level >= 6){ 
                             echo secure_anchor(
                                    'users/create_user/',
                                    '<i class="fa fa-lg fa-fw fa-user-plus txt-color-blue"></i> Add new users',
                                    array('class'=>'add')); 
                        }
                        ?> 
                    </div>                    
                </div>  
             </div>
          
    </article>
   </div>
    </div>
        <!-- END MAIN CONTENT -->

</div>
<!-- END MAIN PANEL -->

<script type="text/javascript">
$(function() {
    $("#search_id").focus();
    $("#app_phone").mask("(999) 999-9999");
    $("#app_primary_ssn").mask("999-99-9999");
    $( "tr:odd" ).css( "background-color", "#dbdbdb" );
    $("tr").not(':first').hover(
  function () {
    $(this).css("background","#3074ae");
    $(this).css("color", "#ffffff");
  }, 
  function () {
    $(this).css("background","");
    $( "tr:odd" ).css( "background-color", "#dbdbdb" );
    $(this).css("color", "#000000");

  }
);
    
});


 function HideContent(d) {
    document.getElementById(d).style.display = "none";
    }
    function ShowContent(d) {
    document.getElementById(d).style.display = "block";
    }
    function ReverseDisplay(d) {
    if(document.getElementById(d).style.display == "none") { document.getElementById(d).style.display = "block"; }
    else { document.getElementById(d).style.display = "none"; }
    }
</script>                                