<?php

/* 
 * Add Loans
 * 03/5/2016
 * Steve Thomas
 */

?>
<style type="text/css">
    #form_bank .error {
    color: red;
}
</style>
<div id="main" role="main">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>Add A Loan</li>
                </ol>
        </div>
 <div id="content">
                <div class="row">
                    <ul class="pager">
                    <li class="previous"><?php echo $link_dash; ?></li>
                                     <li><?php echo $link_view; ?></li>
                        <li class="next"><?php echo $link_app; ?></li>
                    </ul>

                </div>
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">              
     <div class="panel panel-primary">
      <div class="panel-heading">
        <h1><?php echo $title; ?></h1>
      </div>  
          <div class="panel-body">                                                               
        <div class="content"> 
            
             <?php 
             //*********************   Start Form   *****************************************
                    echo validation_errors(); 
                    $attributes = array('role' => 'form', 'id' => 'form_loan');
                   // echo form_open($action, $attributes);  
                   // echo form_open('products/add');

           ?>
             <form action="<?php echo $action; ?>" method="post" autocomplete="off" id="form_loan" name="form_loan">
                  <input type="hidden" name="id" value="<?php echo $id; ?>" />
            <div class="well well-lg">
                
            <?php  echo form_fieldset('Loan Details'); ?>  
          <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="bank_name">Bank Name</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" id="bank_name" name="bank_name" class="form-control" placeholder="Bank Name" 
                                value="<?php echo set_value('bank_name'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                
          </div> 
          <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="bank_branch">Branch</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="bank_branch" id="bank_branch" class="form-control"
                           value="<?php echo set_value('bank_branch'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="bank_account">Bank Account Number</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="bank_account" class="form-control"
                           value="<?php echo set_value('bank_account'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="bank_routing">Routing Number</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="bank_routing" id="bank_routing" class="form-control"
                           value="<?php echo set_value('bank_routing'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
            </div> 
                <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="bank_address">Bank Street Address</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="bank_address" class="form-control"
                           value="<?php echo set_value('bank_address'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="bank_city">City</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="bank_city" class="form-control" 
                           value="<?php echo set_value('bank_city'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="bank_state">State</label><br>
                   <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                <?php $selected = array(set_value('bank_state')?set_value('bank_state'):'Georgia');
                      echo form_dropdown('bank_state', $States, $selected, array('class' => 'form-control'));  ?>
                <span class="input-group-addon"></span>
                 </div>
                </div> 
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="bank_zip">Zipcode</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="bank_zip" id="bank_zip" class="form-control" 
                           value="<?php echo set_value('bank_zip'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="bank_deposit_routing">Deposit Routing(if different)</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="bank_deposit_routing" class="form-control" placeholder="123456789"
                           value="<?php echo set_value('bank_deposit_routing'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                    <label for="bank_deposit_account">Deposit Account(if different)</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="bank_deposit_account" class="form-control" 
                           value="<?php echo set_value('bank_deposit_account'); ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
            </div>    
            <div class="row"> 
                
              <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                <div class="input-group">
                <label for="bank_status">Status<span style="color:red;"> * </span></label><br>
                  <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); 
                            $act = (set_value('bank_status') == "Active")? TRUE :"";
                            $dis = (set_value('bank_status') == "Disabled" || set_value('bank_status') == '')? TRUE :"";
                            ?>  
                     <input type="radio" name="bank_status" 
                            value="Active" <?php echo  set_radio('bank_status', 'Active', $act, $radclass); ?> /> Active
                    <input type="radio" name="bank_status"
                           value="Disabled" <?php echo  set_radio('bank_status', 'Disabled', $dis, $radclass); ?> /> Disabled
                </div>  
                </div>
            </div> 
                
            </div>  
         <?php echo form_fieldset_close(); ?>  
           </div>
        

          <div class="well well-lg">
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                
            <?php 
           
                    echo form_submit('submit_bank','Save Bank Information', array('class' => 'pull-left btn btn-primary' ) ); 
                
            ?>
            </div>
             <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">   
            <?php echo form_reset('reset_prod','Reset', array('class' => 'pull-right' ) ); ?>
             </div>
            </div>
            </div>  
                 

        <?php echo form_close(); ?>

        </div>                        
           </div>

       </div>        
    </article>
   </div>
        </div><!-- END MAIN CONTENT -->
</div><!-- END MAIN PANEL -->

<script type="text/javascript">

jQuery(function($){
     $("#bank_name").focus();
     $("#bank_zip").mask("99999");
     $("#bank_routing").mask("999999999");
});
</script>

 <script>
		// validate custom application requirements form on keyup and submit
                $(function() {
		 $("#form_bank").validate({
                     onfocusout: function (element) {
                                $(element).valid();
                            },
			rules: {
				bank_name: {
                                     required: true,
                                    maxlength: 45
                                },
                                bank_branch: {
                                    maxlength: 45
                                },
				bank_account: {
                                    required: true,
                                    maxlength: 20
				},
                                bank_routing: {
                                    required: true,
                                      digits: true,
                                      minlength: 5,
                                      maxlength: 5
				},
                                bank_address: {
                                    maxlength: 65
				},
                                   bank_city: {
                                    maxlength: 45
				},
                                  bank_state: {
                                    maxlength: 45
				},
                                    bank_zip: {
                                    maxlength: 5
				},
                        bank_deposit_account: {
                                    maxlength: 20
				},
                        bank_deposit_routing: {
                                    maxlength: 9
				},
                                 bank_status: {
                                    maxlength: 14
				}
                            
                                
			},
			messages: {
				bank_name: {
                                        required: "Enter the Bank Name",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                    },
				bank_branch: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                bank_acount: {
                                        required: "Enter the Account Number",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                bank_routing: {
                                        required: "Enter the Routing Number",
                                        maxlength: jQuery.validator.format("No more than {0} characters"),
                                        minlength: jQuery.validator.format("Must be {0} characters")
                                    },
				bank_address: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                 bank_city: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                bank_state: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                    },
				bank_zip: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                 bank_deposit_routing: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                bank_deposit_account: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                    },
				bank_status: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                
                                
				highlight: function(element, errorClass, validClass) {
                                    $(element).addClass(errorClass).removeClass(validClass);
                                    $(element.form).find("label[for=" + element.id + "]")
                                      .addClass(errorClass);
                                  },
                                  unhighlight: function(element, errorClass, validClass) {
                                    $(element).removeClass(errorClass).addClass(validClass);
                                    $(element.form).find("label[for=" + element.id + "]")
                                      .removeClass(errorClass);
                                  }
			}
                        });
			

		
	});
	</script>
