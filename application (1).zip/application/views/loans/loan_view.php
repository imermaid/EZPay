<?php

/* 
 * Loan_View
 * This displays the loan View
 * Steve Thomas
 * 03/05/2016
 */

// get the var's that are used in this page

if(empty($Loan['loa_id']) || $Loan['loa_id'] == '') {
                             //  $data['id'] = $id;
                          $Loan['loa_id'] = '';
                       $Loan['loa_status']  = '';
                     $Loan['loa_requestdate']  = '';
                              
} 
$app_name  = $Loan['app_fname']. ' '.$Loan['app_lname'];  
 $app_address = $Loan['app_street']. ' '.$Loan['app_unit'].'<br>'.$Loan['app_city'].', '.$Loan['app_state'].' '.$Loan['app_zipcode'];
 
 $appStatClass = ($Loan['app_status'] == 'Incomplete' ) ? 'label label-danger' : 'label label-success';
 $loanStatClass = ($Loan['loa_status'] == 'Funded' ) ? 'label label-success' : 'label label-warning';
?>
<!-- MAIN PANEL -->
<div id="main" role="main">

        <!-- RIBBON -->
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>View</li>
                </ol>
        </div>
        <!-- MAIN CONTENT -->
        <div id="content">
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">  
       <div class="panel panel-primary">
    <div class="panel-heading">
        <h1><?php echo $title; ?><span class="pull-right"><?php echo $app_name;?></span></h1>
    </div>  
          <div class="panel-body">
            <div class="content"> 
                <div class="row">
                    <ul class="pager">
                    <li class="previous"><?php echo $link_dash; ?></li>
                    <?php if(empty($Loan['loa_id']) || $Loan['loa_id'] == '') 
                        { 
                         echo '<li>' .$link_add. '</li>';
                    } else {
                        echo '<li>' .$link_update. '</li>';
                    } ?>
                    <li class="next"><?php echo $link_app; ?></li>
                    </ul>
                </div>
                <div class="data"> 
          <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">          
          <div class="well well-lg">  
                <h2 class="text-align-center">Loan Information</h2>        
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Loan ID: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['loa_id']; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Loan Type: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['loa_type']; ?>
               </div>
           </div> 
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Loan Status: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo '<span class="'.$loanStatClass.'">'. $Loan['loa_status'].'</span>'; ?>   
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Request Date: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['loa_requestdate']; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Active Date: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['loa_activedate']; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Loan Amount: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['loa_amount']; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Terms: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['loa_terms']; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Risk Discount: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['risk_discount']; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Down Payment: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['down_payment']; ?>
               </div>
           </div> 
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Approval Amount: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['approval_amount']; ?>
               </div>
           </div>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Approval Term: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['approval_term']; ?>
               </div>
           </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Bid Percent: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['bid_percent']; ?>
               </div>
           </div>   
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Signing: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['esign']; ?>
               </div>
           </div> 
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Interest Rate: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['interest_rate']; ?>
               </div>
           </div> 

          </div>
          </div><!-- div col-6 -->  
          <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
           <div class="well well-lg">  
               <h2 class="text-align-center">Applicant Information</h2>
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Application Status: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo '<span class="'.$appStatClass.'">'. $Loan['app_status'].'</span>'; ?>
               </div>
           </div>  
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Applicant Name: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $app_name; ?>
               </div>
           </div> 
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Application ID: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['app_id']; ?>
               </div>
           </div> 
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Applicant Address: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $app_address; ?>
               </div>
           </div>  
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Applicant Phone: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php echo $Loan['app_phone']; ?>
               </div>
           </div> 
           <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                 <label>Applicant Email: </label>
               </div> 
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <?php 
                echo $Loan['app_email']; ?>
               </div>
           </div>     
               
               
           </div> <!-- well -->
          </div> <!-- col-6 -->
                </div> <!-- data -->

            </div>
        </div>    
       </div>
    </article>
   </div> <!-- end row -->
 
 
        </div>
        <!-- END MAIN CONTENT -->
</div>
<!-- END MAIN PANEL -->


                              