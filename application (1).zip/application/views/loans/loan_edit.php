<?php

/* 
 * Loan_Edit
 * 03/5/2016
 * Steve Thomas
 */
//$appl_name = $Appl->app_fname. " " .$Appl->app_mname. " " .$Appl->app_lname. " " .$Appl->app_suffix;
?>
<style type="text/css">
    #form_loan .error {
    color: red;
}
</style>
<div id="main" role="main">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href="<?php echo base_url(); ?>">Home</a></li><li>Update</li>
                </ol>
        </div>
        <div id="content">
   <div class="row">
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-10">              
     <div class="panel panel-primary">
      <div class="panel-heading">
        <h1><?php echo $title; ?><span class="pull-right"><?php //echo $appl->appl_name;?></span></h1>
      </div>  
          <div class="panel-body">                                   
                                        
        <div class="content"> 
                <ul class="pager">
                    <li class="previous"><?php echo $link_dash; ?></li>
                                     <li><?php echo $link_view; ?></li>
                        <li class="next"><?php echo $link_app; ?></li>
                </ul>
       <?php
       if(empty($Loan)) {
           $msg = "No Redords";
       } else {
           $msg = $Loan->loa_type;
       }
       ?>
            
                    <?php echo validation_errors(); ?>
                   <form action="<?php echo $action; ?>" method="post" autocomplete="off" id="form_loan" name="form_loan">
                       <input type="hidden" name="id" value="<?php echo $id; ?>" />
            <div class="well well-lg">
                
            <?php  echo form_fieldset('Loan Details for Loan # ' .$Loan->loa_id); ?>  
          <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
                    <label for="app_id">Application ID</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="app_id" readonly="readonly" class="form-control"
                           value="<?php echo $Loan->app_id; ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div>
               <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
                    <label for="loa_requestdate">Request Date</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="loa_requestdate" readonly="readonly" class="form-control"
                           value="<?php echo $Loan->loa_requestdate; ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div>
               <div class="col-xs-12 col-sm-12 col-md-4 col-lg-3">
                    <label for="loa_activedate">Loan Active Date</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="loa_activedate" readonly="readonly" class="form-control"
                           value="<?php echo $Loan->loa_activedate; ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                
          </div> 
          <div class="row">
                 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <label for="loa_type">Loan Type</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                        <?php $selected = ($Loan->loa_type)?$Loan->loa_type:'Standard 360';
                        echo form_dropdown('loa_type', $LoanType, $selected, array('class' => 'form-control'));  ?>
                        <span class="input-group-addon"></span>
                        
                     </div>
                </div> 
                 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <label for="loa_status">Loan Status</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                        <?php $selected = ($Loan->loa_status)?$Loan->loa_status:'Pending';
                        echo form_dropdown('loa_status', $LoanStatus, $selected, array('class' => 'form-control'));  ?>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <label for="loa_amount">Requested Loan Amount</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="loa_amount" class="form-control" 
                           value="<?php echo $Loan->loa_amount; ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <label for="loa_terms">Requested Term</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                        <?php $selected = ($Loan->loa_terms)?$Loan->loa_terms:'12';
                        echo form_dropdown('loa_terms', $LoanTerm, $selected, array('class' => 'form-control'));  ?>
                        <span class="input-group-addon"></span>
                        
                     </div>
                </div> 
          </div>
          <div class="row"> 
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <div class="input-group">
                    <label for="interest_rate">Interest Rate</label><br>
                       <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                            <input type="text" name="interest_rate" class="form-control" 
                               value="<?php echo $Loan->interest_rate; ?>"/>
                            <span class="input-group-addon"></span>
                         </div> 
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <div class="input-group">
                    <label for="approval_amount">Approval Amount<span style="color:red;"> * </span></label><br>
                       <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-money"></i></span>
                            <input type="text" name="approval_amount" class="form-control" 
                               value="<?php echo $Loan->approval_amount; ?>"/>
                            <span class="input-group-addon"></span>
                         </div> 
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <div class="input-group">
                    <label for="approval_term">Approval Term<span style="color:red;"> * </span></label><br>
                       <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        <?php $selected = ($Loan->approval_term)?$Loan->approval_term:'12';
                        echo form_dropdown('approval_term', $LoanTerm, $selected, array('class' => 'form-control'));  ?>
                        <span class="input-group-addon"></span>
                         </div> 
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <label for="down_payment">Down Payment</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="down_payment" class="form-control" 
                           value="<?php echo $Loan->down_payment; ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div>
          </div>
           <div class="row">  
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <div class="input-group">
                    <label for="esign">Sign<span style="color:red;"> * </span></label><br>
                        <div class="input-group">
                    <?php $radclass = array('class' => 'form-control');  
                                $es = ($Loan->esign == "ESIGN")? TRUE :"";
                                $pr = ($Loan->esign == "PRINT")? TRUE :"";
                                    ?>
                            <input type="radio" name="esign" 
                                    value="ESIGN" <?php echo  set_radio('esign', 'ESIGN', $es, $radclass ); ?> /> Esign
                            <input type="radio" name="esign" 
                                   value="PRINT" <?php echo  set_radio('esign', 'PRINT', $pr, $radclass ); ?> /> PRINT
                        </div> 
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <label for="risk_discount">Risk Discount</label><br>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                        <input type="text" name="risk_discount" class="form-control"
                           value="<?php echo $Loan->risk_discount; ?>"/>
                        <span class="input-group-addon"></span>
                     </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <div class="input-group">
                    <label for="bid_percent">Bid Percent</label><br>
                       <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-archive"></i></span>
                            <input type="text" name="bid_percent" class="form-control" 
                               value="<?php echo $Loan->bid_percent; ?>"/>
                            <span class="input-group-addon"></span>
                         </div> 
                    </div>
                </div>
                 
            </div>      
         <?php echo form_fieldset_close(); ?>  
           </div>
        

            <div class="well well-lg">
                <div class="row">    
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                    <?php echo form_submit('submit_loan','Save Loan Information', array('class' => 'pull-left btn btn-primary' ) ); ?>
                    </div>
                </div>
            </div>  
                 

        <?php echo form_close(); ?>

        </div>  <!-- Content -->                      
           </div> <!-- Panel Body -->

       </div> <!-- Panel Primary -->       
    </article>
   </div>
        </div><!-- END MAIN CONTENT -->
</div><!-- END MAIN PANEL -->

<script type="text/javascript">

jQuery(function($){
     $("#loa_type").focus();
     $("#bank_zip").mask("99999");
     $("#bank_routing").mask("999999999");
});
</script>

 <script>
		// validate custom application requirements form on keyup and submit
                $(function() {
		 $("#form_loan").validate({
                     onfocusout: function (element) {
                                $(element).valid();
                            },
			rules: {
				bank_name: {
                                     required: true,
                                    maxlength: 45
                                },
                                bank_branch: {
                                    maxlength: 45
                                },
                                bank_account: {
                                     required: true,
                                    maxlength: 20
                                },
                                bank_routing: {
                                     required: true,
                                       digits: true,
                                       minlength: 9
                                },
                                bank_address: {
                                    maxlength: 65
                                },
                                bank_city: {
                                    maxlength: 45
                                },
                                bank_state: {
                                    maxlength: 45
                                },
                                bank_zip: {
                                     digits: true,
                                       maxlength: 5,
                                       minlength: 5
                                },
                                bank_deposit_routing: {
                                    maxlength: 9
                                },
                                bank_deposit_account: {
                                    maxlength: 20
                                },
                                bank_status: {
                                     required: true,
                                    maxlength: 12
                                }
                                
			},
			messages: {
				bank_name: {
                                        required: "Enter the Bank Name",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                    },
				bank_branch: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                bank_acount: {
                                        required: "Enter the Account Number",
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                bank_routing: {
                                        required: "Enter the Routing Number",
                                        maxlength: jQuery.validator.format("No more than {0} characters"),
                                        minlength: jQuery.validator.format("Must be {0} characters")
                                    },
				bank_address: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                 bank_city: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                bank_state: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                    },
				bank_zip: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                 bank_deposit_routing: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                bank_deposit_account: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                    },
				bank_status: {
                                        maxlength: jQuery.validator.format("No more than {0} characters")
                                },
                                
                                
				highlight: function(element, errorClass, validClass) {
                                    $(element).addClass(errorClass).removeClass(validClass);
                                    $(element.form).find("label[for=" + element.id + "]")
                                      .addClass(errorClass);
                                  },
                                  unhighlight: function(element, errorClass, validClass) {
                                    $(element).removeClass(errorClass).addClass(validClass);
                                    $(element.form).find("label[for=" + element.id + "]")
                                      .removeClass(errorClass);
                                  }
			}
                        });
			

		
	});
        
	</script>
