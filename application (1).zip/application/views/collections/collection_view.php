<?php

/* 
 * admin_main_view
 */

// get the var's that are used in this page
if(isset($cli_rec)): foreach ($cli_rec as $r): 
   $client_name    = $r->client_name; 
   $contact_name  = $r->contact_name;
   $contact_phone = $r->contact_phone; 
endforeach;
endif;
if(isset($records)): foreach ($records as $row): 
    $user_email = $row->user_email; 
    $user_id = $row->user_id; 
    $user_name = $row->user_name; 
    endforeach;
    endif; 
?>
<!-- MAIN PANEL -->
<div id="main" role="main">
        <div id="ribbon">
                <ol class="breadcrumb">
                    <li><a href='.<? base_url(); ?>.'>Home</a></li><li>Collections</li>
                </ol>
        </div>
        <!-- MAIN CONTENT -->
<div id="content">
                <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <h1 class="page-title txt-color-blueDark"><!-- PAGE HEADER -->
                                    <i class="fa fa-lg fa-fw fa-cube"></i> <?php echo $client_name; ?>
                                    <span>> Collections </span></h1>
                        </div>
                </div>

<section id="widget-grid" class="">
 
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-8">
        <div class="jarviswidget">
                    <header>
                            <h2> Record Search </h2>
                            <span class="badge pull-right margin-right-5 margin-top-5"><?php echo $client_name; ?></span>
                    </header>
    <div class="padding-gutter">           
        <div class="list-group">

             <?php echo form_fieldset('Search By:'); ?>   
          <div class="row">    
               <?php 
             //*********************   Start Form   *****************************************
                    echo validation_errors(); 
                    $attributes = array('role' => 'form', 'id' => 'form_search');
                    echo form_open($action_sbi, $attributes); 
           ?>
              <div class="well well-clean"> 
             <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
               
                 <div class="input-group">
                            <?php $radclass = array('class' => 'form-control'); ?>  
                     <ul class="list-group">
                         <li class="list-group-item">
                     <input type="radio" name="dash_search_by"  
                            onchange="HideContent('by_p'), HideContent('by_i'),HideContent('by_n'),HideContent('by_s'), ShowContent('by_a')"
                            value="app_id" id="search_id" checked="checked"  /> Application ID
                         </li>
                         <li class="list-group-item">
                    <input type="radio" name="dash_search_by"  
                            onchange="HideContent('by_p'), HideContent('by_i'),HideContent('by_a'),HideContent('by_s'), ShowContent('by_n')"
                            value="app_name" id="search_name"   /> Name 
                         </li>
                         <li class="list-group-item">
                    <input type="radio" name="dash_search_by"
                            onchange="HideContent('by_a'), HideContent('by_i'),HideContent('by_n'),HideContent('by_s'), ShowContent('by_p')"
                            value="app_phone" id="search_phone" /> Main Phone
                         </li>
                         <li class="list-group-item">
                     <input type="radio" name="dash_search_by" 
                            onchange="HideContent('by_p'), HideContent('by_a'),HideContent('by_n'),HideContent('by_s'), ShowContent('by_i')"
                            value="app_internal_id" id="search_internal"  /> Internal ID
                         </li>
                         <li class="list-group-item">
                     <input type="radio" name="dash_search_by" 
                            onchange="HideContent('by_p'), HideContent('by_i'),HideContent('by_n'),HideContent('by_a'), ShowContent('by_s')"
                            value="app_primary_ssn" id="search_ssn"  /> Primary SSN
                         </li>
                     </ul>
                </div> 
            </div> 
              </div>
         
       <div id="by_a">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="app_id">Application ID</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                <input type="text" class="form-control" 
                       name="app_id" value="<?php echo set_value('app_id'); ?>"/> 
                <span class="input-group-addon"></span>             
                </div>
            </div>
           <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"></div>
      </div>       
      <div id="by_n" style="display:none;">  
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                <label for="app_fname">First Name</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                <input type="text" class="form-control" 
                       name="app_fname" value="<?php echo set_value('app_fname'); ?>"/> 
                <span class="input-group-addon"></span>       
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="app_lname">Last Name (or *like)</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                <input type="text" class="form-control" 
                       name="app_lname" value="<?php echo set_value('app_lname'); ?>"/> 
                <span class="input-group-addon"></span>             
                </div>
            </div>
      </div>  
         
      <div id="by_p" style="display:none;">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="app_phone">Main Phone</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                <input type="tel" class="form-control" 
                       name="app_phone" id="app_phone" value=""/> 
                <span class="input-group-addon"></span>             
                </div>
            </div>
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"></div>
      </div> 
      <div id="by_i" style="display:none;">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="app_internal_id">Internal ID</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                <input type="text" class="form-control" 
                       name="app_internal_id" value="<?php echo set_value('app_internal_id'); ?>"/> 
                <span class="input-group-addon"></span>             
                </div>
            </div>
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"></div>
      </div> 
     <div id="by_s" style="display:none;">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                 <label for="app_primary_ssn">Primary SSN</label><br>
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                <input type="text" class="form-control" 
                       name="app_primary_ssn" id="app_primary_ssn" value="<?php echo set_value('app_primary_ssn'); ?>"/> 
                <span class="input-group-addon"></span>             
                </div>
            </div>
         <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3"></div>
      </div> 
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-2">
                <label for="submit_search_fn"> </label><br> 
            <?php echo form_submit('submit_search_fn','Search', array('class' => 'pull-left btn btn-primary' ) );  ?>
            </div>
              <?php  
                    echo form_close(); 
            //*************************************  End Form    **************************************************************
            ?>
              </div>

         

                            
            
                    </div> <!-- List-Group-->
                </div>
            </div><!-- jarviswidget -->
    </article>
      
 

     
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
        <div class="list-group">

        <div class="jarviswidget" >
                    <header>
                            <h2> Quick Search </h2>
                            <span class="badge pull-right margin-right-5 margin-top-5">Recent</span>
                    </header>

        

        <?php if( $auth_level == 9 ) { ?>
                    <div class="padding-gutter">           
                        <div class="list-group">

                                <a href="<?php echo secure_site_url('clients/index'); ?>">      
                                    <button type="button" class="list-group-item">
                                    <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                    <span class="badge"><?php echo $Client_count; ?></span><span>View Client List</span>
                                    </button>
                                </a>
                                <a href="<?php echo secure_site_url('users/'); ?>">    
                                    <button type="button" class="list-group-item">
                                    <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                    <span class="badge"><?php echo $User_count; ?></span><span>View User List</span>
                                    </button>  
                                </a>
                
                                <a href="<?php echo secure_site_url('applications/completed_appls'); ?>">    
                                    <button type="button" class="list-group-item">
                                        <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i>
                                    <span>View Completed Applications</span>
                                    </button>
                                </a>    
                                <a href="<?php echo secure_site_url('applications/incompleted_appls'); ?>">    
                                    <button type="button" class="list-group-item">
                                        <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i>
                                    <span>View Incomplete Applications</span>
                                    </button>
                                </a>            
                                <a href="<?php echo secure_site_url('users/'); ?>">    
                                    <button type="button" class="list-group-item">
                                    <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                    <span>View Approvals</span>    
                                    </button>
                                </a>  
                                <a href="<?php echo secure_site_url('users/'); ?>">    
                                    <button type="button" class="list-group-item">
                                    <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                    <span>View Denial Applications</span>    
                                    </button>
                                </a>
                               
                        </div>
                    </div>
         <?php 
              }  
            elseif( $auth_level == 8 ) { ?>
                    <div class="padding-gutter">
                        <div class="list-group">
                                <a href="<?php echo secure_site_url('users/'); ?>">    
                                    <button type="button" class="list-group-item">
                                    <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                    <span class="badge"><?php echo $User_count; ?></span><span>View User List</span>
                                    </button>  
                                </a>
                                <a href="<?php echo secure_site_url('applications/completed_appls'); ?>">    
                                    <button type="button" class="list-group-item">
                                        <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i>
                                    <span>View Completed Applications</span>
                                    </button>
                                </a>    
                                <a href="<?php echo secure_site_url('applications/incompleted_appls'); ?>">    
                                    <button type="button" class="list-group-item">
                                        <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i>
                                    <span>View Incomplete Applications</span>
                                    </button>
                                </a>            
                                <a href="<?php echo secure_site_url('users/'); ?>">    
                                    <button type="button" class="list-group-item">
                                    <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                    <span>View Approvals</span>    
                                    </button>
                                </a>  
                                <a href="<?php echo secure_site_url('users/'); ?>">    
                                    <button type="button" class="list-group-item">
                                    <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                    <span>View Denial Applications</span>    
                                    </button>
                                </a>

                        </div>
                    </div>
        <?php 
        
            } 
         elseif( $auth_level <= 7 ) { ?>
                    <div class="padding-gutter">
                        <div class="list-group">
                               <a href="<?php echo secure_site_url('applications/completed_appls'); ?>">    
                                    <button type="button" class="list-group-item">
                                        <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i>
                                    <span>View Completed Applications</span>
                                    </button>
                                </a>    
                                <a href="<?php echo secure_site_url('applications/incompleted_appls'); ?>">    
                                    <button type="button" class="list-group-item">
                                        <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i>
                                    <span>View Incomplete Applications</span>
                                    </button>
                                </a>            
                                <a href="<?php echo secure_site_url('users/'); ?>">    
                                    <button type="button" class="list-group-item">
                                    <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                    <span>View Approvals</span>    
                                    </button>
                                </a>  
                                <a href="<?php echo secure_site_url('users/'); ?>">    
                                    <button type="button" class="list-group-item">
                                    <i class="fa fa-lg fa-fw fa-eye txt-color-blue"></i> 
                                    <span>View Denial Applications</span>    
                                    </button>
                                </a>
                        </div>       
                    </div>
        <?php 
            } 
         else { 
             // put a default list here
         }
            ?>

    </div>
       
        </div>
</article>
   
    
<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <div class="list-group">
                            
        <div class="jarviswidget" >
                    <header>
                            <h2> Record Results </h2>
                            <span class="badge pull-right margin-right-5 margin-top-5"><?php echo $tab; ?></span>
                    </header>
                    <div class="padding-gutter">
                        
                      
                        <div class="pagination pagination-lg">
                            <?php echo $pagination; ?>
                        </div> 
                        <div class="data">
                            <?php echo $table; ?>
                        </div> 
                        <div class="paging">
                            <?php echo $pagination; ?>
                        </div> <br /> 
                        
                            <?php echo secure_anchor(
                                    'applications/create_appl/',
                                    '<i class="fa fa-lg fa-fw fa-user-plus txt-color-blue"></i> New Application',
                                    array('class'=>'add')); ?> 
                   
                    </div>
      
      </div>
    </div>
    </article>  
    <article class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
        <div class="jarviswidget" >
                    <header>
                            <h2> Record Results </h2>
                            <span class="badge pull-right margin-right-5 margin-top-5"><?php echo $client_name; ?></span>
                    </header>
                    <div class="padding-gutter">
                        
                        <div class="well well-lg"> 
                        <?php
                        // Add something here
                        ?>
                    </div>
                        
                       
                    </div>
      
      </div>
    </article> 
                                
                     
                </section>
        </div>
</div>
<!-- END MAIN PANEL -->

<script type="text/javascript">
$(function() {
    $("#search_id").focus();
    $("#app_phone").mask("(999) 999-9999");
    $("#app_primary_ssn").mask("999-99-9999");
    $( "tr:odd" ).css( "background-color", "#bbbbff" );
    $("tr").not(':first').hover(
  function () {
    $(this).css("background","#3074ae");
    $(this).css("color", "#ffffff");
  }, 
  function () {
    $(this).css("background","");
    $( "tr:odd" ).css( "background-color", "#bbbbff" );
    $(this).css("color", "#000000");

  }
);
    
});


 function HideContent(d) {
    document.getElementById(d).style.display = "none";
    }
    function ShowContent(d) {
    document.getElementById(d).style.display = "block";
    }
    function ReverseDisplay(d) {
    if(document.getElementById(d).style.display == "none") { document.getElementById(d).style.display = "block"; }
    else { document.getElementById(d).style.display = "none"; }
    }
</script>
