<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function listData($dbs,$table,$name,$value,$orderBy='ASC', $orderOn='') {
    
	 

	 // $CI =& get_instance();
          $dbCI =& get_instance(); // Had to do this because couldn't access it with $this-> when switched to multi database use.
          $db = $dbCI->load->database($dbs, true);
            $items = array();
	  if($orderBy) {
              
           $order = ($orderOn == '') ? $value : $orderOn; // This allows to be orderBy on something other that $value when 6th parameter is provided
	  //$CI->db->order_by($value,$orderBy);
          $db->order_by($order,$orderBy);
	  }

	//  $query = $CI->db->select("$name,$value")->from($table)->get();
          $query = $db->select("$name,$value")->from($table)->get();

	  if ($query->num_rows() > 0) {

	  foreach($query->result() as $data) {

	  $items[$data->$name] = $data->$value;

	  }

	  $query->free_result();

	  return $items;

	  }

  }

  
  function listLevels($dbs,$table,$name,$value,$level,$orderBy='ASC',$orderOn='' ) {
     

	 // $CI =& get_instance();
          $dbCI =& get_instance(); // Had to do this because couldn't access it with $this-> when switched to multi database use.
          $db = $dbCI->load->database($dbs, true);
            $items = array();
	  if($orderBy) {
              
           $order = ($orderOn == '') ? $value : $orderOn; // This allows to be orderBy on something other that $value when 6th parameter is provided
	  //$CI->db->order_by($value,$orderBy);
          $db->order_by($order,$orderBy);
	  }

	//  $query = $CI->db->select("$name,$value")->from($table)->get();
          if($level == 9) {
          $query = $db->select("$name,$value")->from($table)->get();
          } elseif($level == 8) { 
              $db->where_not_in('level_id', 9);
          $query = $db->select("$name,$value")->from($table)->get();    
          } elseif($level == 6) { 
              $db->where('level_id <=', 6);
          $query = $db->select("$name,$value")->from($table)->get();        
          } elseif($level < 4) { 
              $db->where('level_id <=', 1);
          $query = $db->select("$name,$value")->from($table)->get();    
          }

	  if ($query->num_rows() > 0) {

	  foreach($query->result() as $data) {

	  $items[$data->$name] = $data->$value;

	  }

	  $query->free_result();

	  return $items;

	  }

  }
  
  
  /********************************************************************************/
  
  function listFields($dbs,$table) {
    
	 

	 // $CI =& get_instance();
          $dbCI =& get_instance(); // Had to do this because couldn't access it with $this-> when switched to multi database use.
          $db = $dbCI->load->database($dbs, true);
            
	 
            $fields = $db->field_data($table);
            
           $items = array(); 
	  foreach($fields as $key => $data) {

	  $items[$data->name] = $data->name;


	  }


	  return $items;

	  

  }