<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Application Model
 * Steve Thomas
 * 12/23/2015
 *    
 */

class Applications_model extends MY_Model {

	private $client_key = 'client_id';
        private $primary_key = 'app_id';
        private $table_name = 'applicant';


        public function __construct()
	{
		parent::__construct();
                $this->load->helper('url');
                $this->dbMain = $this->load->database('main', true);
	}
        function get_by_client_id($client) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($this->client_key, $client);
            return $this->db2use->get('client_config');
        }
       
        //find applications that have app, ref, and emp all filled out.
        /*
         * Both get_paged_completed_list and get_paged_incompleted_list are obsolete
         * Now just check the applications status.
         */
        function get_paged_completed_list($limit=10, $offset=0, $order_column='', $order_type='desc') {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            if(empty($order_column) || empty($order_type)) {
                $this->db2use->order_by('app_id', 'desc');
            }else {
                $this->db2use->order_by($order_column, $order_type);
            }
            
                $this->db2use->where('client_id', $this->auth_client_id);
                $this->db2use->join('references', 'app_id');
               $this->db2use->join('employers', 'app_id');
                return $this->db2use->get('applicant', $limit, $offset);
           
        }
        
        //Find the apps that are missing either the emp or ref
        function get_paged_incompleted_list($limit=10, $offset=0, $order_column='', $order_type='desc') {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            if(empty($order_column) || empty($order_type)) {
                $this->db2use->order_by('app_id', 'desc');
            }else {
                $this->db2use->order_by($order_column, $order_type);
            }
               $this->db2use->where('client_id', $this->auth_client_id);
             //  $this->db2use->where_in('app_id', $this->unmatch_appl_ref());
             //  $this->db2use->where_in('app_id', $this->unmatch_appl_emp());
               return $this->db2use->get($this->table_name, $limit, $offset);
        }
        function unmatch_appl_ref(){
            $this->db2use = $this->load->database($this->auth_client_id, true);
            // this compares applicant to references and lists all app_id from applicant that is NOT in references
            $query = $this->db2use->query("select `app_id` FROM ( SELECT `app_id` FROM `applicant` 
                                            UNION ALL
                                            SELECT `app_id` FROM `references`
                                            ) tbl
                                            GROUP BY `app_id` HAVING COUNT(*) = 1 
                                            ORDER BY `app_id`");

            foreach ($query->result_array() as $row)
            {
                $res[] = $row['app_id'];
            }
            return $res;
        }
        
        function unmatch_appl_emp(){
            $this->db2use = $this->load->database($this->auth_client_id, true);
            // this compares applicant to employers and lists all app_id from applicant that is NOT in employers
            $query = $this->db2use->query("select `app_id` FROM ( SELECT `app_id` FROM `applicant` 
                                            UNION ALL
                                            SELECT `app_id` FROM `employers`
                                            ) tbl
                                            GROUP BY `app_id` HAVING COUNT(*) = 1 
                                            ORDER BY `app_id`");

            foreach ($query->result_array() as $row)
            {
                $res[] = $row['app_id'];
            }
            return $res;
        }

        /**********************************************************************************
         * list of applied status
         */
        
        //create the default order_by and sort or set as requested for incomplete appls
        function get_applied_status_list($limit=10, $offset=0, $order_column='', $order_type='asc') {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            if(empty($order_column) || empty($order_type)) {
                $this->db2use->order_by('app_id', 'asc');
            }else {
                $this->db2use->order_by($order_column, $order_type);
            }
           
               // $this->db2use->where('client_id', $this->auth_client_id);
                $this->db2use->where('app_status', 'Applied');
                return $this->db2use->get($this->table_name, $limit, $offset);
 
           
        }
        

        function count_all() {
            $this->db2use = $this->load->database($this->auth_client_id, true);
        return $this->db2use->count_all($this->table_name);
        } 
        function count_users() {
            // This needs to call the main db to get a count of users that are in this client. This shows in the badge on dashboard View Users List tab
            $this->dbMain = $this->load->database('main', true);
            $this->dbMain->where('client_id', $this->auth_client_id);
            return $this->dbMain->count_all_results('users');

        } 
        function get_by_id($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($this->primary_key, $id);
            return $this->db2use->get($this->table_name);
        }
        function save($the_user) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->insert($this->table_name, $the_user);
            return $this->db2use->insert_id();
        }
        function update($id, $the_applicant) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($this->primary_key, $id);
            $this->db2use->update('applicant', $the_applicant);
        }
        function ref_update($id, $the_applicant) {
           $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($this->primary_key, $id);
            $this->db2use->update('references', $the_applicant);
        }
        function emp_update($id, $the_applicant) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($this->primary_key, $id);
            $this->db2use->update('employers', $the_applicant);
        }
        function co_update($id, $the_applicant) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($this->primary_key, $id);
            $this->db2use->update('coapplicant', $the_applicant);
        }
        function delete($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($this->primary_key, $id);
            $this->db2use->delete($this->table_name);
        }

          public function view_record() {
              $this->db2use = $this->load->database($this->auth_client_id, true);
              $this->db2use->where('app_id',  $this->auth_user_id );
              $query = $this->db2use->get('applicant'); // table to pull data
        return $query->result();
     
        } 
        
       
      
       
        
        // get coapplicant information
        function get_by_coid($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where('coapp_id', $id);
            return $this->db2use->get('coapplicant');
        }
        // get references information
        function get_by_refid($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where('ref_id', $id);
            return $this->db2use->get('references');
        }
        // get employment information
        function get_by_empid($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where('emp_id', $id);
            return $this->db2use->get('employers');
        }
         // get applicant information
        function get_by_applicant($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where('app_id', $id);
            return $this->db2use->get('applicant');
        }
        // get references information
        function get_ref_by_app_id($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where('app_id', $id);
            return $this->db2use->get('references');
        }
        // get Employers information
        function get_emp_by_app_id($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where('app_id', $id);
            return $this->db2use->get('employers');
        }
        // get Co Applicants information
        function get_co_by_app_id($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where('app_id', $id);
            return $this->db2use->get('coapplicant');
        }
        function update_deny($id, $the_data) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->set('app_status', $the_data);
            $this->db2use->where($this->primary_key, $id);
            $this->db2use->update($this->table_name);
        }
        function count_deny() {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where('loa_status', 'Denied');
        return $this->db2use->count_all_results('loans');
        }
 /*****************************************************************************************
         *    SEARCHES
         */
   
        function search_by_id($limit=10, $offset=0, $field, $value, $order_column='', $order_type='desc') {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($field, $value);
            $this->db2use->join('loans', 'loans.app_id = applicant.app_id', 'inner');
            $this->db2use->order_by('applicant.app_id', 'desc');
            return $this->db2use->get($this->table_name, $limit, $offset);
        }
        //*******************************************************************
        public function get_paged_search_list($limit=10, $offset=0, $field, $value, $order_column='', $order_type='desc') {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($field, $value);
                $this->db2use->join('loans', 'loans.app_id = applicant.app_id');
                $this->db2use->order_by('applicant.app_id', 'desc');
                return $this->db2use->get($this->table_name, $limit, $offset);
        }
        //******************************************************************
        function count_search($table, $field, $value) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($field, $value);
        return $this->db2use->count_all_results($table);
        }
        //******************************************************************
        public function get_paged_recentapp_list($limit=20, $offset=0, $order_column='', $order_type='desc') {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            
            if(empty($order_column) || empty($order_type)) {
              //  $this->db2use->order_by('applicant.app_id', 'desc');
                 $this->db2use->order_by('applicant.app_created', 'desc');
            }else {
             //   $this->db2use->order_by('applicant.app_id', 'desc');
                 $this->db2use->order_by('applicant.app_created', 'desc');
            }
                $this->db2use->join('loans', 'loans.app_id = applicant.app_id', 'left');
              //  $this->db2use->where('applicant.app_status', 'Applied');
                return $this->db2use->get($this->table_name, $limit, $offset);  
        }
        //****************************************************************
        public function get_paged_all_list($limit=20, $offset=0, $order_column='', $order_type='desc') {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            
            if(empty($order_column) || empty($order_type)) {
                $this->db2use->order_by('app_id', 'desc');
            }else {
                $this->db2use->order_by('applicant.app_id', 'desc');
            }
                $this->db2use->join('loans', 'loans.app_id = applicant.app_id', 'left inner');
                return $this->db2use->get($this->table_name, $limit, $offset);
        }
        //********************************************************************
         public function get_paged_search_first_last($limit=10, $offset=0, $fname, $lname, $order_column='', $order_type='asc') {
              $this->db2use = $this->load->database($this->auth_client_id, true);
              $this->db2use->where('app_fname',  $fname );
              $this->db2use->where('app_lname',  $lname );
              $this->db2use->order_by('applicant.app_id', 'asc');
              $this->db2use->join('loans', 'loans.app_id = applicant.app_id');
                return $this->db2use->get($this->table_name, $limit, $offset);
             
        }
        //********************************************************************
        public function get_paged_search_like_last($limit=10, $offset=0,$lname, $order_column='', $order_type='desc') {
              $this->db2use = $this->load->database($this->auth_client_id, true);
              $this->db2use->like('app_lname',  $lname );
              $this->db2use->order_by('applicant.app_id', 'desc');
              $this->db2use->join('loans', 'loans.app_id = applicant.app_id');
                return $this->db2use->get($this->table_name, $limit, $offset);
            
        }
        
        public function get_paged_settlement($limit=20, $offset=0, $order_column='', $order_type='desc') {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            
                $this->db2use->join('credit_card_holder', 'card_tran.FCC_ID = credit_card_holder.cc_id');
                $this->db2use->order_by($order_column, $order_type);
                return $this->db2use->get('card_tran', $limit, $offset);
        }
        //******************************************************************
         public function get_pdf_settlement() {
             // This will get the settlement report for pdf in views/pdf/pdf_settlement.php
             
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->join('credit_card_holder', 'card_tran.FCC_ID = credit_card_holder.cc_id');
            $this->db2use->order_by('DATE', 'desc');
                return $this->db2use->get('card_tran');
        }
        //******************************************************************
        function count_settlements() {
            $this->db2use = $this->load->database($this->auth_client_id, true);
        return $this->db2use->count_all('card_tran');
        } 
        //****************************************************************************
        public function get_paged_chargeback($limit=10, $offset=0, $order_column='', $order_type='desc') {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            
               // $this->db2use->join('', 'loans.app_id = applicant.app_id');
              //  $this->db2use->order_by('applicant.app_id', 'desc');
                $this->db2use->where('STATUS',  'Denied' );
                return $this->db2use->get('card_tran', $limit, $offset);
        }
        //******************************************************************
        
}//end model

