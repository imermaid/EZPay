<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Terminal_model extends MY_Model
{
    private $primary_key = "API_KEY";
    private $table_name = "pagasys_api";
    
    public function __construct()
    {
        parent::__construct();
        $this->load->helper("url");
    }
    
    public function getApiKey()
    {
        $this->db2use = $this->load->database($this->auth_client_id, true);
        $query = $this->db2use->query("SELECT API_KEY FROM {$this->table_name}");
        return $query->result()[0]->API_KEY;
    }
    
    public function getApiPass()
    {
        $this->db2use = $this->load->database($this->auth_client_id, true);
        $query = $this->db2use->query("SELECT API_PASS FROM {$this->table_name}");
        return $query->result()[0]->API_PASS;
    }
    
    public function getProcessingModel()
    {
        $this->db2use = $this->load->database($this->auth_client_id, true);
        
        $query = $this->db2use->query("SELECT * FROM client_model");
        
        //check the client model for values if they don't exist use the default
        $cli_res = $query->result()[0];
        $model = $cli_res->MODEL;
        
        $query = $this->db2use->query("SELECT USE_CONV_FEE, USE_PERCENTAGE, USE_MIX FROM processing_model WHERE MODEL_ID='$model'");
        $mod_res = $query->result()[0];
        $use_pct = $mod_res->USE_PERCENTAGE == true;
        $use_conv = $mod_res->USE_CONV_FEE == true;
        $use_mixed = $mod_res->USE_MIX == true;
        
        $model = array();
        if($use_pct)
        {
            $model["type"] = "PCT";
            $model["percent"] = $this->db2use->query("SELECT PERCENTAGE FROM client_model")->result()[0]->PERCENTAGE;
            
            if($model["percent"] == 0)
            {
                $model["percent"] = ($this->db2use->query("SELECT DEFAULT_PERCENTAGE FROM processing_model")->result()[0]->DEFAULT_PERCENTAGE) / 100.0;
            }
            else
            {
                $model["percent"] = $model["percent"] / 100.0;
            }
        }
        else if($use_conv)
        {
            $model["type"] = "CONV";
            $model["conv_fee"] = $this->db2use->query("SELECT CONV_FEE FROM client_model")->result()[0]->PERCENTAGE;
            
            if($model["conv_fee"] == 0)
            {
                $model["conv_fee"] = ($this->db2use->query("SELECT DEFAULT_CONV_FEE FROM processing_model")->result()[0]->DEFAULT_CONV_FEE) / 100.0;
            }
            else
            {
                $model["conv_fee"] = $model["conv_fee"] / 100.0;
            }
        }
        else if($use_mixed)
        {
            $model["type"] = "MIX";
            $model["percent"] = $this->db2use->query("SELECT PERCENTAGE FROM client_model")->result()[0]->PERCENTAGE;
            
            if($model["percent"] == 0)
            {
                $model["percent"] = ($this->db2use->query("SELECT DEFAULT_PERCENTAGE FROM processing_model")->result()[0]->DEFAULT_PERCENTAGE) / 100.0;
            }
            else
            {
                $model["percent"] = $model["percent"] / 100.0;
            }
            
            $model["conv_fee"] = $this->db2use->query("SELECT CONV_FEE FROM client_model")->result()[0]->PERCENTAGE;
            
            if($model["conv_fee"] == 0)
            {
                $model["conv_fee"] = ($this->db2use->query("SELECT DEFAULT_CONV_FEE FROM processing_model")->result()[0]->DEFAULT_CONV_FEE) / 100.0;
            }
            else
            {
                $model["conv_fee"] = $model["conv_fee"] / 100.0;
            }
        }
        
        return $model;
    }
    
    public function storeTran($data)
    {
        $this->db2use->insert("card_tran", $data); 
    }
    
    public function storeCardHolder($data)
    {
        $this->db2use->insert("credit_card_holder", $data);
    }
}