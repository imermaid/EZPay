 <?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Products Model
 * Steve Thomas
 * 2/14/2016
 *    
 */

class Products_model extends MY_Model {


        private $primary_key = 'prod_id';
        private $table_name = 'products';


        public function __construct()
	{
		parent::__construct();
                $this->load->helper('url');
	}
        
        function count_all() {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            return $this->db2use->count_all($this->table_name);
        } 
        function get_by_id($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($this->primary_key, $id);
            return $this->db2use->get($this->table_name);
        }
         function default_processing($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where('client_id', $id);
            return $this->db2use->get($this->table_name);
        }
        function save($the_user) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->insert($this->table_name, $the_user);
            return $this->db2use->insert_id();
        }
        function update($id, $the_product) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($this->primary_key, $id);
            $this->db2use->update('products', $the_product);
        }
        function delete($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($this->primary_key, $id);
            $this->db2use->delete($this->table_name);
        }

          public function view_record($prod_id) {
              $this->db2use = $this->load->database($this->auth_client_id, true);
              $this->db2use->where('MODEL_ID',  $prod_id );
              $query = $this->db2use->get($this->table_name); // table to pull data
            return $query->result();
     
        } 
       
        //create the default order_by and sort or set as requested
        function get_paged_product_list($limit=10, $offset=0, $order_column='prod_id', $order_type='asc') {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            if(empty($order_column) || empty($order_type)) {
                $this->db2use->order_by('prod_id', 'asc');
            }else {
                $this->db2use->order_by($order_column, $order_type);
            }
            return $this->db2use->get($this->table_name, $limit, $offset);
           
        }    
}
