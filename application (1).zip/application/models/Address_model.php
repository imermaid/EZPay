<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Address Model

 */

class Address_model extends MY_Model {

	private $primary_key = 'add_id';
        private $table_name = 'address';
        
	public function __construct()
	{
		parent::__construct();
                $this->load->helper('url');
	}

        //create the default order_by and sort or set as requested
        function get_paged_list($limit=10, $offset=0, $order_column='', $order_type='asc') {
            if(empty($order_column) || empty($order_type)) {
                $this->db->order_by($this->primary_key, 'asc');
            }else {
                $this->db->order_by($order_column, $order_type);
                return $this->db->get($this->table_name, $limit, $offset);
            } 
        }

        function count_all() {
        return $this->db->count_all($this->table_name);
        } 
        
        function get_by_id($id, $id_for = NULL) {
            if ($id_for === 'app_id') {
                $this->db->where('app_id', $id);
                $this->db->where('add_status', 'Active');
            }
            elseif ($id_for === 'client_id') {
                $this->db->where('client_id', $id);
                $this->db->where('add_status', 'Active');
            }
            elseif ($id_for === 'ref_id') {
                $this->db->where('ref_id', $id);
                $this->db->where('add_status', 'Active');
            }
            elseif ($id_for === 'emp_id') {
                $this->db->where('emp_id', $id);
                $this->db->where('add_status', 'Active');
            }
            elseif ($id_for === 'coapp_id') {
                $this->db->where('coapp_id', $id);
                $this->db->where('add_status', 'Active');
            }
            elseif ($id_for === 'len_id') {
                $this->db->where('len_id', $id);
                $this->db->where('add_status', 'Active');
            }
            
           
            return $this->db->get($this->table_name);
        }
        
        function save($the_address) {
            $this->db->insert($this->table_name, $the_address); // the_address is an array of the address data
            return $this->db->insert_id();
        }
        function update($add_id, $the_address) {
            $this->db->where($this->primary_key, $add_id); // add_id
            $this->db->update($this->table_name, $the_address); // the_address is an array of the address data
        }
        function delete($add_id) {
            $this->db->where($this->primary_key, $add_id);
            $this->db->delete($this->table_name);
        }
        function update_by_appid($app_id, $the_address) {
            $this->db->where('app_id', $app_id); // add_id
            $this->db->update($this->table_name, $the_address); // the_address is an array of the address data
        }
        function get_states() {
             $query = $this->db->get('states'); 
             return $query;
                
        }

     
    
    public function add_address() {
        $today = date('Y-m-d');
        
        $data = array(
                  'add_type' => $this->input->post('add_type'),
                'add_street' => $this->input->post('add_street'),
                  'add_unit' => $this->input->post('add_unit'),
                  'add_city' => $this->input->post('add_city'),
                 'add_state' => $this->input->post('add_state'),
               'add_zipcode' => $this->input->post('add_zipcode'),
            'add_possession' => $this->input->post('add_possession'),
               'add_payment' => $this->input->post('add_payment'),
                 'add_since' => $this->input->post('add_since'),
                   'add_end' => $this->input->post('add_end'),
             'add_isMailing' => $this->input->post('add_isMailing'),
                    'app_id' => $this->input->post('app_id'),
                    'ref_id' => $this->input->post('ref_id'),
                    'emp_id' => $this->input->post('emp_id'),
                 'client_id' => $this->input->post('client_id'),
                  'coapp_id' => $this->input->post('coapp_id'),
                    'len_id' => $this->input->post('len_id'),
                   'created' => $today,
                    'status' => '1'
            );
        return $this->db->insert('address', $data);
    }
        
}