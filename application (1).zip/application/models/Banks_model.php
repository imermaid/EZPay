<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Banks Model
 * Steve Thomas
 * 2/17/2016
 *    
 */

class Banks_model extends MY_Model {


        private $primary_key = 'bank_id';
        private $table_name = 'banks';


        public function __construct()
	{
		parent::__construct();
                $this->load->helper('url');
	}
        
        function count_all() {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            return $this->db2use->count_all($this->table_name);
        } 
        function get_by_id($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($this->primary_key, $id);
            return $this->db2use->get($this->table_name);
        }
         function get_by_app_id($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where('app_id', $id);
            return $this->db2use->get($this->table_name);
        }
        function save($the_user) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->insert($this->table_name, $the_user);
            return $this->db2use->insert_id();
        }
        function update($id, $the_data) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($this->primary_key, $id);
            $this->db2use->update($this->table_name, $the_data);
        }
        function delete($id) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($this->primary_key, $id);
            $this->db2use->delete($this->table_name);
        }

          public function view_record() {
              $this->db2use = $this->load->database($this->auth_client_id, true);
              $this->db2use->where($this->primary_key,  $this->auth_user_id );
              $query = $this->db2use->get($this->table_name); // table to pull data
            return $query->result();
     
        } 
       
        //create the default order_by and sort or set as requested
        function get_paged_bank_list($limit=10, $offset=0, $order_column='', $order_type='asc') {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            if(empty($order_column) || empty($order_type)) {
                $this->db2use->order_by($this->primary_key, 'asc');
            }else {
                $this->db2use->order_by($order_column, $order_type);
            }
            return $this->db2use->get($this->table_name, $limit, $offset);
           
        }    
}
