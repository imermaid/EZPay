<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Client
 *
 * @author Billy
 */

class Client extends MY_Model
{
    private $passdb;
    private $db2use;
    private $valid;
    
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->valid = false;
        $this->passdb = $this->auth_client_id; // This passes the client id to the dropdown helper to call the dynamic dropdowns from the correct databases
        $this->db2use = $this->load->database($this->auth_client_id, true);
    }
    
    public function validClient($username, $password)
    {
        $query = $this->db2use->query("SELECT API_KEY, API_PASS FROM pagasys_api");
        $key = $query->result()[0]->API_KEY;
        $pass = $query->result()[1]->API_PASS;
        
        if($username == $key && $pass == $password)
            $this->valid = true;
        
        return $this->valid;
    }
}
