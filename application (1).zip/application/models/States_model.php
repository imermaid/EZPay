<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Address Model

 */

class States_model extends MY_Model {
     //   private $useDB = '30041';  // Main database for login
     //   protected $db; // this data connection is for the 30041 main database
	public function __construct()
	{
		parent::__construct();
                $this->load->helper('url');
        //        $this->db = $this->load->database($this->useDB, true); // load the database
	}
        
        public function get_states() {
        $query = $this->db->get('states'); 
        return $query;
        }
        
}
