<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *  Clients_model
 *
 * Community Auth is an open source authentication application for CodeIgniter 3
 * @package     Community Auth
 * @author      Robert B Gottier
 * @copyright   Copyright (c) 2011 - 2015, Robert B Gottier. (http://brianswebdesign.com/)
 * @license     BSD - http://www.opensource.org/licenses/BSD-3-Clause
 * @link        http://community-auth.com
 * Edited by Steve Thomas
 * The $db is set for main, the default db that holds client information
 * method list:
 * get_paged_list - count_all - get_by_id($id) - save($the_client_data) - update($id, $client_data) - delete($id) - view_record() - add_client()
 */

class Clients_model extends MY_Model {

        
	public function __construct()
	{
		parent::__construct();
                $this->load->helper('url');
	}

        //create the default order_by and sort or set as requested
        function get_paged_list($limit=10, $offset=0, $order_column='', $order_type='asc') {
            $db = $this->load->database('main', true);
            if(empty($order_column) || empty($order_type)) {
                $db->order_by('client_id', 'asc');
            }else {
                $db->order_by($order_column, $order_type);
                return $db->get('client', $limit, $offset);
            } 
        }

        function count_all() {
            $db = $this->load->database('main', true);
        return $db->count_all('client');
        } 
        function get_by_id($id) {
            $db = $this->load->database('main', true);
            $db->where('client_id', $id);
            return $this->db->get('client');
        }
        function save($the_client_data) {
            $db = $this->load->database('main', true);
            $db->insert('client', $the_client_data);
            return $db->insert_id();
        }
        function update($id, $the_client_data) {
            $db = $this->load->database('main', true);
            $db->where('client_id', $id);
            $db->update('client', $the_client_data);
        }
        function delete($id) {
            $db = $this->load->database('main', true);
            $db->where('client_id', $id);
            $db->delete('client');
        }

        
        
        
        public function view_record() {
            // $client_db = $this->load->database('main', true);
            $db = $this->load->database('main', true);
        $db->where('client_id',  $this->auth_client_id );
        $query = $db->get('client'); // table to pull data
        return $query->result();
     
    } 
    
    public function get_config() {
            $db = $this->load->database('main', true);
        $db->where('client_id',  $this->auth_client_id );
        $query = $db->get('client_config'); // table to pull data
        return $query->result();
     
    } 
    
    public function add_client() {
        
        $data = array(
               'client_name' => $this->input->post('client_name'),
              'contact_name' => $this->input->post('contact_name'),
             'contact_phone' => $this->input->post('contact_phone'),
                   'created' => $this->input->post('created'),
                    'status' => '1',
             'client_street' => $this->input->post('client_street'),
               'client_unit' => $this->input->post('client_unit'),
               'client_city' => $this->input->post('client_city'),
              'client_state' => $this->input->post('client_state'),
            'client_zipcode' => $this->input->post('client_zipcode'),
            );
        return $this->db->insert('client', $data);
    }
        
}