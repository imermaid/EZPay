<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* 
 * Description: Users model class
 * Steve Thomas
 * 12/20/2015
 * $this->dbMain is set for main for Users table for Global access
 * Method List:
 * get_paged_list() - count_all() - get_by_id($id) - save($the_user) - update($id, $arrdata) - delete($id) - view_record() - check_username($str)
 * check_for_match($id,$itmd,$str) - get_client_list(.....) - check_login_status(...) -  
 */
class Reports_model extends MY_Model {
    
       private $primary_key = 'reports_id';
        private $table_name = 'reports';
        public $dbMain;
        private $db2use;
                
    function __construct(){
        parent::__construct();
          $this->load->helper('url');
          $this->dbMain = $this->load->database('main', true);
          $this->db2use = $this->load->database($this->auth_client_id, true);
    }
    
    
       //create the default order_by and sort or set as requested
    public function get_paged_list($limit=10, $offset=0, $order_column='', $order_type='asc') {
            $this->dbMain->where('client_id', $this->auth_client_id );
            if(empty($order_column) || empty($order_type)) {
                $this->dbMain->order_by($this->primary_key, 'asc');
            }else {
                $this->dbMain->order_by($order_column, $order_type);
                return $this->dbMain->get($this->table_name, $limit, $offset);
            } 
        }

    public function count_all() {
        return $this->dbMain->count_all($this->table_name);
        } 
    public function count_all_by_client() {
        $this->dbMain->where('client_id', $this->auth_client_id);
        return $this->dbMain->count_all_results($this->table_name);  // count_all_results accepts a where()
        }
    public function get_by_id($id) {
            $this->dbMain->where($this->primary_key, $id);
            return $this->dbMain->get($this->table_name);
        }
    public function save($the_user) {
            $this->dbMain->insert($this->table_name, $the_user);
            return $this->dbMain->insert_id();
        }
    public function update($id, $the_user) {
            $this->dbMain->where($this->primary_key, $id);
            $this->dbMain->update($this->table_name, $the_user);
        }
    public function delete($id) {
            $this->dbMain->where($this->primary_key, $id);
            $this->dbMain->delete($this->table_name);
        }

        public function view_record($prod_id) {
              $this->db2use = $this->load->database($this->auth_client_id, true);
              $this->db2use->where('prod_id',  $prod_id );
              $query = $this->db2use->get($this->table_name); // table to pull data
            return $query->result();
     
        }
        
        //****************  This is the Transaction report by dates  *********************
        public function get_paged_start_end($limit=20, $offset=0, $table, $start, $end, $order_column, $order_type) {
            $this->db2use = $this->load->database($this->auth_client_id, true);

                $this->db2use->where('card_tran.DATE >=', $start);
                $this->db2use->where('card_tran.DATE <=', $end);
                $this->db2use->join('credit_card_holder', 'card_tran.FCC_ID = credit_card_holder.cc_id');
                $this->db2use->order_by($order_column, $order_type);
                
                return $this->db2use->get($table, $limit, $offset);
        }
        //******************  This is the PDF Creator for the above Transaction Report  *************
         public function get_pdf_start_end($start, $end) {
             // This will get the settlement report for pdf in views/pdf/pdf_settlement.php
             
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where('card_tran.DATE >=', $start);
            $this->db2use->where('card_tran.DATE <=', $end);
            $this->db2use->join('credit_card_holder', 'card_tran.FCC_ID = credit_card_holder.cc_id');
            $this->db2use->order_by('card_tran.DATE', 'desc');
                return $this->db2use->get('card_tran');
        }
        //****************** count start end for the search by dates ************************** 
        function count_start_end($start, $end) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where('DATE >=', $start);
            $this->db2use->where('DATE <=', $end);
        return $this->db2use->count_all_results('card_tran');
        } 

        
        //********************  generic search by some ID. Pass table with one field and one value  *************************************
        
        function get_pdf_by_id($tbl, $fld, $val) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($fld, $val);
            $this->db2use->join('credit_card_holder', 'card_tran.FCC_ID = credit_card_holder.cc_id');
            $this->db2use->order_by('FCC_ID', 'desc');
            return $this->db2use->get($tbl);
        }
        // *********************
        
        function search_by_id($limit=10, $offset=0, $table, $field, $value, $order_column='', $order_type='', $extra='') {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->where($field, $value);
            $this->db2use->join('credit_card_holder', 'card_tran.FCC_ID = credit_card_holder.cc_id');
            $this->db2use->order_by($order_column, $order_type);
            if(is_int($extra)){
            $this->db2use->limit($extra);
            }
            return $this->db2use->get($table, $limit, $offset);
        }
        
        //******************** generic count to search. Pass table and one field/value **********************
        function count_search($table, $field, $value, $extra='') {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            if($extra = 'name') {
              $this->db2use->like($field, $value);  
            } else {
            $this->db2use->where($field, $value);
            }
            if(is_int($extra)){
                $this->db2use->limit($extra);
            }
        return $this->db2use->count_all_results($table);
        }
        
         //********************************************************************
         public function get_paged_search_card_name($limit=10, $offset=0, $name, $order_column, $order_type) {
              $this->db2use = $this->load->database($this->auth_client_id, true);
              $this->db2use->like('name_on_card', $name );
              //$this->db2use->where('name_on_card',  $name );
              $this->db2use->order_by($order_column, $order_type);
              $this->db2use->join('card_tran', 'credit_card_holder.cc_id = card_tran.FCC_ID');
              $this->db2use->order_by('credit_card_holder.cc_id', 'asc');
                return $this->db2use->get('credit_card_holder', $limit, $offset);
             
        }
        //*******************************************************************
        function get_pdf_by_name($tbln, $fldn, $valn) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            $this->db2use->like($fldn, $valn );
           // $this->db2use->where($fld, $val);
            $this->db2use->join('card_tran', 'credit_card_holder.cc_id = card_tran.FCC_ID');
            $this->db2use->order_by('cc_id', 'desc');
            return $this->db2use->get($tbln);
        }
        // *********************
        
        public function transdays($limit=10, $offset=0, $table, $field, $value) {
              $this->db2use = $this->load->database($this->auth_client_id, true);
              // Last 7 days trans query
              if($value == 'week'){
                $td  = date("Y-m-d", mktime(0, 0, 0, date("m")  , date("d")-7, date("Y")));
              $this->db2use->where($field.'>=',  $td );  
              }
              // Last 30 days trans query
              if($value == 30){ 
                $td  = date("Y-m-d", mktime(0, 0, 0, date("m")  , date("d")-30, date("Y"))); 
                $this->db2use->where($field.'>=', $td);
            } 
            // This months trans query
             if($value == date('m')){ 
                $this->db2use->where('month('.$field.')', $value);
            }  
            // Last months query
            if($value == date('m')-1){  
                $this->db2use->where('month('.$field.')', $value);
            } 
            
              $this->db2use->join('credit_card_holder', 'card_tran.FCC_ID = credit_card_holder.cc_id');
              $this->db2use->order_by('credit_card_holder.cc_id', 'asc');
                return $this->db2use->get($table, $limit, $offset);
             
        }
         //******************** count to search days. Pass table and one field/value **********************
        function count_search_days($table, $field, $value) {
            $this->db2use = $this->load->database($this->auth_client_id, true);
            //Last 7 days count
            if($value == 'week'){ 
                $td  = date("Y-m-d", mktime(0, 0, 0, date("m")  , date("d")-7, date("Y"))); 
                $this->db2use->where($field.'>=', $td);
            }
            //Last 30 days count
            if($value == 30){ 
                $td  = date("Y-m-d", mktime(0, 0, 0, date("m")  , date("d")-30, date("Y"))); 
                $this->db2use->where($field.'>=', $td);
            } 
            // this months count
            if($value == date('m')){ 
               // $td  = date("Y-m-d", mktime(0, 0, 0, date("m")  , date("d")-30, date("Y"))); 
                $this->db2use->where('month('.$field.')', $value);
            } 
            //Last months count
            if($value == date('m')-1){  
                $this->db2use->where('month('.$field.')', $value);
            } 
            
        return $this->db2use->count_all_results($table);
        }
        
        function search_type_limit($limit, $offset, $table, $field, $value, $order_column='', $order_type='') {
            $this->db2use = $this->load->database($this->auth_client_id, true);

            $this->db2use->where($field, $value);
            $this->db2use->join('credit_card_holder', 'card_tran.FCC_ID = credit_card_holder.cc_id');
            $this->db2use->order_by($order_column, $order_type);
            $this->db2use->limit(30);
            
            return $this->db2use->get($table, $limit, $offset);
        
            
        }
        function count_by_day($table, $field, $value) {
            $this->db2use->where($field, $value);
           return $this->db2use->count_all_results($table);
            
        } 
        
    
        
        
        
        
    }