<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* 
 * Description: Users model class
 * Steve Thomas
 * 12/20/2015
 * $this->dbMain is set for main for Users table for Global access
 * Method List:
 * get_paged_list() - count_all() - get_by_id($id) - save($the_user) - update($id, $arrdata) - delete($id) - view_record() - check_username($str)
 * check_for_match($id,$itmd,$str) - get_client_list(.....) - check_login_status(...) -  
 */
class Users_model extends MY_Model {
    
       private $primary_key = 'user_id';
        private $table_name = 'users';
        public $dbMain;
                
    function __construct(){
        parent::__construct();
          $this->load->helper('url');
          $this->dbMain = $this->load->database('main', true);
    }
    
    
       //create the default order_by and sort or set as requested
    public function get_paged_list($limit=10, $offset=0, $order_column='', $order_type='asc') {
            $this->dbMain->where('client_id', $this->auth_client_id );
            if(empty($order_column) || empty($order_type)) {
                $this->dbMain->order_by($this->primary_key, 'asc');
            }else {
                $this->dbMain->order_by($order_column, $order_type);
                return $this->dbMain->get($this->table_name, $limit, $offset);
            } 
        }

    public function count_all() {
        return $this->dbMain->count_all($this->table_name);
        } 
    public function count_all_by_client() {
        $this->dbMain->where('client_id', $this->auth_client_id);
        return $this->dbMain->count_all_results($this->table_name);  // count_all_results accepts a where()
        }
    public function get_by_id($id) {
            $this->dbMain->where($this->primary_key, $id);
            return $this->dbMain->get($this->table_name);
        }
    public function save($the_user) {
            $this->dbMain->insert($this->table_name, $the_user);
            return $this->dbMain->insert_id();
        }
    public function update($id, $the_user) {
            $this->dbMain->where($this->primary_key, $id);
            $this->dbMain->update($this->table_name, $the_user);
        }
    public function delete($id) {
            $this->dbMain->where($this->primary_key, $id);
            $this->dbMain->delete($this->table_name);
        }

    public function view_record() {
              $this->dbMain->where('user_id',  $this->auth_user_id );
              $query = $this->dbMain->get('users'); // table to pull data
           return $query->result();
     
        } 
    public function check_username($str) {
            $this->dbMain->where('user_name', $str);
            return $this->dbMain->get($this->table_name);
    
        }
        // check_for_match is used to check the username and email to see if the client is changing it to a new one or 
        // keeping it the same. If same, no validation is needed. If changing, must validate that is's unique.
        // ex. check $id = user_id, $item = 'user_name', $str = 'funkymonkey'
    public function check_for_match($id,$item,$str) {
            $this->dbMain->where($this->primary_key, $id);
            $this->dbMain->where($item, $str);
            $res = $this->dbMain->count_all($this->table_name);
            // if there's a match, it's TRUE, if not, FALSE
            if( $res > 0   ) {
            return TRUE;
            } else {
                return FALSE;
            }
        }
    
    public function get_client_list($limit=10, $offset=0, $client_id, $order_column='user_id', $order_type='asc') {
            if(empty($order_column) || empty($order_type)) {
                $this->dbMain->order_by($this->primary_key, 'asc');
            }else {
                $this->dbMain->order_by($order_column, $order_type);
                $this->dbMain->where('client_id', $client_id);
                return $this->dbMain->get($this->table_name, $limit, $offset);
            } 
        }    

    public function check_login_status( $user_modified, $user_id, $user_login_time ) {
		// Selected user table data
		$selected_columns = array(
			'user_name',
			'user_email',
			'user_level',
			'user_agent_string',
			'user_id',
			'user_banned'
		);

		$this->dbMain->select( $selected_columns );
		$this->dbMain->from( config_item('user_table') );
		$this->dbMain->where( 'user_modified', $user_modified );
		$this->dbMain->where( 'user_id', $user_id );

		/**
		 * If multiple devices are allowed to login at the same time, 
		 * the user_login_time cannot be checked. The session ID is also useless.
		 */
		if( config_item('disallow_multiple_logins') === TRUE )
		{
			$this->dbMain->where( 'user_login_time', $user_login_time );

			// If the session ID was NOT regenerated, the session IDs should match
			if( is_null( $this->session->regenerated_session_id ) )
			{
				$this->db->where( 'user_session_id', $this->session->session_id );
			}

			// If it was regenerated, we can only compare the old session ID for this request
			else
			{
				$this->dbMain->where( 'user_session_id', $this->session->pre_regenerated_session_id );
			}
		}

		$this->dbMain->limit(1);
		$query = $this->db->get();

		if ( $query->num_rows() == 1 )
		{
			return $query->row();
		}

		return FALSE;
	}

	// --------------------------------------------------------------

        
        
       
}
